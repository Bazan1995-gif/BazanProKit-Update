/**
 * CSInterface - Adobe CEP (Common Extensibility Platform) JavaScript Interface
 * Version 8.0 - Compatible with After Effects 2020+
 * Official Adobe CEP Library
 */

var cslib = {}, CSInterface, SystemPath, ColorType, RGBColor, Direction, CSColor,
    AppSkinInfo, HostEnvironment, HostCapabilities, ApiVersion, CSEvent, CreativeCloudEvent;

(function() {
'use strict';

var ADOBE_CSS_COLOR_NAMES = { "aliceblue":"F0F8FF","antiquewhite":"FAEBD7","aqua":"00FFFF","aquamarine":"7FFFD4","azure":"F0FFFF","beige":"F5F5DC","bisque":"FFE4C4","black":"000000","blanchedalmond":"FFEBCD","blue":"0000FF","blueviolet":"8A2BE2","brown":"A52A2A","burlywood":"DEB887","cadetblue":"5F9EA0","chartreuse":"7FFF00","chocolate":"D2691E","coral":"FF7F50","cornflowerblue":"6495ED","cornsilk":"FFF8DC","crimson":"DC143C","cyan":"00FFFF","darkblue":"00008B","darkcyan":"008B8B","darkgoldenrod":"B8860B","darkgray":"A9A9A9","darkgreen":"006400","darkkhaki":"BDB76B","darkmagenta":"8B008B","darkolivegreen":"556B2F","darkorange":"FF8C00","darkorchid":"9932CC","darkred":"8B0000","darksalmon":"E9967A","darkseagreen":"8FBC8F","darkslateblue":"483D8B","darkslategray":"2F4F4F","darkturquoise":"00CED1","darkviolet":"9400D3","deeppink":"FF1493","deepskyblue":"00BFFF","dimgray":"696969","dodgerblue":"1E90FF","firebrick":"B22222","floralwhite":"FFFAF0","forestgreen":"228B22","fuchsia":"FF00FF","gainsboro":"DCDCDC","ghostwhite":"F8F8FF","gold":"FFD700","goldenrod":"DAA520","gray":"808080","green":"008000","greenyellow":"ADFF2F","honeydew":"F0FFF0","hotpink":"FF69B4","indianred":"CD5C5C","indigo":"4B0082","ivory":"FFFFF0","khaki":"F0E68C","lavender":"E6E6FA","lavenderblush":"FFF0F5","lawngreen":"7CFC00","lemonchiffon":"FFFACD","lightblue":"ADD8E6","lightcoral":"F08080","lightcyan":"E0FFFF","lightgoldenrodyellow":"FAFAD2","lightgray":"D3D3D3","lightgreen":"90EE90","lightpink":"FFB6C1","lightsalmon":"FFA07A","lightseagreen":"20B2AA","lightskyblue":"87CEFA","lightslategray":"778899","lightsteelblue":"B0C4DE","lightyellow":"FFFFE0","lime":"00FF00","limegreen":"32CD32","linen":"FAF0E6","magenta":"FF00FF","maroon":"800000","mediumaquamarine":"66CDAA","mediumblue":"0000CD","mediumorchid":"BA55D3","mediumpurple":"9370DB","mediumseagreen":"3CB371","mediumslateblue":"7B68EE","mediumspringgreen":"00FA9A","mediumturquoise":"48D1CC","mediumvioletred":"C71585","midnightblue":"191970","mintcream":"F5FFFA","mistyrose":"FFE4E1","moccasin":"FFE4B5","navajowhite":"FFDEAD","navy":"000080","oldlace":"FDF5E6","olive":"808000","olivedrab":"6B8E23","orange":"FFA500","orangered":"FF4500","orchid":"DA70D6","palegoldenrod":"EEE8AA","palegreen":"98FB98","paleturquoise":"AFEEEE","palevioletred":"DB7093","papayawhip":"FFEFD5","peachpuff":"FFDAB9","peru":"CD853F","pink":"FFC0CB","plum":"DDA0DD","powderblue":"B0E0E6","purple":"800080","red":"FF0000","rosybrown":"BC8F8F","royalblue":"4169E1","saddlebrown":"8B4513","salmon":"FA8072","sandybrown":"F4A460","seagreen":"2E8B57","seashell":"FFF5EE","sienna":"A0522D","silver":"C0C0C0","skyblue":"87CEEB","slateblue":"6A5ACD","slategray":"708090","snow":"FFFAFA","springgreen":"00FF7F","steelblue":"4682B4","tan":"D2B48C","teal":"008080","thistle":"D8BFD8","tomato":"FF6347","turquoise":"40E0D0","violet":"EE82EE","wheat":"F5DEB3","white":"FFFFFF","whitesmoke":"F5F5F5","yellow":"FFFF00","yellowgreen":"9ACD32" };

SystemPath = {
    USER_DATA : 'userData',
    COMMON_FILES : 'commonFiles',
    MY_DOCUMENTS : 'myDocuments',
    APPLICATION : 'application',
    EXTENSION : 'extension',
    EXTENSION_DATA : 'extensionData'
};

ColorType = {
    RGB : 'rgb',
    GRADIENT : 'gradient',
    NONE : 'none'
};

var THEME_COLOR_NAMES = {
    panelBackgroundColor : 'panelBackgroundColor',
    appBarBackgroundColor : 'appBarBackgroundColor'
};

Direction = {
    HORIZONTAL : 0,
    VERTICAL : 1
};

function RGBColor(red, green, blue, alpha) {
    this.red = red; this.green = green; this.blue = blue; this.alpha = alpha;
}
function Direction(value) { this.value = value; }
function CSColor(type, antiAliasLevel) { this.type = type; this.antiAliasLevel = antiAliasLevel; }
function AppSkinInfo(baseFontFamily, baseFontSize, imageDPI, scaleFactor, secondaryColor, panelBackgroundColor) {
    this.baseFontFamily = baseFontFamily; this.baseFontSize = baseFontSize;
    this.imageDPI = imageDPI; this.scaleFactor = scaleFactor;
    this.secondaryColor = secondaryColor; this.panelBackgroundColor = panelBackgroundColor;
}
function HostEnvironment(appName, appVersion, appLocale, appUILocale, appId, isAppOffline, appSkinInfo) {
    this.appName = appName; this.appVersion = appVersion; this.appLocale = appLocale;
    this.appUILocale = appUILocale; this.appId = appId; this.isAppOffline = isAppOffline;
    this.appSkinInfo = appSkinInfo;
}
function HostCapabilities(EXTENDED_PANEL_MENU, EXTENDED_PANEL_ICONS, DELEGATE_APE_ENGINE, SUPPORT_HTML_EXTENSIONS, DISABLE_FLASH_EXTENSIONS) {
    this.EXTENDED_PANEL_MENU = EXTENDED_PANEL_MENU; this.EXTENDED_PANEL_ICONS = EXTENDED_PANEL_ICONS;
    this.DELEGATE_APE_ENGINE = DELEGATE_APE_ENGINE; this.SUPPORT_HTML_EXTENSIONS = SUPPORT_HTML_EXTENSIONS;
    this.DISABLE_FLASH_EXTENSIONS = DISABLE_FLASH_EXTENSIONS;
}
function ApiVersion(major, minor, micro) { this.major = major; this.minor = minor; this.micro = micro; }
function CSEvent(type, scope, appId, extensionId) {
    this.type = type; this.scope = scope; this.appId = appId; this.extensionId = extensionId;
}
function CreativeCloudEvent(eventType, data) { this.type = eventType; this.data = data; }

CSInterface = function() {
    this.hostEnvironment = this.getHostEnvironment();
};

CSInterface.GLOBAL = 'GLOBAL';
CSInterface.APPLICATION = 'APPLICATION';
CSInterface.CS_EVENT_TYPE_ALL = 'com.adobe.csxs.events.*';
CSInterface.CS_EVENT_TYPE_CLOSE = 'com.adobe.csxs.events.ApplicationClosed';
CSInterface.CS_EVENT_TYPE_FOCUS = 'com.adobe.csxs.events.ApplicationActivated';
CSInterface.CS_EXTENSION_OPERATION_CHECK_ID = 'CSX.checkId';
CSInterface.prototype.getHostEnvironment = function() {
    return JSON.parse(window.__adobe_cep__.getHostEnvironment());
};
CSInterface.prototype.openExtension = function(extensionId, params) {
    window.__adobe_cep__.invokeAsync('openExtension', extensionId, params);
};
CSInterface.prototype.getExtensions = function(extensionIds) {
    var extensionIdsStr = JSON.stringify(extensionIds);
    var resStr = window.__adobe_cep__.invokeSync('getExtensions', extensionIdsStr);
    return JSON.parse(resStr);
};
CSInterface.prototype.getNetworkPreferences = function() {
    var result = window.__adobe_cep__.invokeSync('getNetworkPreferences', '');
    return JSON.parse(result);
};
CSInterface.prototype.initResourceBundle = function() {
    var resBundle = {}; var bundlePath = csInterface.getSystemPath(SystemPath.EXTENSION) + '/CSXS/resources/';
    var hostUILocale = csInterface.getHostEnvironment().appUILocale;
    return resBundle;
};
CSInterface.prototype.dumpInstallationInfo = function() {
    return window.__adobe_cep__.dumpInstallationInfo();
};
CSInterface.prototype.getOSInformation = function() { return window.__adobe_cep__.getOSInformation(); };
CSInterface.prototype.openURLInDefaultBrowser = function(url) {
    if (window.cep && cep.util) cep.util.openURLInDefaultBrowser(url);
    else window.__adobe_cep__.openURLInDefaultBrowser(url);
};
CSInterface.prototype.getSystemPath = function(pathType) {
    var result = decodeURI(window.__adobe_cep__.getSystemPath(pathType));
    var OSVersion = this.getOSInformation();
    if (OSVersion.indexOf('Windows') >= 0) result = result.replace('file:///','');
    else result = result.replace('file://','');
    return result;
};
CSInterface.prototype.evalScript = function(script, callback) {
    if (callback == null || callback == undefined) callback = function(result){};
    window.__adobe_cep__.evalScript(script, callback);
};
CSInterface.prototype.getApplicationID = function() {
    var appId = this.hostEnvironment.appId;
    return appId;
};
CSInterface.prototype.getHostCapabilities = function() {
    var hostCapabilities = JSON.parse(window.__adobe_cep__.getHostCapabilities());
    return hostCapabilities;
};
CSInterface.prototype.dispatchEvent = function(event) {
    if (typeof event.data == 'object') event.data = JSON.stringify(event.data);
    window.__adobe_cep__.dispatchEvent(event);
};
CSInterface.prototype.addEventListener = function(type, listener, obj) {
    window.__adobe_cep__.addEventListener(type, listener, obj);
};
CSInterface.prototype.removeEventListener = function(type, listener, obj) {
    window.__adobe_cep__.removeEventListener(type, listener, obj);
};
CSInterface.prototype.requestOpenExtension = function(extensionId, params) {
    window.__adobe_cep__.requestOpenExtension(extensionId, params);
};
CSInterface.prototype.getExtensionList = function() {
    return JSON.parse(window.__adobe_cep__.getExtensionList());
};
CSInterface.prototype.setPanelFlyoutMenu = function(menu) {
    if ('string' != typeof menu) return;
    window.__adobe_cep__.setPanelFlyoutMenu(menu);
};
CSInterface.prototype.updatePanelMenuItem = function(menuItemLabel, enabled, checked) {
    var result = false;
    if (this.getHostCapabilities().EXTENDED_PANEL_MENU) {
        var itemStatus = new MenuItemStatus(menuItemLabel, enabled, checked);
        result = !window.__adobe_cep__.updatePanelMenuItem(JSON.stringify(itemStatus));
    }
    return result;
};
CSInterface.prototype.setContextMenu = function(menu, callback) {
    if ('string' != typeof menu) return;
    window.__adobe_cep__.setContextMenu(menu, callback);
};
CSInterface.prototype.setContextMenuByJSON = function(menu, callback) {
    if ('string' != typeof menu) return;
    window.__adobe_cep__.setContextMenuByJSON(menu, callback);
};
CSInterface.prototype.updateContextMenuItem = function(menuItemID, enabled, checked) {
    var itemStatus = new ContextMenuItemStatus(menuItemID, enabled, checked);
    window.__adobe_cep__.updateContextMenuItem(JSON.stringify(itemStatus));
};
CSInterface.prototype.getExtensionState = function(extensionId) {
    return JSON.parse(window.__adobe_cep__.getExtensionState(extensionId));
};
CSInterface.prototype.setExtensionState = function(state) {
    window.__adobe_cep__.setExtensionState(JSON.stringify(state));
};
CSInterface.prototype.getCurrentApiVersion = function() {
    var ver = JSON.parse(window.__adobe_cep__.getCurrentApiVersion());
    return ver;
};
CSInterface.prototype.setCursorStyle = function(cursorStyle) {
    document.body.style.cursor = cursorStyle;
};
CSInterface.prototype.getScaleFactor = function() { return window.__adobe_cep__.getScaleFactor(); };
CSInterface.prototype.setScaleFactorChangedHandler = function(handler) {
    window.__adobe_cep__.setScaleFactorChangedHandler(handler);
};
CSInterface.prototype.getCurrentImsUserInfo = function(callback) {
    window.__adobe_cep__.getCurrentImsUserInfo(callback);
};
CSInterface.prototype.isImsUserSignedIn = function() {
    return window.__adobe_cep__.isImsUserSignedIn();
};
CSInterface.prototype.registerExtensionUnloadCallback = function(extensionId, callback) {
    window.__adobe_cep__.registerExtensionUnloadCallback(extensionId, callback);
};
CSInterface.prototype.showPanel = function() { window.__adobe_cep__.showPanel(); };
CSInterface.prototype.closeExtension = function() { window.__adobe_cep__.closeExtension(); };
CSInterface.prototype.getLastError = function() { return window.__adobe_cep__.getLastError(); };

}());
