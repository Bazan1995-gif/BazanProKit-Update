/* ═══════════════════════════════════════════════════════════
   BAZAN PRO KIT V4 — CEP PANEL JAVASCRIPT (CRASH-PROOF)
   ═══════════════════════════════════════════════════════════ */
const CURRENT_VERSION = "2.0.0";
var csInterface = new CSInterface();

// ── UTILITIES ────────────────────────────────────────────────
function runJSX(call, cb) {
  csInterface.evalScript(call, function(r) {
    if (r && r !== 'undefined' && r !== 'null' && r !== 'EvalScript error.') {
      if (cb) cb(r);
    } else {
      if (cb) cb(null);
    }
  });
}

function toast(msg, type) {
  var el = document.getElementById('toast');
  if (!el) return;
  el.textContent = msg;
  el.className = 'show' + (type === 'err' ? ' err' : '');
  clearTimeout(window._tt);
  window._tt = setTimeout(function() { el.className = ''; }, 2200);
}

function esc(s) { return (s || '').replace(/\\/g,'\\\\').replace(/'/g,"\\'"); }

// دالة ذكية لمنع الكراش لو في زرار مش موجود في الـ HTML
function bindClick(id, callback) {
  var el = document.getElementById(id);
  if (el) {
    el.addEventListener('click', callback);
  } else {
    console.warn("Bazan Kit Warning: Button ID '" + id + "' not found in HTML. Skipped.");
  }
}

function openModal(id) {
  var overlay = document.getElementById('overlay');
  if(overlay) overlay.classList.add('open');
  document.querySelectorAll('.modal').forEach(function(m) { m.style.display = 'none'; });
  var m = document.getElementById(id);
  if (m) m.style.display = 'block';
}

function closeModal() { 
  var overlay = document.getElementById('overlay');
  if(overlay) overlay.classList.remove('open'); 
}

var overlayEl = document.getElementById('overlay');
if(overlayEl) {
  overlayEl.addEventListener('click', function(e) {
    if (e.target === this) closeModal();
  });
}

// ── TABS ─────────────────────────────────────────────────────
document.querySelectorAll('.tab-btn').forEach(function(btn) {
  btn.addEventListener('click', function() {
    var t = this.dataset.tab;
    document.querySelectorAll('.tab-btn').forEach(function(b) { b.classList.remove('active'); });
    document.querySelectorAll('.tab-panel').forEach(function(p) { p.classList.remove('active'); });
    this.classList.add('active');
    var targetPanel = document.getElementById(t);
    if(targetPanel) targetPanel.classList.add('active');
  });
});

// ── COLLAPSIBLE SECTIONS ─────────────────────────────────────
document.querySelectorAll('.section-header').forEach(function(hdr) {
  hdr.addEventListener('click', function(e) {
    if (e.target.closest('.drag-handle')) return;
    this.closest('.section').classList.toggle('collapsed');
    saveSectionStates();
  });
});

function saveSectionStates() {
  var states = {};
  document.querySelectorAll('.section[data-id]').forEach(function(s) {
    states[s.dataset.id] = s.classList.contains('collapsed');
  });
  try { localStorage.setItem('bpk4_sections', JSON.stringify(states)); } catch(e) {}
}
function loadSectionStates() {
  try {
    var s = localStorage.getItem('bpk4_sections');
    if (!s) return;
    var states = JSON.parse(s);
    document.querySelectorAll('.section[data-id]').forEach(function(sec) {
      if (states[sec.dataset.id]) sec.classList.add('collapsed');
    });
  } catch(e) {}
}

// ── DRAG & DROP REORDER ──────────────────────────────────────
var _dragSrc = null;

function initDragDrop() {
  document.querySelectorAll('.drag-zone').forEach(function(zone) {
    zone.addEventListener('dragover', function(e) {
      e.preventDefault(); this.classList.add('drag-over');
    });
    zone.addEventListener('dragleave', function() { this.classList.remove('drag-over'); });
    zone.addEventListener('drop', function(e) {
      e.preventDefault(); this.classList.remove('drag-over');
      if (!_dragSrc || _dragSrc.parentNode !== this) return;
      var afterEl = getDragAfter(this, e.clientY);
      if (afterEl == null) this.appendChild(_dragSrc);
      else this.insertBefore(_dragSrc, afterEl);
      _dragSrc.classList.remove('dragging');
      _dragSrc = null;
      saveSectionOrder();
    });
  });
  document.querySelectorAll('.section').forEach(initSectionDrag);
}

function initSectionDrag(sec) {
  sec.setAttribute('draggable', 'true');
  sec.addEventListener('dragstart', function(e) {
    _dragSrc = this;
    this.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', this.dataset.id || '');
  });
  sec.addEventListener('dragend', function() {
    this.classList.remove('dragging');
    _dragSrc = null;
  });
}

function getDragAfter(zone, y) {
  var els = [].slice.call(zone.querySelectorAll('.section:not(.dragging)'));
  return els.reduce(function(closest, el) {
    var box = el.getBoundingClientRect();
    var offset = y - box.top - box.height / 2;
    if (offset < 0 && offset > closest.offset) return { offset: offset, el: el };
    return closest;
  }, { offset: Number.NEGATIVE_INFINITY }).el;
}

function saveSectionOrder() {
  var order = {};
  document.querySelectorAll('.drag-zone').forEach(function(zone, zi) {
    var ids = [];
    zone.querySelectorAll('.section[data-id]').forEach(function(s) { ids.push(s.dataset.id); });
    order['zone' + zi] = ids;
  });
  try { localStorage.setItem('bpk4_order', JSON.stringify(order)); } catch(e) {}
}

function loadSectionOrder() {
  try {
    var raw = localStorage.getItem('bpk4_order');
    if (!raw) return;
    var order = JSON.parse(raw);
    document.querySelectorAll('.drag-zone').forEach(function(zone, zi) {
      var ids = order['zone' + zi];
      if (!ids) return;
      ids.forEach(function(id) {
        var sec = zone.querySelector('[data-id="' + id + '"]');
        if (sec) zone.appendChild(sec);
      });
    });
  } catch(e) {}
}

// ════════════════════════════════════════════════════════════
// TAB 1 — BASICS & EASE
// ════════════════════════════════════════════════════════════

var easeIn  = 33; 
var easeOut = 33; 
var activePreset = -1;

var cvs = document.getElementById('ease-canvas');
var ctx = cvs ? cvs.getContext('2d') : null;

function drawCurve(context, w, h, inInf, outInf, color, lw, mini) {
  if(!context) return;
  var iV = Math.max(0.001, inInf  / 100); 
  var oV = Math.max(0.001, outInf / 100); 
  var px = mini ? 1 : 0, py = mini ? 1 : 0;
  var eW = w - px*2, eH = h - py*2;
  var sc = mini ? 2.5 : 3.2;
  context.beginPath();
  var started = false;
  for (var t = 0; t <= 1.001; t += 0.02) {
    var ct = Math.min(1,t), mt = 1-ct;
    var vx = 3*mt*mt*ct*iV + 3*mt*ct*ct*(1-oV) + ct*ct*ct;
    var bx = px + vx*eW;
    var dy = 6*ct*mt;
    var dx = 3*iV*mt*(1-3*ct) + 3*(1-oV)*ct*(2-3*ct) + 3*ct*ct;
    var sp = (dx === 0) ? 0 : Math.abs(dy/dx);
    var by = (h-py) - (sp*(eH/sc));
    by = Math.max(py, Math.min(h-py, by));
    if (!started) { context.moveTo(bx, by); started = true; } else context.lineTo(bx, by);
  }
  context.strokeStyle = color;
  context.lineWidth   = lw;
  context.stroke();
}

function redrawGraph() {
  if(!cvs || !ctx) return;
  var w = cvs.width, h = cvs.height;
  ctx.clearRect(0,0,w,h);
  ctx.fillStyle = '#020208'; ctx.fillRect(0,0,w,h);
  ctx.strokeStyle = 'rgba(255,255,255,0.06)'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(w/2,0); ctx.lineTo(w/2,h); ctx.stroke();
  
  // تم العكس هنا: easeIn الأول وبعدين easeOut عشان الكيرف يتعدل
  drawCurve(ctx, w, h, easeIn, easeOut, '#FFA61A', 2, false);
}

function setSliders(inV, outV, presetIdx) {
  easeIn  = inV;  easeOut = outV;
  activePreset = (presetIdx !== undefined) ? presetIdx : -1;
  if(document.getElementById('sld-in')) document.getElementById('sld-in').value  = inV;
  if(document.getElementById('sld-out')) document.getElementById('sld-out').value = outV;
  if(document.getElementById('val-in')) document.getElementById('val-in').value  = Math.round(inV);
  if(document.getElementById('val-out')) document.getElementById('val-out').value = Math.round(outV);
  redrawGraph();
  updatePresetHighlight();
}

['sld-in','sld-out','val-in','val-out'].forEach(function(id) {
  var el = document.getElementById(id);
  if(!el) return; // حماية ضد الكراش
  var ev = id.startsWith('sld') ? 'input' : 'change';
  el.addEventListener(ev, function() {
    var v = parseFloat(this.value);
    if (isNaN(v)) return;
    v = Math.max(0.1, Math.min(100, v));
    if (id === 'sld-in')  { easeIn  = v; if(document.getElementById('val-in')) document.getElementById('val-in').value  = Math.round(v); }
    if (id === 'sld-out') { easeOut = v; if(document.getElementById('val-out')) document.getElementById('val-out').value = Math.round(v); }
    if (id === 'val-in')  { easeIn  = v; if(document.getElementById('sld-in')) document.getElementById('sld-in').value  = v; }
    if (id === 'val-out') { easeOut = v; if(document.getElementById('sld-out')) document.getElementById('sld-out').value = v; }
    activePreset = -1;
    redrawGraph();
    updatePresetHighlight();
  });
});

bindClick('btn-ease-apply', function() {
  runJSX('applyEaseKeys(' + easeOut + ',' + easeIn + ')', function() { toast('Ease applied ✓'); });
});

bindClick('btn-ease-save', function() {
  runJSX('saveCurrentPreset(' + easeIn + ',' + easeOut + ')', function(len) {
    var newIdx = (parseInt(len) || 1) - 1;
    activePreset = newIdx;
    loadPresets();
    toast('Preset saved ✓');
  });
});

bindClick('btn-ease-del', function() {
  if (activePreset < 0) { toast('Select a preset first'); return; }
  runJSX('deletePreset(' + activePreset + ')', function() {
    activePreset = -1;
    loadPresets();
    toast('Preset deleted');
  });
});

function drawPreset(canvas, sldIn, sldOut, active) {
  var c = canvas.getContext('2d');
  var w = canvas.width, h = canvas.height;
  c.clearRect(0,0,w,h);
  c.fillStyle = active ? '#1e1e38' : '#040408';
  c.fillRect(0,0,w,h);
  c.strokeStyle = active ? 'rgba(255,166,26,0.7)' : 'rgba(80,80,120,0.5)';
  c.lineWidth = active ? 1.5 : 1;
  c.strokeRect(0.5,0.5,w-1,h-1);
  
  // وتم العكس هنا كمان عشان الأيقونات الصغيرة للـ Presets تترسم صح
  drawCurve(c, w, h, sldIn, sldOut, '#FFA61A', 1.2, true);
}

function updatePresetHighlight() {
  document.querySelectorAll('.preset-btn').forEach(function(btn, i) {
    var isActive = (i === activePreset);
    btn.classList.toggle('active', isActive);
    var cv = btn.querySelector('canvas');
    if (cv) drawPreset(cv, parseFloat(btn.dataset.in), parseFloat(btn.dataset.out), isActive);
  });
}

function loadPresets() {
  runJSX('getPresetsJSON()', function(json) {
    var presets = [];
    try { presets = JSON.parse(json || '[]'); } catch(e) {}
    var grid = document.getElementById('preset-grid');
    if(!grid) return;
    grid.innerHTML = '';
    presets.forEach(function(preset, idx) {
      var parts = preset.split(',');
      if (parts.length !== 2) return;
      var inV  = parseFloat(parts[0]);
      var outV = parseFloat(parts[1]);
      var btn = document.createElement('button');
      btn.className = 'preset-btn';
      btn.dataset.in  = inV;
      btn.dataset.out = outV;
      btn.title = 'In: ' + Math.round(inV) + '  Out: ' + Math.round(outV);
      var cv = document.createElement('canvas');
      cv.width = 24; cv.height = 24;
      btn.appendChild(cv);
      btn.addEventListener('click', (function(iV, oV, ix) {
        return function() {
          setSliders(iV, oV, ix);
          runJSX('applyEaseKeys(' + oV + ',' + iV + ')');
        };
      })(inV, outV, idx));
      grid.appendChild(btn);
    });
    updatePresetHighlight();
  });
}

redrawGraph();
loadPresets();

// ── BASIC TOOLS ──────────────────────────────────────────────
bindClick('btn-solid', function() { runJSX('addSolid()'); });
bindClick('btn-adj', function() { runJSX('addAdjLayer()', function() { toast('Adjustment layer added'); }); });
bindClick('btn-null', function() { runJSX('addSmartNull()', function() { toast('Smart null created'); }); });
bindClick('btn-reverse', function() { runJSX('reverseLayers()', function(r) { toast(r || 'Reversed'); }); });
bindClick('btn-trim', function() { openModal('modal-trim'); });

bindClick('trim-in', function() { closeModal(); runJSX("trimKeys('in')",   function() { toast('Trimmed to In'); }); });
bindClick('trim-out', function() { closeModal(); runJSX("trimKeys('out')",  function() { toast('Trimmed to Out'); }); });
bindClick('trim-both', function() { closeModal(); runJSX("trimKeys('both')", function() { toast('Trimmed Both'); }); });

// ── BOUNCE BUNDLE ──────────────────────────
bindClick('btn-bounce', function() {
    var pEl = document.getElementById('chk-bounce-pos');
    var sEl = document.getElementById('chk-bounce-scale');
    var rEl = document.getElementById('chk-bounce-rot');
    
    // خليتها بـ true عشان لو إنت مش حاطط checkboxes في الواجهة يتطبق عليهم كلهم إجباري
    var doPos = pEl ? pEl.checked : true;
    var doScale = sEl ? sEl.checked : true;
    var doRot = rEl ? rEl.checked : true; 

    runJSX('applyBazanBounce(' + doPos + ', ' + doScale + ', ' + doRot + ')', function(r) { 
        toast(r || 'Bounce Applied ✓'); 
    }); 
});
// ── COMPOSITIONS ─────────────────────────────────────────────
bindClick('btn-precomp', function() { openModal('modal-precomp'); });
bindClick('precomp-ok', function() {
  var name = document.getElementById('pc-name') ? document.getElementById('pc-name').value : 'Pre-comp 1';
  var crop = document.getElementById('pc-crop') ? document.getElementById('pc-crop').checked : false;
  var mask = document.getElementById('pc-mask') ? document.getElementById('pc-mask').checked : false;
  var pad  = document.getElementById('pc-pad') ? parseInt(document.getElementById('pc-pad').value) : 0;
  if(isNaN(pad)) pad = 0;
  closeModal();
  runJSX("preComposeSelected('" + esc(name) + "'," + crop + ',' + mask + ',' + pad + ')', function() { toast('Pre-composed ✓'); });
});
bindClick('precomp-cancel', closeModal);

var pcCrop = document.getElementById('pc-crop');
if(pcCrop) {
  pcCrop.addEventListener('change', function() {
    var pcMask = document.getElementById('pc-mask');
    if(pcMask) pcMask.disabled = !this.checked;
  });
}

bindClick('btn-unprecomp', function() { openModal('modal-unprecomp'); });
bindClick('unprecomp-del', function() { closeModal(); runJSX('unPrecompose(true)',  function(r) { toast(r || 'Un-Precomposed ✓'); }); });
bindClick('unprecomp-keep', function() { closeModal(); runJSX('unPrecompose(false)', function(r) { toast(r || 'Un-Precomposed (hidden)'); }); });
bindClick('unprecomp-cancel', closeModal);

bindClick('btn-copycomp', function() { openModal('modal-copycomp'); });
bindClick('copycomp-ok', function() {
  var copies = document.getElementById('cc-copies') ? parseInt(document.getElementById('cc-copies').value) : 1;
  var suffix = document.getElementById('cc-suffix') ? document.getElementById('cc-suffix').value : '_';
  if(isNaN(copies)) copies = 1;
  closeModal();
  runJSX('copyComp(' + copies + ",'" + esc(suffix) + "')", function(r) { toast(r || 'Copied ✓'); });
});
bindClick('copycomp-cancel', closeModal);

// ── TEXT EXPLODER ─────────────────────────────────────────────
bindClick('btn-textbox', function() { runJSX('addTextBoxRig()', function() { toast('Text Box Rig created ✓'); }); });
bindClick('btn-srt', function() {
  csInterface.evalScript("var f=File.openDialog('Select SRT','*.srt');f?f.fsName:''", function(path) {
    if (path && path.length > 1) {
      runJSX("importSRT('" + path.replace(/\\/g,'\\\\') + "')", function() { toast('SRT imported ✓'); });
    }
  });
});
bindClick('btn-decompose', function() {
  var mode  = document.getElementById('decomp-mode') ? document.getElementById('decomp-mode').selectedIndex : 0;
  var order = document.getElementById('decomp-order') ? document.getElementById('decomp-order').selectedIndex : 0;
  var rtl   = document.getElementById('decomp-rtl') ? document.getElementById('decomp-rtl').checked : false;
  var ttb   = (order === 0);
  runJSX('decomposeText(' + mode + ',' + rtl + ',' + ttb + ')', function() { toast('Decomposed ✓'); });
});

// ── NUMBER & SYMBOL ───────────────────────────────────────────
function applyNum(comma) {
  var sym    = document.getElementById('dropSym') ? document.getElementById('dropSym').value : '';
  var custom = document.getElementById('txtCustomSym') ? document.getElementById('txtCustomSym').value.trim() : '';
  var pos    = document.getElementById('dropPos') ? document.getElementById('dropPos').selectedIndex : 0;
  
  if(!sym && document.getElementById('num-sym')) sym = document.getElementById('num-sym').value;
  if(!custom && document.getElementById('num-custom')) custom = document.getElementById('num-custom').value.trim();
  if(!pos && document.getElementById('num-pos')) pos = document.getElementById('num-pos').selectedIndex;

  runJSX("applyNumberScript(" + comma + ",'" + esc(sym) + "'," + pos + ",'" + esc(custom) + "')", function() { toast('Counter applied ✓'); });
}
bindClick('btn-num-count', function() { applyNum(false); });
bindClick('btn-num-comma', function() { applyNum(true); });
bindClick('btnNumCount', function() { applyNum(false); });
bindClick('btnNumComma', function() { applyNum(true); });

// ════════════════════════════════════════════════════════════
// TAB 2 — PROXIMITY & RIGS
// ════════════════════════════════════════════════════════════

bindClick('btn-pts-nulls', function() { runJSX('pointsFollowNulls()', function() { toast('Points follow nulls ✓'); }); });
bindClick('btn-nulls-pts', function() { runJSX('nullsFollowPoints()', function() { toast('Nulls follow points ✓'); }); });
bindClick('btn-trace', function() { runJSX('tracePath()', function() { toast('Trace path created ✓'); }); });

bindClick('btn-path-rig', function() { openModal('modal-pathrig'); });
bindClick('pathrig-ok', function() {
  var countEl = document.getElementById('pathrig-count');
  var n = countEl ? parseInt(countEl.value) : 6;
  if(isNaN(n)) n = 6;
  closeModal();
  runJSX('createAutoPathRig(' + n + ')', function() { toast('Auto Path Rig created ✓'); });
});
bindClick('pathrig-cancel', closeModal);

bindClick('btn-around', function() { runJSX('aroundObject()', function() { toast('Around Object rig ✓'); }); });
bindClick('btn-ropes', function() {
  var typeEl = document.getElementById('rope-type');
  var type = typeEl ? typeEl.selectedIndex : 0;
  runJSX('networkRopes(' + type + ')', function() { toast('Network Ropes created ✓'); });
});

bindClick('btn-space', function(e) {
  var isCtrl = e.ctrlKey || e.metaKey;
  runJSX('applySpaceXYZR(' + isCtrl + ')', function() { toast(isCtrl ? 'Space baked ✓' : 'Space applied ✓'); });
});

bindClick('btn-prox-scale', function(e) {
  var isCtrl = e.ctrlKey || e.metaKey;
  runJSX('applyProxScale(' + isCtrl + ')', function() { toast(isCtrl ? 'Scale baked ✓' : 'Scale applied ✓'); });
});

bindClick('btn-ui-style', function() { openModal('modal-uistyle'); });
bindClick('uistyle-ok', function() {
  var typeEl = document.getElementById('uistyle-type');
  var shape = typeEl ? (typeEl.selectedIndex === 1) : false;
  closeModal();
  runJSX('applyUIStyle(' + shape + ',false)', function() { toast('UI Style applied ✓'); });
});
bindClick('uistyle-bake', function() {
  closeModal();
  runJSX('applyUIStyle(false,true)', function() { toast('UI Style baked ✓'); });
});
bindClick('uistyle-cancel', closeModal);

// ════════════════════════════════════════════════════════════
// TAB 3 — SPACE & FILL
// ════════════════════════════════════════════════════════════

bindClick('btn-split-masks', function() { runJSX('splitMasksToLayers()', function(r) { toast(r && r.length > 2 ? r : 'Masks split ✓'); }); });

bindClick('btn-disperse', function() { runDepth(false); });
bindClick('btn-move', function() { runDepth(true); });

function runDepth(isMove) {
  var focalEl = document.getElementById('z-focal');
  var spaceEl = document.getElementById('z-space');
  var distEl = document.getElementById('z-dist');
  var camNullEl = document.getElementById('z-camnull');

  var lens   = focalEl ? parseFloat(focalEl.value) : 50;
  var space  = spaceEl ? parseFloat(spaceEl.value) : 1000;
  var dist   = distEl ? parseFloat(distEl.value) : 0;
  var camNull= camNullEl ? camNullEl.checked : false;

  if(isNaN(lens)) lens = 50; if(isNaN(space)) space = 1000; if(isNaN(dist)) dist = 0;

  runJSX('executeDepth(' + lens + ',' + space + ',' + dist + ',' + camNull + ',' + isMove + ')',
    function(r) { toast(r && r.length > 2 ? r : (isMove ? 'Z Move ✓' : 'Z Disperse ✓')); });
}

// Smart Fill
var rgb1 = [0.8, 0.1, 0.2], rgb2 = [0.1, 0.5, 0.8];
function rgb2css(c) { return 'rgb(' + Math.round(c[0]*255) + ',' + Math.round(c[1]*255) + ',' + Math.round(c[2]*255) + ')'; }
function hex2rgb(hex) { hex = hex.replace(/^#/,''); if (hex.length===3) hex=hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2]; return [parseInt(hex.slice(0,2),16)/255,parseInt(hex.slice(2,4),16)/255,parseInt(hex.slice(4,6),16)/255]; }
function rgb2hex(c) { return c.map(function(v){return ('0'+Math.round(v*255).toString(16)).slice(-2);}).join('').toUpperCase(); }

var swatch1 = document.getElementById('swatch1');
var swatch2 = document.getElementById('swatch2');
if(swatch1) {
  swatch1.style.background = rgb2css(rgb1);
  swatch1.addEventListener('click', function() {
    var h = prompt('Hex color (e.g. CC1A33):', rgb2hex(rgb1));
    if (h) { rgb1 = hex2rgb(h); this.style.background = rgb2css(rgb1); }
  });
}
if(swatch2) {
  swatch2.style.background = rgb2css(rgb2);
  swatch2.addEventListener('click', function() {
    var h = prompt('Hex color (e.g. 1A80CC):', rgb2hex(rgb2));
    if (h) { rgb2 = hex2rgb(h); this.style.background = rgb2css(rgb2); }
  });
}

var fillOpacSld = document.getElementById('fill-opac-sld');
if(fillOpacSld) {
  fillOpacSld.addEventListener('input', function() {
    var valEl = document.getElementById('fill-opac-val');
    if(valEl) valEl.textContent = Math.round(this.value) + '%';
  });
}

bindClick('btn-fill-apply', function(e) {
  var opacEl = document.getElementById('fill-opac-sld');
  var opac  = opacEl ? parseFloat(opacEl.value) : 100;
  if(isNaN(opac)) opac = 100;
  var isAlt = e.altKey;
  runJSX('applySmartFill(' + rgb1.join(',') + ',' + rgb2.join(',') + ',' + opac + ',' + isAlt + ')',
    function() { toast(isAlt ? 'Fill removed ✓' : 'Smart Fill applied ✓'); });
});

bindClick('btn-pull', function() {
  var groupedEl = document.getElementById('pull-grouped');
  var grouped = groupedEl ? groupedEl.checked : false;
  runJSX('pullInAE(' + grouped + ')', function(r) {
    if (r === 'ok') toast('AI shapes imported ✓');
    else if (r) toast(r, 'err');
  });
});

// ── THEME SYNC ────────────────────────────────────────────────
function syncTheme() {
  try {
    var env = csInterface.getHostEnvironment();
    if (env && env.appSkinInfo) {
      var bg = env.appSkinInfo.panelBackgroundColor.color;
      if (bg && bg.red !== undefined) {
        var br = (0.299*bg.red + 0.587*bg.green + 0.114*bg.blue) / 255;
        if (br > 0.6) document.body.classList.add('light-host');
      }
    }
  } catch(e) {}
}
syncTheme();

// ── INIT ─────────────────────────────────────────────────────
loadSectionOrder();
loadSectionStates();
initDragDrop();

bindClick('btnNewton', function() {
  csInterface.evalScript('applyNewtonLauncherScript()');
});

