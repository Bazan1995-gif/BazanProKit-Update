/**
 * BAZAN PRO KIT V4 — CEP Host Bridge
 * All logic ported exactly from Bazan_ProKit_V4.jsx.
 * Optimised for JSXBIN conversion: no eval(), no direct File access in hot paths.
 */

// ── UNDO SYSTEM ──────────────────────────────────────────────
var _ud = 0;
function _addUndo(name, fn) {
    var g = false;
    if (_ud === 0) { app.beginUndoGroup(name); g = true; }
    _ud++;
    try { fn(); } catch(e) {}
    finally { _ud--; if (g && _ud === 0) app.endUndoGroup(); }
}
function _handleExpression(prop, expr, isCtrl, isAlt) {
    if (!prop || !prop.canSetExpression) return;
    if (isAlt)  { prop.expression = ""; }
    else if (isCtrl) { if (prop.expression !== "") { var v = prop.value; prop.expression = ""; prop.setValue(v); } }
    else { prop.expression = expr; }
}
function _getCompSel() {
    var c = app.project.activeItem;
    if (!c || !(c instanceof CompItem)) return null;
    var s = c.selectedLayers;
    return (s.length === 0) ? null : { comp: c, layers: s };
}
function _manageEffect(layer, matchName, displayName) {
    var fx = layer.property("Effects");
    var e = fx.property(displayName);
    if (!e) { e = fx.addProperty(matchName); e.name = displayName; }
    return e;
}

// ── EASE ─────────────────────────────────────────────────────
function applyEaseKeys(inV, outV) {
    var comp = app.project.activeItem; if (!comp) return;
    var sel = comp.selectedProperties;
    _addUndo("Apply Speed", function() {
        for (var i = 0; i < sel.length; i++) {
            var p = sel[i]; if (!p.canVaryOverTime) continue;
            for (var j = 0; j < p.selectedKeys.length; j++) {
                var k = p.selectedKeys[j];
                p.setInterpolationTypeAtKey(k, KeyframeInterpolationType.BEZIER);
                var inE = p.keyInTemporalEase(k); var outE = p.keyOutTemporalEase(k);
                var iA = [], oA = [];
                for (var d = 0; d < inE.length;  d++) iA.push(new KeyframeEase(0, inV));
                for (var d = 0; d < outE.length; d++) oA.push(new KeyframeEase(0, outV));
                p.setTemporalEaseAtKey(k, iA, oA);
            }
        }
    });
}

// ── EASE PRESETS ─────────────────────────────────────────────
var _eS = "BazanProEase_V5"; var _eK = "SavedPresets";
function getSavedPresets() {
    if (app.settings.haveSetting(_eS, _eK)) { var s = app.settings.getSetting(_eS, _eK); if (s !== "") return s.split("|"); }
    return [];
}
function savePresets(arr) { app.settings.saveSetting(_eS, _eK, arr.join("|")); }
function saveCurrentPreset(sldInVal, sldOutVal) {
    var arr = getSavedPresets();
    arr.push(sldInVal + "," + sldOutVal);
    savePresets(arr);
    return arr.length;
}
function deletePreset(idx) {
    var arr = getSavedPresets();
    if (idx >= 0 && idx < arr.length) { arr.splice(idx, 1); savePresets(arr); return true; }
    return false;
}
function getPresetsJSON() { return JSON.stringify(getSavedPresets()); }

// ── PATH NULLS ───────────────────────────────────────────────
var PathNulls = {};
PathNulls.createNull = function(c) { var n = c.layers.addNull(); n.property("Anchor Point").setValue([50,50]); return n; };
PathNulls.getSelectedProperties = function(l) { var p = l.selectedProperties; return (p.length<1)?null:p; };
PathNulls.forEachLayer = function(a,fn) { for(var i=0;i<a.length;i++) fn(a[i]); };
PathNulls.forEachProperty = function(a,fn) { for(var i=0;i<a.length;i++) fn(a[i]); };
PathNulls.forEachEffect = function(l,fn) { for(var i=1;i<=l.property("ADBE Effect Parade").numProperties;i++) fn(l.property("ADBE Effect Parade").property(i)); };
PathNulls.matchMatchName = function(fx,name) { return (fx!=null&&fx.matchName===name)?fx:null; };
PathNulls.getPropPath = function(cur,hier) { var pp=""; while(cur.parentProperty!==null){ if(cur.parentProperty.propertyType===PropertyType.INDEXED_GROUP){hier.unshift(cur.propertyIndex);pp="("+cur.propertyIndex+")"+pp;}else{pp="(\""+cur.matchName.toString()+"\")"+pp;} cur=cur.parentProperty;} return pp; };
PathNulls.getPathPoints = function(path) { return path.value.vertices; };
PathNulls.forEachPath = function(doSomething) {
    var comp = app.project.activeItem; if(!comp) return;
    var selL = comp.selectedLayers; if(!selL) return;
    var selP=[]; var parL=[];
    PathNulls.forEachLayer(selL, function(sl){ var paths=PathNulls.getSelectedProperties(sl); if(!paths) return; PathNulls.forEachProperty(paths,function(path){ if(PathNulls.matchMatchName(path,"ADBE Vector Shape")!=null||PathNulls.matchMatchName(path,"ADBE Mask Shape")!=null){selP.push(path);parL.push(sl);}});});
    if(selP.length==0) return alert("Error: No paths selected.");
    for(var p=0;p<selP.length;p++) doSomething(comp,parL[p],selP[p]);
};
function nullsFollowPoints() {
    _addUndo("Nulls Follow Points", function() { PathNulls.forEachPath(function(comp,sl,path){ var ph=[]; var pp=PathNulls.getPropPath(path,ph); var pts=PathNulls.getPathPoints(path); for(var i=0;i<pts.length;i++){ var nm=sl.name+": "+path.parentProperty.name+" ["+ph.join(".")+"."+i+"]"; if(comp.layer(nm)==undefined){var nn=PathNulls.createNull(comp); nn.moveBefore(sl); nn.position.setValue(pts[i]); nn.position.expression="var srcLayer = thisComp.layer(\""+sl.name+"\"); \rvar srcPath = srcLayer"+pp+".points()["+i+"]; \rsrcLayer.toComp(srcPath);"; nn.name=nm; nn.label=10;} } }); });
}
function pointsFollowNulls() {
    _addUndo("Points Follow Nulls", function() { PathNulls.forEachPath(function(comp,sl,path){ var ph=[]; var pp=PathNulls.getPropPath(path,ph); var ns=[]; var pts=PathNulls.getPathPoints(path); for(var i=0;i<pts.length;i++){var nm=sl.name+": "+path.parentProperty.name+" ["+ph.join(".")+"."+i+"]"; ns.push(nm); if(comp.layer(nm)==undefined){var nn=PathNulls.createNull(comp); nn.moveBefore(sl); nn.name=nm; nn.label=11; nn.position.setValue(pts[i]); nn.position.expression="var srcLayer = thisComp.layer(\""+sl.name+"\"); \rvar srcPath = srcLayer"+pp+".points()["+i+"]; \rsrcLayer.toComp(srcPath);"; nn.position.setValue(nn.position.value); nn.position.expression='';} } var ee=[]; PathNulls.forEachEffect(sl,function(fx){if(PathNulls.matchMatchName(fx,"ADBE Layer Control")!=null) ee.push(fx.name);}); for(var n=0;n<ns.length;n++){if(ee.join("|").indexOf(ns[n])!=-1){sl.property("ADBE Effect Parade")(ns[n]).property("ADBE Layer Control-0001").setValue(comp.layer(ns[n]).index);}else{var nc=sl.property("ADBE Effect Parade").addProperty("ADBE Layer Control"); nc.name=ns[n]; nc.property("ADBE Layer Control-0001").setValue(comp.layer(ns[n]).index);}} _handleExpression(path,"var nullLayerNames = [\""+ns.join("\",\"")+"\"];\rvar origPath = thisProperty;\rvar origPoints = origPath.points();\rvar origInTang = origPath.inTangents();\rvar origOutTang = origPath.outTangents();\rvar getNullLayers = [];\rfor (var i=0,il=nullLayerNames.length;i<il;i++){\r  try{ getNullLayers.push(effect(nullLayerNames[i])(\"ADBE Layer Control-0001\")); } catch(err){getNullLayers.push(null);}}\rfor (var i=0,il=getNullLayers.length;i<il;i++){\r  if(getNullLayers[i]!=null&&getNullLayers[i].index!=thisLayer.index){\r    origPoints[i]=fromCompToSurface(getNullLayers[i].toComp(getNullLayers[i].anchorPoint));}}\rcreatePath(origPoints,origInTang,origOutTang,origPath.isClosed());"); }); });
}
function tracePath() {
    _addUndo("Trace Path", function() { PathNulls.forEachPath(function(comp,sl,path){ var ph=[]; var pp=PathNulls.getPropPath(path,ph); var nn=PathNulls.createNull(comp); nn.moveBefore(sl); var nc=nn.property("ADBE Effect Parade").addProperty("Pseudo/ADBE Trace Path"); nc.property("Pseudo/ADBE Trace Path-0002").setValue(true); nc.property("Pseudo/ADBE Trace Path-0001").setValuesAtTimes([0,1],[0,100]); nc.property("Pseudo/ADBE Trace Path-0001").expression="if(thisProperty.propertyGroup(1)(\"Pseudo/ADBE Trace Path-0002\")==true&&thisProperty.numKeys>1){\rthisProperty.loopOut(\"cycle\");\r}else{\rvalue\r}"; nn.position.expression="var pathLayer = thisComp.layer(\""+sl.name+"\");\rvar progress = thisLayer.effect(\"Pseudo/ADBE Trace Path\")(\"Pseudo/ADBE Trace Path-0001\")/100;\rvar pathToTrace = pathLayer"+pp+";\rpathLayer.toComp(pathToTrace.pointOnPath(progress));"; nn.rotation.expression="var pathToTrace = thisComp.layer(\""+sl.name+"\")" + pp+";\rvar progress=thisLayer.effect(\"Pseudo/ADBE Trace Path\")(\"Pseudo/ADBE Trace Path-0001\")/100;\rvar pathTan=pathToTrace.tangentOnPath(progress);\rradiansToDegrees(Math.atan2(pathTan[1],pathTan[0]));"; nn.name="Trace "+sl.name+": "+path.parentProperty.name+" ["+ph.join(".")+"]"; nn.label=10; }); });
}

// ── BASIC TOOLS ──────────────────────────────────────────────
function addSolid() { app.executeCommand(2038); }

function addAdjLayer() {
    var c = app.project.activeItem; if(!c||!(c instanceof CompItem)) return "Select a comp!";
    _addUndo("Add Adj Layer", function() { var sel=c.selectedLayers; var l=c.layers.addSolid([1,1,1],"Adjustment Layer",c.width,c.height,c.pixelAspect,c.duration); l.adjustmentLayer=true; l.label=5; l.startTime=0; if(sel.length>0) l.moveBefore(sel[0]); });
}

// ── BOUNCE FIX ─────────────────────────────────────────────
function applyBazanBounce(doPos, doScale, doRot) {
    var comp = app.project.activeItem;
    if (!comp || !(comp instanceof CompItem)) return "لازم تفتح Composition الأول يا محمد بازان.";
    var layers = comp.selectedLayers;
    if (layers.length === 0) return "اختار لاير واحد على الأقل عشان نطبق عليه الـ Bounce.";

    var bPos = (doPos === true || doPos === "true");
    var bScale = (doScale === true || doScale === "true");
    var bRot = (doRot === true || doRot === "true");

    _addUndo("Apply Bazan Bounce", function() {
        var expr = "try {\n" +
        "    var amp = effect('Amplitude')('Slider') / 1000;\n" +
        "    var freq = effect('Frequency')('Slider');\n" +
        "    var decay = effect('Decay')('Slider');\n" +
        "    var floor = effect('Floor')('Checkbox');\n" +
        "    var n = 0, t = 0, v;\n" +
        "    if (numKeys > 0) {\n" +
        "        n = nearestKey(time).index;\n" +
        "        if (key(n).time > time) { n--; }\n" +
        "    }\n" +
        "    if (n == 0) { t = 0; } else { t = time - key(n).time; }\n" +
        "    if (n > 0) {\n" +
        "        v = velocityAtTime(key(n).time - thisComp.frameDuration / 10);\n" +
        "        if (floor == 1) {\n" +
        "            value + v * amp * -(Math.abs(Math.sin(freq * t * 2 * Math.PI)) / Math.exp(decay * t));\n" +
        "        } else {\n" +
        "            value + v * amp * (Math.sin(freq * t * 2 * Math.PI) / Math.exp(decay * t));\n" +
        "        }\n" +
        "    } else {\n" +
        "        value;\n" +
        "    }\n" +
        "} catch (err) {\n" +
        "    value;\n" +
        "}";

        function addEff(lyr, mName, dName, val) {
            var fx = lyr.property("Effects");
            if (!fx.property(dName)) {
                var f = fx.addProperty(mName);
                f.name = dName;
                if(f.property(1)) f.property(1).setValue(val);
            }
        }
        
        for (var i = 0; i < layers.length; i++) {
            var layer = layers[i];
            addEff(layer, "ADBE Slider Control", "Amplitude", 50);
            addEff(layer, "ADBE Slider Control", "Frequency", 3);
            addEff(layer, "ADBE Slider Control", "Decay", 5);
            addEff(layer, "ADBE Checkbox Control", "Floor", 0);
            
            if (bPos) _handleExpression(layer.property("Transform").property("Position"), expr, false, false);
            if (bScale) _handleExpression(layer.property("Transform").property("Scale"), expr, false, false);
            
            if (bRot) {
                // الكود ده هيجيب الـ Rotation المظبوط سواء اللاير 2D أو 3D
                var rProp = layer.property("Transform").property("Rotation");
                if (layer.threeDLayer && layer.property("Transform").property("Z Rotation")) {
                    rProp = layer.property("Transform").property("Z Rotation");
                }
                if (rProp) {
                    _handleExpression(rProp, expr, false, false);
                }
            }
        }
    });
    return "Done";
}
function addSmartNull() {
    var comp=app.project.activeItem; if(!comp) return "Select a comp!";
    _addUndo("Smart Parent Null", function() {
        var sel=comp.selectedLayers; if(sel.length===0){ var n=comp.layers.addNull(); n.name="Parent Null"; n.label=2; n.property("Anchor Point").setValue([50,50]); return; }
        var is3D=false; var avgX=0,avgY=0,avgZ=0; var count=sel.length; var minIdx=comp.numLayers+1;
        for(var i=0;i<count;i++){ if(sel[i].threeDLayer) is3D=true; if(sel[i].index<minIdx) minIdx=sel[i].index; var pos=sel[i].property("Position").value; avgX+=pos[0]; avgY+=pos[1]; if(pos.length>2) avgZ+=pos[2]; }
        var nl=comp.layers.addNull(); nl.name="Parent Null"; nl.threeDLayer=is3D; nl.label=2; nl.property("Anchor Point").setValue([50,50]);
        if(count>1){ if(is3D) nl.property("Position").setValue([comp.width/2,comp.height/2,0]); else nl.property("Position").setValue([comp.width/2,comp.height/2]); }
        else { if(is3D) nl.property("Position").setValue([avgX,avgY,avgZ]); else nl.property("Position").setValue([avgX,avgY]); }
        var tIdx=minIdx+1; if(nl.index!==tIdx&&nl.index!==tIdx-1) nl.moveBefore(comp.layer(tIdx));
        for(var j=0;j<count;j++) sel[j].parent=nl;
    });
}
function reverseLayers() {
    var comp=app.project.activeItem; if(!comp||comp.selectedLayers.length<2) return "Select 2+ layers!";
    _addUndo("Reverse Layers", function() { var sel=comp.selectedLayers.slice(0); sel.sort(function(a,b){return a.index-b.index;}); var top=sel[0]; for(var i=sel.length-1;i>0;i--) sel[i].moveBefore(top); });
}
function getLayerKeyTimes(layer) {
    var mn=999999,mx=-999999; function scan(g){for(var i=1;i<=g.numProperties;i++){var p=g.property(i); if(p.propertyType===PropertyType.PROPERTY&&p.canVaryOverTime&&p.numKeys>0){if(p.keyTime(1)<mn)mn=p.keyTime(1);if(p.keyTime(p.numKeys)>mx)mx=p.keyTime(p.numKeys);}else if(p.propertyType===PropertyType.INDEXED_GROUP||p.propertyType===PropertyType.NAMED_GROUP)scan(p);}} scan(layer); return(mn===999999)?null:{min:mn,max:mx};
}
function trimKeys(mode) {
    var comp=app.project.activeItem; if(!comp||comp.selectedLayers.length===0) return "Select layers with keyframes!";
    _addUndo("Trim Keys", function() {
        for(var i=0;i<comp.selectedLayers.length;i++){var k=getLayerKeyTimes(comp.selectedLayers[i]); if(!k) continue; if(mode==="in"||mode==="both") comp.selectedLayers[i].inPoint=k.min; if(mode==="out"||mode==="both") comp.selectedLayers[i].outPoint=k.max;}
    });
}
function addPrefix(prefix) { var d=_getCompSel(); if(!d) return; _addUndo("Add Prefix",function(){for(var i=0;i<d.layers.length;i++) d.layers[i].name=prefix+d.layers[i].name;}); }
function addSuffix(suffix) { var d=_getCompSel(); if(!d) return; _addUndo("Add Suffix",function(){for(var i=0;i<d.layers.length;i++) d.layers[i].name=d.layers[i].name+suffix;}); }
function renameLayers(prefix,suffix,base,useNum) {
    var d=_getCompSel(); if(!d) return;
    _addUndo("Base Rename",function(){ for(var i=0;i<d.layers.length;i++){var fn=base; if(useNum){var n=(i+1).toString(); if(n.length<2)n="0"+n; fn+=("_"+n);} d.layers[i].name=prefix+fn+suffix; } });
}

// ── COMPOSITIONS ─────────────────────────────────────────────
function preComposeSelected(compName, doCrop, doMask, pad) {
    var comp=app.project.activeItem; if(!comp||comp.selectedLayers.length===0) return "Select layers first!";
    _addUndo("Precompose & Crop", function() {
        var layers=comp.selectedLayers; var idx=[]; var minIn=layers[0].inPoint; var maxOut=layers[0].outPoint;
        for(var i=0;i<layers.length;i++){idx.push(layers[i].index); if(layers[i].inPoint<minIn)minIn=layers[i].inPoint; if(layers[i].outPoint>maxOut)maxOut=layers[i].outPoint;}
        var nC=comp.layers.precompose(idx,compName,true); var pL=comp.selectedLayers[0];
        nC.duration=maxOut-minIn; pL.startTime=minIn;
        for(var j=1;j<=nC.numLayers;j++) nC.layer(j).startTime-=minIn;
        if(doCrop){
            var et=comp.time-minIn; if(et<0||et>nC.duration)et=0;
            function getTrueBounds(lyr,t,rm){var b=lyr.sourceRectAtTime(t,false);var res={left:b.left,top:b.top,width:b.width,height:b.height};if(rm&&lyr.property("ADBE Mask Parade")&&lyr.property("ADBE Mask Parade").numProperties>0){var masks=lyr.property("ADBE Mask Parade");var hv=false;var mnX=Infinity,mnY=Infinity,mxX=-Infinity,mxY=-Infinity;for(var m=1;m<=masks.numProperties;m++){var mk=masks.property(m);if(mk.maskMode!==MaskMode.NONE){var sh=mk.property("ADBE Mask Shape").valueAtTime(t,false);var vts=sh.vertices;if(vts&&vts.length>0){hv=true;var inT=sh.inTangents;var oT=sh.outTangents;for(var v=0;v<vts.length;v++){var px=vts[v][0],py=vts[v][1];var ix=px+inT[v][0],iy=py+inT[v][1];var ox=px+oT[v][0],oy=py+oT[v][1];mnX=Math.min(mnX,px,ix,ox);mxX=Math.max(mxX,px,ix,ox);mnY=Math.min(mnY,py,iy,oy);mxY=Math.max(mxY,py,iy,oy);}try{var f=mk.property("ADBE Mask Feather").valueAtTime(t,false);mnX-=f[0];mxX+=f[0];mnY-=f[1];mxY+=f[1];}catch(e){}}}}if(hv){res.left=mnX;res.top=mnY;res.width=mxX-mnX;res.height=mxY-mnY;}}return res;}
            var mnX=999999,mnY=999999,mxX=-999999,mxY=-999999; var hv=false;
            var en=nC.layers.addNull(); en.name="Bazan_Temp_Scanner";
            for(var i=1;i<=nC.numLayers;i++){var l=nC.layer(i);if(l===en||!l.active||l.isNull||l.adjustmentLayer||l.camera||l.light||l.hasTrackMatte)continue;try{var rect=getTrueBounds(l,et,doMask);if(rect.width===0||rect.height===0)continue;var corners=[[rect.left,rect.top],[rect.left+rect.width,rect.top],[rect.left,rect.top+rect.height],[rect.left+rect.width,rect.top+rect.height]];for(var c=0;c<4;c++){en.property("Position").expression="try{thisComp.layer("+l.index+").toComp(["+corners[c][0]+","+corners[c][1]+",0],"+et+");}catch(e){[0,0,0];}";var p=en.property("Position").value;mnX=Math.min(mnX,p[0]);mnY=Math.min(mnY,p[1]);mxX=Math.max(mxX,p[0]);mxY=Math.max(mxY,p[1]);}hv=true;}catch(e){}}
            en.remove();
            if(hv&&mnX!==999999&&mxX>mnX&&mxY>mnY){var nW=Math.max(4,Math.ceil(mxX-mnX))+(pad*2);var nH=Math.max(4,Math.ceil(mxY-mnY))+(pad*2);var roots=[];var lkSt=[];var sn=nC.layers.addNull();sn.name="Temp Shift Null";for(var i=1;i<=nC.numLayers;i++){var lr=nC.layer(i);if(lr!==sn&&lr.parent==null){roots.push(lr);lkSt.push(lr.locked);if(lr.locked)lr.locked=false;lr.parent=sn;}}var nPos=sn.property("Position").value;sn.property("Position").setValue([nPos[0]-mnX+pad,nPos[1]-mnY+pad]);for(var i=0;i<roots.length;i++){roots[i].parent=null;if(lkSt[i])roots[i].locked=true;}sn.remove();nC.width=nW;nC.height=nH;pL.property("Anchor Point").setValue([nW/2,nH/2]);if(pL.threeDLayer){var pZ=pL.property("Position").value[2];pL.property("Position").setValue([mnX-pad+nW/2,mnY-pad+nH/2,pZ]);}else{pL.property("Position").setValue([mnX-pad+nW/2,mnY-pad+nH/2]);}}
        }
    });
}
function unPrecompose(doDelete) {
    var c=app.project.activeItem; if(!c||!(c instanceof CompItem)) return "Select a comp.";
    var sel=c.selectedLayers; if(sel.length===0) return "Select Pre-comps.";
    var pComps=[]; for(var i=0;i<sel.length;i++) if(sel[i].source instanceof CompItem) pComps.push(sel[i]);
    if(pComps.length===0) return "No valid Pre-comps selected.";
    _addUndo("Un-Precompose", function(){
        try{
            for(var p=pComps.length-1;p>=0;p--){var pL=pComps[p];var sC=pL.source;var tO=pL.startTime;sC.openInViewer();app.executeCommand(2004);var hL=false;for(var i=1;i<=sC.numLayers;i++){sC.layer(i).locked=false;sC.layer(i).selected=true;hL=true;}if(hL)app.executeCommand(19);c.openInViewer();app.executeCommand(2004);pL.selected=true;if(hL){app.executeCommand(20);var pst=c.selectedLayers;for(var i=0;i<pst.length;i++)if(pst[i]!==pL)pst[i].startTime+=(tO-sC.displayStartTime);var pRoots=[];for(var i=0;i<pst.length;i++){if(pst[i]===pL)continue;var iR=true;if(pst[i].parent!==null){for(var j=0;j<pst.length;j++)if(pst[i].parent===pst[j]){iR=false;break;}}if(iR)pRoots.push(pst[i]);}if(pRoots.length>0){var tn=c.layers.addNull(c.duration);tn.property("Anchor Point").setValue([0,0]);tn.property("Position").setValue([0,0]);for(var i=0;i<pRoots.length;i++)pRoots[i].parent=tn;tn.property("Anchor Point").setValue(pL.property("Anchor Point").value);tn.property("Position").setValue(pL.property("Position").value);tn.property("Scale").setValue(pL.property("Scale").value);tn.property("Rotation").setValue(pL.property("Rotation").value);if(pL.threeDLayer){tn.threeDLayer=true;tn.property("X Rotation").setValue(pL.property("X Rotation").value);tn.property("Y Rotation").setValue(pL.property("Y Rotation").value);tn.property("Z Rotation").setValue(pL.property("Z Rotation").value);if(pL.property("Orientation"))tn.property("Orientation").setValue(pL.property("Orientation").value);}for(var i=0;i<pRoots.length;i++)pRoots[i].parent=null;tn.remove();}}else{c.openInViewer();}if(doDelete){pL.remove();try{sC.remove();}catch(e){}}else{pL.enabled=false;pL.selected=false;}}
        }catch(err){return "Un-Precompose Error: "+err.toString();}
    });
}
function copyComp(copies, suffixBase) {
    var proj=app.project; if(!proj) return "No project.";
    var selItems=proj.selection; var compsToDupe=[];
    for(var i=0;i<selItems.length;i++) if(selItems[i] instanceof CompItem) compsToDupe.push(selItems[i]);
    if(compsToDupe.length===0) return "Select Comps in PROJECT PANEL.";
    function deepDup(orig,suf,map){if(map[orig.id])return map[orig.id];var nc=orig.duplicate();nc.name=orig.name.replace(/(_\d+)+$/,'')+suf;map[orig.id]=nc;for(var i=1;i<=nc.numLayers;i++){var l=nc.layer(i);if(l.source&&l.source instanceof CompItem){var np=deepDup(l.source,suf,map);l.replaceSource(np,true);}}return nc;}
    _addUndo("Multi-Copy Comp",function(){for(var c=0;c<compsToDupe.length;c++){for(var k=1;k<=copies;k++){var map={};var fs=suffixBase+(copies>1?k:"1");deepDup(compsToDupe[c],fs,map);}}});
    return "Done! Copied successfully.";
}

// ── TEXT BOX RIG ─────────────────────────────────────────────
function addTextBoxRig() {
    var comp=app.project.activeItem; if(!comp) return "Open a composition first!";
    _addUndo("Bazan Centered Box Rig", function(){
        comp.layers.addShape().name="Bazan Box";
        comp.layers.addText("New Text").name="Bazan Text";
        var cn=comp.layers.addNull(); cn.name="Bazan Controller"; cn.label=2;
        var tp=comp.layer("Bazan Text").property("ADBE Text Properties").property("ADBE Text Document");
        var td=tp.value; td.justification=ParagraphJustification.CENTER_JUSTIFY; tp.setValue(td);
        var fx=cn.property("ADBE Effect Parade");
        fx.addProperty("ADBE Slider Control").name="Progress %";
        fx.addProperty("ADBE Slider Control").name="Padding X";
        fx.addProperty("ADBE Slider Control").name="Padding Y";
        fx.addProperty("ADBE Slider Control").name="Roundness";
        cn.effect("Padding X")(1).setValue(80); cn.effect("Padding Y")(1).setValue(40); cn.effect("Roundness")(1).setValue(20);
        comp.layer("Bazan Text").property("ADBE Text Properties").property("ADBE Text Document").expression="var ctrl = thisComp.layer('Bazan Controller');\nvar p = clamp(ctrl.effect('Progress %')(1), 0, 100) / 100;\nvar str = value.toString();\nvar count = Math.round(str.length * p);\nvar res = str.substr(0, count);\nif(res == '') res = '\\u200B';\nres;";
        var vectors=comp.layer("Bazan Box").property("ADBE Root Vectors Group");
        var rg=vectors.addProperty("ADBE Vector Group"); rg.property("ADBE Vectors Group").addProperty("ADBE Vector Shape - Rect"); rg.property("ADBE Vectors Group").addProperty("ADBE Vector Graphic - Fill");
        var sg=comp.layer("Bazan Box").property("ADBE Root Vectors Group").property(1).property("ADBE Vectors Group");
        sg.property(2).property("ADBE Vector Fill Color").setValue([0.1,0.4,0.8]);
        sg.property(1).property("ADBE Vector Rect Roundness").expression="thisComp.layer('Bazan Controller').effect('Roundness')(1);";
        sg.property(1).property("ADBE Vector Rect Size").expression="var txt = thisComp.layer('Bazan Text');\nvar ctrl = thisComp.layer('Bazan Controller');\nvar dummy = txt.text.sourceText;\nvar px = ctrl.effect('Padding X')(1);\nvar py = ctrl.effect('Padding Y')(1);\nvar r = txt.sourceRectAtTime(time, false);\nif (r.width === 0) { [0, 0]; } else { [r.width + px, r.height + py]; }";
        sg.property(1).property("ADBE Vector Rect Position").expression="var txt = thisComp.layer('Bazan Text');\nvar dummy = txt.text.sourceText;\nvar r = txt.sourceRectAtTime(time, false);\nif (r.width === 0) { [0, 0]; } else { [r.left + r.width/2, r.top + r.height/2]; }";
        var cx=comp.width/2; var cy=comp.height/2;
        cn.property("ADBE Transform Group").property("ADBE Position").setValue([cx,cy]);
        comp.layer("Bazan Text").property("ADBE Transform Group").property("ADBE Position").setValue([cx,cy]);
        comp.layer("Bazan Box").property("ADBE Transform Group").property("ADBE Position").setValue([cx,cy]);
        cn.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([50,50]);
        comp.layer("Bazan Text").property("ADBE Transform Group").property("ADBE Anchor Point").setValue([0,0]);
        comp.layer("Bazan Box").property("ADBE Transform Group").property("ADBE Anchor Point").setValue([0,0]);
        comp.layer("Bazan Box").parent=comp.layer("Bazan Text");
        comp.layer("Bazan Text").parent=cn;
        cn.effect("Progress %")(1).setValue(100);
        for(var i=1;i<=comp.numLayers;i++) comp.layer(i).selected=false;
        cn.selected=true;
    });
}

// ── SRT IMPORT ───────────────────────────────────────────────
function importSRT(filePath) {
    var comp=app.project.activeItem; if(!comp||!(comp instanceof CompItem)) return "Select comp first!";
    var f=new File(filePath); if(!f.exists) return "File not found.";
    if(!f.open("r")) return "Failed to open.";
    var content=f.read(); f.close();
    function parseSrtTime(ts){var p=ts.replace(',','.').split(":");return(parseInt(p[0],10)*3600)+(parseInt(p[1],10)*60)+parseFloat(p[2]);}
    _addUndo("Import SRT",function(){content=content.replace(/\r\n/g,"\n").replace(/\r/g,"\n");var blocks=content.split(/\n\n+/);for(var i=0;i<blocks.length;i++){var block=blocks[i].replace(/^\s+|\s+$/g,'');if(block==="")continue;var lines=block.split("\n");if(lines.length>=3){var tp=lines[1].split(" --> ");if(tp.length===2){var st=parseSrtTime(tp[0]);var et=parseSrtTime(tp[1]);var tl=comp.layers.addText(lines.slice(2).join("\n"));tl.startTime=st;tl.inPoint=st;tl.outPoint=et;var rect=tl.sourceRectAtTime(st,false);tl.property("Anchor Point").setValue([rect.left+rect.width/2,rect.top+rect.height/2]);tl.property("Position").setValue([comp.width/2,comp.height*0.85]);}}}});
}

// ── TEXT DECOMPOSE ────────────────────────────────────────────
function decomposeText(splitMode, isRTL, isTopToBottom) {
    var comp=app.project.activeItem; if(!comp||!(comp instanceof CompItem)) return "A comp must be active.";
    var layers=comp.selectedLayers; if(layers.length===0) return "Please select a text layer.";
    _addUndo("Decompose Text",function(){
        function getTrueWidth(layer,textDoc,str,time){if(str==="")return 0;textDoc.text=str+"|";layer.property("ADBE Text Properties").property("ADBE Text Document").setValue(textDoc);var w1=layer.sourceRectAtTime(time,false).width;textDoc.text="|";layer.property("ADBE Text Properties").property("ADBE Text Document").setValue(textDoc);var w2=layer.sourceRectAtTime(time,false).width;return w1-w2;}
        function safeAddOffset(prop,diff){if(!prop||!prop.canSetExpression)return;var hk=prop.numKeys>0;var he=prop.expression!=="";if(!hk&&!he){var v=prop.value;if(v.length>=2){v[0]+=diff[0];v[1]+=diff[1];if(v.length>2&&diff.length>2)v[2]+=diff[2];}else{v+=diff[0];}prop.setValue(v);}else{var os=(prop.value.length===3)?"["+diff[0]+","+diff[1]+","+(diff[2]||0)+"]":"["+diff[0]+","+diff[1]+"]";if(he){var ce=prop.expression.replace(/\r\n/g,"\n");prop.expression="var _orig=(function(){\n"+ce+"\n})();\ntry{_orig+"+os+";}catch(e){value+"+os+";}";}else{prop.expression="value+"+os+";";}}}
        for(var lIdx=0;lIdx<layers.length;lIdx++){
            var layer=layers[lIdx]; if(!(layer instanceof TextLayer))continue;
            var textProp=layer.property("ADBE Text Properties").property("ADBE Text Document");
            var doc=textProp.value; if(doc.boxText)continue;
            var fullText=doc.text.replace(/\r\n/g,"\n").replace(/\r/g,"\n"); var lines=fullText.split("\n");
            var ml=layer.duplicate(); ml.name="Bazan_Measure"; ml.locked=false;
            if(ml.property("Source Text").canSetExpression)ml.property("Source Text").expression="";
            var mDoc=ml.property("ADBE Text Properties").property("ADBE Text Document").value;
            mDoc.justification=ParagraphJustification.LEFT_JUSTIFY;
            var lead=doc.autoLeading?doc.fontSize*1.2:doc.leading; var genL=[];
            for(var i=0;i<lines.length;i++){
                var lt=lines[i]; if(lt==="")continue; var yOff=i*lead; var chunks=[];
                if(splitMode===2)chunks.push({text:lt,prefix:""});
                else if(splitMode===1){var rx=/\S+/g;var m;while((m=rx.exec(lt))!==null)chunks.push({text:m[0],prefix:lt.substring(0,m.index)});}
                else{for(var cIdx=0;cIdx<lt.length;cIdx++)if(lt[cIdx]!==' '&&lt[cIdx]!=='\t')chunks.push({text:lt[cIdx],prefix:lt.substring(0,cIdx)});}
                if(chunks.length===0)continue;
                var tlw=getTrueWidth(ml,mDoc,lt,comp.time); var startX=0;
                if(doc.justification==ParagraphJustification.CENTER_JUSTIFY)startX=-tlw/2;
                else if(doc.justification==ParagraphJustification.RIGHT_JUSTIFY)startX=-tlw;
                for(var j=0;j<chunks.length;j++){
                    var ch=chunks[j]; var pw=getTrueWidth(ml,mDoc,ch.prefix,comp.time); var cw=getTrueWidth(ml,mDoc,ch.text,comp.time);
                    var csx=isRTL?startX+tlw-pw-cw:startX+pw; var cax=0;
                    if(doc.justification==ParagraphJustification.CENTER_JUSTIFY)cax=-cw/2;
                    else if(doc.justification==ParagraphJustification.RIGHT_JUSTIFY)cax=-cw;
                    var dX=csx-cax; var dY=yOff;
                    var nl=layer.duplicate(); nl.name=ch.text; nl.locked=false;
                    if(nl.property("Source Text").canSetExpression)nl.property("Source Text").expression="";
                    var nd=nl.property("ADBE Text Properties").property("ADBE Text Document").value; nd.text=ch.text; nl.property("ADBE Text Properties").property("ADBE Text Document").setValue(nd);
                    var oAP=nl.property("Anchor Point").value; var sAP=[oAP[0]-dX,oAP[1]-dY,oAP.length>2?oAP[2]:0];
                    var rect=nl.sourceRectAtTime(comp.time,false); var tAP=[rect.left+rect.width/2,rect.top+rect.height/2,sAP[2]];
                    var cPos=nl.property("Position").value; var sc=nl.property("Scale").value;
                    var aDX=tAP[0]-sAP[0]; var aDY=tAP[1]-sAP[1];
                    var nPX=cPos[0]+(aDX*(sc[0]/100)); var nPY=cPos[1]+(aDY*(sc[1]/100)); var nPZ=cPos.length>2?cPos[2]:0;
                    var offAP=[tAP[0]-oAP[0],tAP[1]-oAP[1],tAP.length>2?tAP[2]-(oAP[2]||0):0];
                    var offPos=[nPX-cPos[0],nPY-cPos[1],cPos.length>2?nPZ-(cPos[2]||0):0];
                    safeAddOffset(nl.property("Anchor Point"),offAP); safeAddOffset(nl.property("Position"),offPos);
                    nl.selected=false; genL.push(nl);
                }
            }
            ml.remove(); if(isRTL)genL.reverse();
            for(var k=0;k<genL.length;k++){if(isTopToBottom){if(k===0)genL[k].moveBefore(layer);else genL[k].moveAfter(genL[k-1]);}else{if(k===0)genL[k].moveAfter(layer);else genL[k].moveBefore(genL[k-1]);}}
            layer.enabled=false; layer.selected=false;
        }
    });
}

// ── NETWORK ROPES ─────────────────────────────────────────────
function networkRopes(typeIdx) {
    var comp = app.project.activeItem; 
    if(!comp || !(comp instanceof CompItem)) return "لازم تفتح كومبوزيشن الأول.";
    if(comp.selectedLayers.length < 2) return "اختار لايرين على الأقل يا هندسة.";

    var tIdx = parseInt(typeIdx, 10);
    if(isNaN(tIdx)) tIdx = 0;

    _addUndo("Network Ropes Pro", function() {
        var layers = comp.selectedLayers; 
        var conns = [];

        if (tIdx === 0) { 
            for (var i = 1; i < layers.length; i++) {
                conns.push({l1: layers[0], l2: layers[i]});
            }
        } else { 
            for (var i = 0; i < layers.length; i++) {
                for (var j = i + 1; j < layers.length; j++) {
                    conns.push({l1: layers[i], l2: layers[j]});
                }
            }
        }

        var cn = comp.layers.addNull(); 
        cn.name = "🎛️ Network Controller"; 
        cn.property("Anchor Point").setValue([50, 50]);
        if (cn.index > 1) cn.moveBefore(comp.layer(1));

        var fx = cn.property("Effects");
        var fc = fx.addProperty("ADBE Color Control"); fc.name = "Rope Color"; fc.property("Color").setValue([1, 1, 1]);
        var ft = fx.addProperty("ADBE Slider Control"); ft.name = "Stroke Thickness"; ft.property(1).setValue(4);
        var fs = fx.addProperty("ADBE Slider Control"); fs.name = "Trim Start %"; fs.property(1).setValue(0);
        var fe = fx.addProperty("ADBE Slider Control"); fe.name = "Trim End %"; fe.property(1).setValue(100);
        var fwh = fx.addProperty("ADBE Slider Control"); fwh.name = "Wave Height"; fwh.property(1).setValue(0);
        var fww = fx.addProperty("ADBE Slider Control"); fww.name = "Wave Width"; fww.property(1).setValue(40);
        var fws = fx.addProperty("ADBE Slider Control"); fws.name = "Wave Speed"; fws.property(1).setValue(1);

        for (var c = 0; c < conns.length; c++) {
            var l1 = conns[c].l1; 
            var l2 = conns[c].l2;
            var rl = comp.layers.addShape(); 
            rl.name = "Rope: " + l1.name + " -> " + l2.name;
            if (rl.index !== cn.index + 1) rl.moveAfter(cn);
            
            rl.property("Position").setValue([0, 0]); 
            rl.property("Anchor Point").setValue([0, 0]);
            
            var sg = rl.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group"); sg.name = "Rope Path";
            var pg = sg.property("ADBE Vectors Group").addProperty("ADBE Vector Shape - Group");
            var pp = pg.property("ADBE Vector Shape");
            
            // رجعنا للاسم الأصلي عشان الشيبس الجديدة متلخبطش الاندكس، مع دمج تعديل الـ 3D
            var n1 = l1.name.replace(/'/g, "\\'").replace(/"/g, '\\"');
            var n2 = l2.name.replace(/'/g, "\\'").replace(/"/g, '\\"');

            pp.expression = "var _l1 = thisComp.layer('" + n1 + "');\n" +
                            "var _l2 = thisComp.layer('" + n2 + "');\n" +
                            "var p1 = _l1.toComp(_l1.anchorPoint);\n" +
                            "var p2 = _l2.toComp(_l2.anchorPoint);\n" +
                            "createPath([[p1[0], p1[1]], [p2[0], p2[1]]], [], [], false);";

            var trim = sg.property("ADBE Vectors Group").addProperty("ADBE Vector Filter - Trim");
            trim.property("ADBE Vector Trim Start").expression = 'thisComp.layer("' + cn.name + '").effect("Trim Start %")(1);';
            trim.property("ADBE Vector Trim End").expression = 'thisComp.layer("' + cn.name + '").effect("Trim End %")(1);';
            
            var stk = sg.property("ADBE Vectors Group").addProperty("ADBE Vector Graphic - Stroke");
            stk.property("ADBE Vector Stroke Color").expression = 'thisComp.layer("' + cn.name + '").effect("Rope Color")(1);';
            stk.property("ADBE Vector Stroke Width").expression = 'thisComp.layer("' + cn.name + '").effect("Stroke Thickness")(1);';
            
            var wfx = rl.property("Effects").addProperty("ADBE Wave Warp");
            wfx.property("Wave Height").expression = 'thisComp.layer("' + cn.name + '").effect("Wave Height")(1);';
            wfx.property("Wave Width").expression = 'thisComp.layer("' + cn.name + '").effect("Wave Width")(1);';
            wfx.property("Wave Speed").expression = 'thisComp.layer("' + cn.name + '").effect("Wave Speed")(1);';
            
            rl.selected = false;
        }
        for(var j = 1; j <= comp.numLayers; j++) comp.layer(j).selected = false; 
        cn.selected = true;
    });
    
    return "Done";
}
// ── AROUND OBJECT ─────────────────────────────────────────────
function aroundObject() {
    _addUndo("Around Object Rig",function(){
        var comp=app.project.activeItem; if(!comp||!(comp instanceof CompItem)||comp.selectedLayers.length===0)return;
        var layers=comp.selectedLayers; var tx=0,ty=0;
        for(var i=0;i<layers.length;i++){var p=layers[i].property("Position").value;tx+=p[0];ty+=p[1];}
        var center=[tx/layers.length,ty/layers.length];
        var ctrl=comp.layers.addNull();ctrl.name="Radial Controller";ctrl.property("Anchor Point").setValue([50,50]);ctrl.position.setValue([center[0],center[1],0]);
        var fx=ctrl.property("Effects");
        fx.addProperty("ADBE Slider Control").name="Influence";ctrl.effect("Influence")(1).setValue(100);
        fx.addProperty("ADBE Slider Control").name="Radius";ctrl.effect("Radius")(1).setValue(300);
        fx.addProperty("ADBE Slider Control").name="Arc";ctrl.effect("Arc")(1).setValue(360);
        fx.addProperty("ADBE Angle Control").name="Start Angle";
        fx.addProperty("ADBE Slider Control").name="Random Offset";
        fx.addProperty("ADBE Slider Control").name="Random Seed";
        fx.addProperty("ADBE Checkbox Control").name="Orient to Center";
        fx.addProperty("ADBE Angle Control").name="Random Rotation";
        var is3D=false; for(var i=0;i<layers.length;i++)if(layers[i].threeDLayer)is3D=true;
        if(is3D){ctrl.threeDLayer=true;fx.addProperty("ADBE Angle Control").name="Tilt X";fx.addProperty("ADBE Angle Control").name="Tilt Y";fx.addProperty("ADBE Slider Control").name="Random Offset Z";}
        layers.sort(function(a,b){return a.index-b.index;});
        for(var i=0;i<layers.length;i++){
            var l=layers[i];l.parent=ctrl;
            var expr="var ctrl=thisLayer.parent;\nvar influence=ctrl.effect('Influence')(1)/100;\nvar radius=ctrl.effect('Radius')(1);\nvar arc=ctrl.effect('Arc')(1);\nvar startAngle=ctrl.effect('Start Angle')(1);\nvar randomOffset=ctrl.effect('Random Offset')(1);\nvar randomSeed=ctrl.effect('Random Seed')(1);\nvar siblings=[];for(var i=1;i<=thisComp.numLayers;i++){var lyr=thisComp.layer(i);if(lyr.hasParent&&lyr.parent.index==ctrl.index&&lyr.index!=ctrl.index)siblings.push(lyr.index);}\nsiblings.sort(function(a,b){return a-b;});var totalLayers=siblings.length;\nvar myIndex=0;for(var j=0;j<siblings.length;j++){if(siblings[j]==thisLayer.index){myIndex=j;break;}}\nvar blend=Math.max(0,Math.min(1,(arc-270)/90));\nvar angleStep=(totalLayers>1)?arc/(totalLayers-1+blend):0;\nvar angle=degreesToRadians(startAngle+(myIndex*angleStep));\nseedRandom(randomSeed+"+(i*1000)+",true);\nvar randOffset=(random()-0.5)*2*randomOffset;\nvar finalRadius=radius+randOffset;\nvar radialX=Math.cos(angle)*finalRadius;\nvar radialY=Math.sin(angle)*finalRadius;\n";
            if(is3D){expr+="var tiltX=degreesToRadians(ctrl.effect('Tilt X')(1));\nvar tiltY=degreesToRadians(ctrl.effect('Tilt Y')(1));\nvar randZ=(random()-0.5)*2*ctrl.effect('Random Offset Z')(1);\nvar y1=radialY*Math.cos(tiltX);var z1=radialY*Math.sin(tiltX);\nvar x2=radialX*Math.cos(tiltY)+z1*Math.sin(tiltY);\nvar z2=-radialX*Math.sin(tiltY)+z1*Math.cos(tiltY);\nvar radialPos=[x2,y1,z2+randZ];\n";}
            else{expr+="var radialPos=[radialX,radialY];\n";}
            expr+="linear(influence,0,1,value,radialPos);";
            _handleExpression(l.property("Position"),expr,false,false);
            var rExpr="var ctrl=thisLayer.parent;\nvar influence=ctrl.effect('Influence')(1)/100;\nvar arc=ctrl.effect('Arc')(1);\nvar startAngle=ctrl.effect('Start Angle')(1);\nvar orient=ctrl.effect('Orient to Center')(1);\nvar randomRotation=ctrl.effect('Random Rotation')(1);\nvar randomSeed=ctrl.effect('Random Seed')(1);\nvar siblings=[];for(var i=1;i<=thisComp.numLayers;i++){var lyr=thisComp.layer(i);if(lyr.hasParent&&lyr.parent.index==ctrl.index&&lyr.index!=ctrl.index)siblings.push(lyr.index);}\nsiblings.sort(function(a,b){return a-b;});var totalLayers=siblings.length;\nvar myIndex=0;for(var j=0;j<siblings.length;j++){if(siblings[j]==thisLayer.index){myIndex=j;break;}}\nvar blend=Math.max(0,Math.min(1,(arc-270)/90));\nvar angleStep=(totalLayers>1)?arc/(totalLayers-1+blend):0;\nvar radialAngle=startAngle+(myIndex*angleStep)+90;\nseedRandom(randomSeed+"+(i*1000)+",true);\nvar randRot=(random()-0.5)*2*randomRotation;\nvar targetRot=(orient==1)?radialAngle+randRot+value:value+randRot;\nlinear(influence,0,1,value,targetRot);";
            _handleExpression(l.property("Rotation"),rExpr,false,false);
        }
        for(var i=1;i<=comp.numLayers;i++)comp.layer(i).selected=false;ctrl.selected=true;
    });
}

// ── AUTO PATH RIG ─────────────────────────────────────────────
function createAutoPathRig(count) {
    var comp=app.project.activeItem; if(!comp)return "Select a comp first!";
    _addUndo("1-Click Path Rig",function(){
        var sL=comp.layers.addShape();sL.name="path";
        var sG=sL.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");sG.name="Ellipse 1";
        var pG=sG.property("ADBE Vectors Group").addProperty("ADBE Vector Shape - Group");pG.name="Path 1";
        var pathProp=pG.property("ADBE Vector Shape");
        var ns=new Shape();var w=comp.width*0.6;var h=comp.height*0.6;var kx=(w/2)*0.55228;var ky=(h/2)*0.55228;
        ns.vertices=[[0,-h/2],[w/2,0],[0,h/2],[-w/2,0]];
        ns.inTangents=[[-kx,0],[0,-ky],[kx,0],[0,ky]];
        ns.outTangents=[[kx,0],[0,ky],[-kx,0],[0,-ky]];
        ns.closed=true;pathProp.setValue(ns);
        var stk=sG.property("ADBE Vectors Group").addProperty("ADBE Vector Graphic - Stroke");stk.property("ADBE Vector Stroke Width").setValue(2);stk.property("ADBE Vector Stroke Color").setValue([1,1,1,1]);
        var ctrl=comp.layers.addNull();ctrl.name="controller";ctrl.property("Anchor Point").setValue([50,50]);
        var fx=ctrl.property("Effects");
        fx.addProperty("ADBE Checkbox Control").name="Enable Scale";ctrl.effect("Enable Scale")(1).setValue(1);
        fx.addProperty("ADBE Checkbox Control").name="Enable Rotation";ctrl.effect("Enable Rotation")(1).setValue(1);
        fx.addProperty("ADBE Slider Control").name="max distance";ctrl.effect("max distance")(1).setValue(200);
        fx.addProperty("ADBE Slider Control").name="min scale";ctrl.effect("min scale")(1).setValue(25);
        fx.addProperty("ADBE Slider Control").name="layers rotation";
        fx.addProperty("ADBE Slider Control").name="max scale";ctrl.effect("max scale")(1).setValue(40);
        fx.addProperty("ADBE Angle Control").name="rotation";
        fx.addProperty("ADBE Slider Control").name="Images Count";ctrl.effect("Images Count")(1).setValue(count);
        var exprPos='try{\n  var sc=thisComp.layer("controller");\n  var pLayer=thisComp.layer("path");\n  var el=pLayer.content("Ellipse 1").content("Path 1").path;\n  var r=sc.effect("rotation")(1);\n  var lc=Math.max(2,Math.min(30,sc.effect("Images Count")(1)));\n  var x=parseInt(thisLayer.name.split(" ")[1])-1;\n  if(isNaN(x))x=index;\n  var t=((x/lc)+(r/360))%1.0;\n  if(t<0)t+=1;\n  var pt=el.pointOnPath(t);\n  pLayer.toComp(pt);\n}catch(e){value;}';
        var exprScl='try{\n  var sc=thisComp.layer("controller");\n  if(sc.effect("Enable Scale")(1).value==1){\n    var distance=length(toWorld(transform.anchorPoint),sc.toWorld(sc.transform.anchorPoint));\n    var maxDist=sc.effect("max distance")(1);\n    var minS=sc.effect("min scale")(1);\n    var maxS=sc.effect("max scale")(1);\n    var scaleFactor=linear(distance,0,maxDist,maxS/100,minS/100);\n    [scaleFactor*100,scaleFactor*100];\n  }else{value;}\n}catch(e){value;}';
        var exprRot='try{\n  var sc=thisComp.layer("controller");\n  if(sc.effect("Enable Rotation")(1).value==1){\n    var el=thisComp.layer("path").content("Ellipse 1").content("Path 1").path;\n    var r=sc.effect("rotation")(1);\n    var lc=Math.max(2,Math.min(30,sc.effect("Images Count")(1)));\n    var x=parseInt(thisLayer.name.split(" ")[1])-1;\n    if(isNaN(x))x=index;\n    var t=((x/lc)+(r/360))%1.0;\n    if(t<0)t+=1;\n    var tan=el.tangentOnPath(t);\n    var angleRad=Math.atan2(tan[1],tan[0]);\n    var lr=sc.effect("layers rotation")(1);\n    radiansToDegrees(angleRad)+lr;\n  }else{value;}\n}catch(e){value;}';
        for(var i=count;i>=1;i--){
            var nc=app.project.items.addComp("Image "+i,1080,1080,1,comp.duration,comp.frameRate);
            nc.layers.addSolid([0.2,0.6,0.8],"Put Image Here",1080,1080,1);
            var nl=comp.layers.add(nc);nl.name="Image "+i;
            _handleExpression(nl.property("Position"),exprPos,false,false);
            _handleExpression(nl.property("Scale"),exprScl,false,false);
            _handleExpression(nl.property("Rotation"),exprRot,false,false);
        }
        ctrl.moveToBeginning();sL.moveToBeginning();
        for(var i=1;i<=comp.numLayers;i++)comp.layer(i).selected=false;ctrl.selected=true;
    });
}

// ── SPACE BETWEEN LAYERS ──────────────────────────────────────
function applySpaceXYZR(isCtrl) {
    var comp=app.project.activeItem; if(!comp)return;
    var selLayers=comp.selectedLayers.slice(0); if(selLayers.length===0)return "Select layers first!";
    _addUndo("Space X-Y-Z-R Link",function(){
        var l=comp.layer("X-Y-Z-R");
        if(!l){l=comp.layers.addNull();l.name="X-Y-Z-R";l.label=2;l.property("Anchor Point").setValue([50,50]);var fx=l.property("Effects");fx.addProperty("ADBE Slider Control").name="Space X";fx.addProperty("ADBE Slider Control").name="Space Y";fx.addProperty("ADBE Slider Control").name="Space Z";var sr=fx.addProperty("ADBE Slider Control");sr.name="Space Rotation";sr.property(1).setValue(0);}
        var minIdx=selLayers[0].index; for(var i=1;i<selLayers.length;i++)if(selLayers[i].index<minIdx)minIdx=selLayers[i].index;
        for(var i=0;i<selLayers.length;i++){
            var layer=selLayers[i]; layer.threeDLayer=true;
            var selIdx=i; // first selected = 0 → stays static
            var prop=layer.property("Transform").property("Position");
            if(isCtrl){if(prop.canSetExpression&&prop.expression!==""){var cv=prop.value;prop.expression="";prop.setValue(cv);}continue;}
            var expr='var sx=0,sy=0,sz=0,sr=0;\nvar spc=null;\ntry{\n  spc=thisComp.layer("X-Y-Z-R");\n  if(spc!=null){\n    var myRelIdx='+selIdx+';\n    sx=spc.effect("Space X")(1)*myRelIdx;\n    sy=spc.effect("Space Y")(1)*myRelIdx;\n    sz=spc.effect("Space Z")(1)*myRelIdx;\n    sr=spc.effect("Space Rotation")(1)*myRelIdx;\n  }\n}catch(e){}\nvar basePos=(value.length>=3)?value+[sx,sy,sz]:value+[sx,sy];\nif(spc!=null){\n  var nullPos=spc.toComp(spc.anchorPoint);\n  var vec=basePos-nullPos;\n  var rad=degreesToRadians(sr);\n  var cos=Math.cos(rad),sin=Math.sin(rad);\n  var nx=vec[0]*cos-vec[1]*sin;\n  var ny=vec[0]*sin+vec[1]*cos;\n  (basePos.length>=3)?[nullPos[0]+nx,nullPos[1]+ny,basePos[2]]:[nullPos[0]+nx,nullPos[1]+ny];\n}else{\n  basePos;\n}';
            _handleExpression(prop,expr,false,false);
            var rProp=layer.property("Transform").property("Rotation");
            if(layer.threeDLayer&&layer.property("Transform").property("Z Rotation"))rProp=layer.property("Transform").property("Z Rotation");
            var rExpr='try{\n  var spc=thisComp.layer("X-Y-Z-R");\n  value+(spc.effect("Space Rotation")(1)*'+selIdx+');\n}catch(e){value;}';
            _handleExpression(rProp,rExpr,false,false);
        }
    });
}

// ── PROXIMALLY SCALE ──────────────────────────────────────────
function applyProxScale(isCtrl) {
    var comp=app.project.activeItem; if(!comp)return "Select a comp first!";
    var selLayers=comp.selectedLayers.slice(0); if(selLayers.length===0)return "Select layers!";
    _addUndo("Null Scale",function(){
        var l=comp.layer("Effector");
        if(!l){l=comp.layers.addNull();l.name="Effector";l.property("Anchor Point").setValue([50,50]);var fx=l.property("Effects");fx.addProperty("ADBE Slider Control").name="Radius";l.effect("Radius")(1).setValue(100);fx.addProperty("ADBE Slider Control").name="Radius Strength";fx.addProperty("ADBE Slider Control").name="Scale To";l.effect("Scale To")(1).setValue(150);}
        var expr='var eff=null;\ntry{eff=thisComp.layer("Effector");}catch(e){}\nif(eff!=null){\n  var p1=thisLayer.toWorld(thisLayer.anchorPoint);\n  var p2=eff.toWorld(eff.anchorPoint);\n  var d=length(p1,p2);\n  var r=eff.effect("Radius")(1);\n  var rStr=eff.effect("Radius Strength")(1);\n  var valTo=eff.effect("Scale To")(1);\n  var valFrom=value[0];\n  var fVal=linear(d,r,rStr,valTo,valFrom);\n  if(value.length==3)[fVal,fVal,fVal];else[fVal,fVal];\n}else{value;}';
        for(var i=0;i<selLayers.length;i++){var sl=selLayers[i]; if(isCtrl){var p=sl.property("Transform").property("Scale");if(p.canSetExpression&&p.expression!==""){var cv=p.value;p.expression="";p.setValue(cv);}}else{_handleExpression(sl.property("Transform").property("Scale"),expr,false,false);}}
        if(!isCtrl){for(var i=1;i<=comp.numLayers;i++)comp.layer(i).selected=false;l.selected=true;}
    });
}

// ── UI STYLE (Z-POSITION & FX) ────────────────────────────────
function applyUIStyle(isShapeMode, isBake) {
    var comp = app.project.activeItem;
    if (!comp) return "Please select a comp first!";
    var selLayers = comp.selectedLayers.slice(0);
    if (selLayers.length === 0) return "Select layers to apply UI Style!";

    app.beginUndoGroup("Apply UI Style");
    
    try {
        function setExpr(prop, exprStr) {
            if (prop && prop.canSetExpression) prop.expression = exprStr;
        }

        function addOrGetFx(layerObj, matchName, fxName) {
            var fxGrp = layerObj.property("Effects");
            for (var e = 1; e <= fxGrp.numProperties; e++) {
                if (fxGrp.property(e).matchName === matchName) return fxGrp.property(e);
            }
            var newFx = fxGrp.addProperty(matchName);
            if (fxName) newFx.name = fxName;
            return newFx;
        }

        var ctrl = comp.layer("UI Controller");
        if (!ctrl) {
            ctrl = comp.layers.addNull();
            ctrl.name = "UI Controller";
            ctrl.label = 2;
            ctrl.property("Anchor Point").setValue([50, 50]);

            var fx = ctrl.property("Effects");
            
            fx.addProperty("ADBE Slider Control").name = "Range"; ctrl.effect("Range")(1).setValue(200);
            fx.addProperty("ADBE Checkbox Control").name = "Enable X"; ctrl.effect("Enable X")(1).setValue(0);
            fx.addProperty("ADBE Slider Control").name = "X Shift"; ctrl.effect("X Shift")(1).setValue(0);
            fx.addProperty("ADBE Checkbox Control").name = "Enable Y"; ctrl.effect("Enable Y")(1).setValue(0);
            fx.addProperty("ADBE Slider Control").name = "Y Shift"; ctrl.effect("Y Shift")(1).setValue(0);
            fx.addProperty("ADBE Checkbox Control").name = "Enable Z"; ctrl.effect("Enable Z")(1).setValue(1);
            fx.addProperty("ADBE Slider Control").name = "Z Shift"; ctrl.effect("Z Shift")(1).setValue(-200);
            fx.addProperty("ADBE Checkbox Control").name = "Enable Shadow"; ctrl.effect("Enable Shadow")(1).setValue(0);
            fx.addProperty("ADBE Slider Control").name = "Shdw Dist Max"; ctrl.effect("Shdw Dist Max")(1).setValue(45);
            fx.addProperty("ADBE Slider Control").name = "Shdw Opac Max"; ctrl.effect("Shdw Opac Max")(1).setValue(50);
            fx.addProperty("ADBE Slider Control").name = "Shdw Soft Max"; ctrl.effect("Shdw Soft Max")(1).setValue(11);
            fx.addProperty("ADBE Checkbox Control").name = "Enable Fade Opac"; ctrl.effect("Enable Fade Opac")(1).setValue(1);
            fx.addProperty("ADBE Slider Control").name = "Opac Radius"; ctrl.effect("Opac Radius")(1).setValue(200);
            fx.addProperty("ADBE Slider Control").name = "Opac Strength"; ctrl.effect("Opac Strength")(1).setValue(100);
            fx.addProperty("ADBE Checkbox Control").name = "Enable Col Shift"; ctrl.effect("Enable Col Shift")(1).setValue(0);
            fx.addProperty("ADBE Color Control").name = "End Color"; ctrl.effect("End Color")("Color").setValue([1,0,0,1]);
            fx.addProperty("ADBE Slider Control").name = "Color Radius"; ctrl.effect("Color Radius")(1).setValue(200);

            var bModeFx = fx.addProperty("ADBE Solid Composite");
            bModeFx.name = "Bazan Blend Mode";
            try { bModeFx.property("Opacity").setValue(0); } catch(e){}
        }

        var posExpr = "var offX=0, offY=0, offZ=0;\n" +
        "try{\n" +
        "  var ctrl = thisComp.layer('UI Controller');\n" +
        "  if(ctrl != null){\n" +
        "    var rng = ctrl.effect('Range')(1).value;\n" +
        "    var ctrlPos = ctrl.toWorld(ctrl.anchorPoint);\n" +
        "    var myPos = toWorld(anchorPoint);\n" +
        "    var d = length([myPos[0], myPos[1]], [ctrlPos[0], ctrlPos[1]]);\n" +
        "    var factor = ease(d, 0, rng, 1, 0);\n" +
        "    if(ctrl.effect('Enable X')(1).value) offX = factor * ctrl.effect('X Shift')(1).value;\n" +
        "    if(ctrl.effect('Enable Y')(1).value) offY = factor * ctrl.effect('Y Shift')(1).value;\n" +
        "    if(ctrl.effect('Enable Z')(1).value) offZ = factor * ctrl.effect('Z Shift')(1).value;\n" +
        "  }\n" +
        "}catch(e){}\n" +
        "(value.length >= 3) ? value + [offX, offY, offZ] : value + [offX, offY];";

        var opacExpr = "var ctrl=null;\ntry{ctrl=thisComp.layer('UI Controller');}catch(e){}\nif(ctrl!=null && ctrl.effect('Enable Fade Opac')(1).value){\n  var ctrlPos=ctrl.toWorld(ctrl.anchorPoint);\n  var myPos=toWorld(anchorPoint);\n  var dist=length([myPos[0],myPos[1]], [ctrlPos[0],ctrlPos[1]]);\n  var infl=linear(dist, 0, ctrl.effect('Opac Radius')(1).value, 1, 0);\n  linear(infl, 0, 1, 100 - clamp(ctrl.effect('Opac Strength')(1).value,0,100), 100);\n}else{value;}";

        var shdwDistExpr = "var ctrl=null;\ntry{ctrl=thisComp.layer('UI Controller');}catch(e){}\nif(ctrl!=null){\n  var rng=ctrl.effect('Range')(1).value;\n  var ctrlPos=ctrl.toWorld(ctrl.anchorPoint);\n  var myPos=toWorld(anchorPoint);\n  var d=length([myPos[0],myPos[1]], [ctrlPos[0],ctrlPos[1]]);\n  var factor=ease(d,0,rng,1,0);\n  linear(factor,0,1,0,ctrl.effect('Shdw Dist Max')(1).value);\n}else{value;}";

        var shdwOpacExpr = "var ctrl=null;\ntry{ctrl=thisComp.layer('UI Controller');}catch(e){}\nif(ctrl!=null){\n  if(ctrl.effect('Enable Shadow')(1).value){\n    var rng=ctrl.effect('Range')(1).value;\n    var ctrlPos=ctrl.toWorld(ctrl.anchorPoint);\n    var myPos=toWorld(anchorPoint);\n    var d=length([myPos[0],myPos[1]], [ctrlPos[0],ctrlPos[1]]);\n    var factor=ease(d,0,rng,1,0);\n    linear(factor,0,1,0,ctrl.effect('Shdw Opac Max')(1).value);\n  }else{0;}\n}else{value;}";

        var shdwSoftExpr = "var ctrl=null;\ntry{ctrl=thisComp.layer('UI Controller');}catch(e){}\nif(ctrl!=null){\n  var rng=ctrl.effect('Range')(1).value;\n  var ctrlPos=ctrl.toWorld(ctrl.anchorPoint);\n  var myPos=toWorld(anchorPoint);\n  var d=length([myPos[0],myPos[1]], [ctrlPos[0],ctrlPos[1]]);\n  var factor=ease(d,0,rng,1,0);\n  linear(factor,0,1,0,ctrl.effect('Shdw Soft Max')(1).value);\n}else{value;}";

        var shapeColExpr = "var ctrl=null;\ntry{ctrl=thisComp.layer('UI Controller');}catch(e){}\nif(ctrl!=null && ctrl.effect('Enable Col Shift')(1).value){\n  var ctrlPos=ctrl.toWorld(ctrl.anchorPoint);\n  var myPos=toWorld(anchorPoint);\n  var dist=length([myPos[0],myPos[1]], [ctrlPos[0],ctrlPos[1]]);\n  var infl=linear(dist, 0, ctrl.effect('Color Radius')(1).value, 1, 0);\n  linear(infl, 0, 1, value, ctrl.effect('End Color')(1).value);\n}else{value;}";

        function applyToShapeFills(layer, exprStr) {
            function scanGrp(grp) {
                for(var k=1; k<=grp.numProperties; k++) {
                    var p = grp.property(k);
                    if(p.matchName === "ADBE Vector Graphic - Fill") {
                        var cProp = p.property("Color");
                        if(cProp.canSetExpression) cProp.expression = exprStr;
                    } else if(p.propertyType === PropertyType.INDEXED_GROUP || p.propertyType === PropertyType.NAMED_GROUP) {
                        scanGrp(p);
                    }
                }
            }
            scanGrp(layer.property("ADBE Root Vectors Group"));
        }

        for (var i = 0; i < selLayers.length; i++) {
            var sl = selLayers[i];
            sl.threeDLayer = true;

            setExpr(sl.property("Transform").property("Position"), posExpr);
            setExpr(sl.property("Transform").property("Opacity"), opacExpr);

            if(isShapeMode) {
                if(sl instanceof ShapeLayer) {
                    applyToShapeFills(sl, shapeColExpr);
                } else {
                    alert("Layer '" + sl.name + "' is not a Shape Layer! Color Shift skipped.");
                }
            } else {
                var fillBlend = addOrGetFx(sl, "ADBE Solid Composite", "Color Shift Blend");
                if (fillBlend) {
                    var colExpr = "var cLayer=null;\ntry{cLayer=thisComp.layer(\"UI Controller\");}catch(e){}\nif(cLayer!=null && cLayer.effect(\"Enable Col Shift\")(1).value == 1){ cLayer.effect(\"End Color\")(1); } else { value; }";
                    var colOpacExpr = "var cLayer=null;\ntry{cLayer=thisComp.layer(\"UI Controller\");}catch(e){}\nif(cLayer!=null && cLayer.effect(\"Enable Col Shift\")(1).value == 1){\n  var dist=length([toWorld(anchorPoint)[0],toWorld(anchorPoint)[1]], cLayer.position);\n  var infl=linear(dist, 0, cLayer.effect(\"Color Radius\")(1), 1, 0);\n  linear(infl, 0, 1, 0, 100);\n}else{0;}";
                    var modeExpr = "try{\n  var ctrl = thisComp.layer('UI Controller');\n  if(ctrl.effect('Enable Col Shift')(1).value == 1){\n    ctrl.effect('Bazan Blend Mode')(4).value;\n  }else{\n    value;\n  }\n}catch(e){ value; }";

                    setExpr(fillBlend.property("Color"), colExpr);
                    setExpr(fillBlend.property("Opacity"), colOpacExpr);
                    setExpr(fillBlend.property(4), modeExpr);
                }
            }

            var dropFx = addOrGetFx(sl, "ADBE Drop Shadow", "Drop Shadow");
            if(dropFx) {
                dropFx.property("Direction").setValue(180);
                setExpr(dropFx.property("Distance"), shdwDistExpr);
                setExpr(dropFx.property("Opacity"), shdwOpacExpr);
                setExpr(dropFx.property("Softness"), shdwSoftExpr);
            }
        }

        if (isBake) {
        }

        for(var i=1; i<=comp.numLayers; i++) comp.layer(i).selected = false;
        ctrl.selected = true;

    } catch (err) {
        alert("Error applying UI Style: " + err.toString());
    }

    app.endUndoGroup();
}

// ── MASK SPLITTER ─────────────────────────────────────────────
function splitMasksToLayers() {
    var comp=app.project.activeItem; if(!comp||!(comp instanceof CompItem))return "Open a composition first.";
    var sel=comp.selectedLayers; if(sel.length===0)return "Select layers with masks.";
    _addUndo("Split Masks to Layers",function(){
        var lp=0;var nl=[];
        for(var i=0;i<sel.length;i++){var layer=sel[i];var masks=layer.property("ADBE Mask Parade");if(!masks||masks.numProperties===0)continue;var nm=masks.numProperties;lp++;for(var m=1;m<=nm;m++){var dl=layer.duplicate();dl.name=layer.name+" (Mask "+m+")";var dm=dl.property("ADBE Mask Parade");for(var j=nm;j>=1;j--){if(j!==m)dm.property(j).remove();}if(dm.numProperties>0)dm.property(1).maskMode=MaskMode.ADD;nl.push(dl);}layer.enabled=false;}
        for(var s=0;s<comp.selectedLayers.length;s++)comp.selectedLayers[s].selected=false;
        for(var k=0;k<nl.length;k++){nl[k].selected=true;app.executeCommand(3973);nl[k].selected=false;}
        if(lp===0)return "No Masks Found on selected layers.";
    });
}

// ── Z-SPACE ───────────────────────────────────────────────────
function executeDepth(lens, distribution, zOffset, createNull, isMove) {
    var activeComp=app.project.activeItem; if(!activeComp||!(activeComp instanceof CompItem))return "Select layers.";
    var layers=activeComp.selectedLayers; if(layers.length===0)return "Select layers.";
    var hH=activeComp.height/2;var hW=activeComp.width/2;
    layers.sort(function(a,b){return a.index-b.index;});
    var camFL=lens*0.02777777777778*hW*2; var curCamNull;
    _addUndo(isMove?"Z Space Move":"Z Space Disperse",function(){
        if(activeComp.activeCamera==null){
            var cam=activeComp.layers.addCamera(lens+"mm",[hW,hH]);cam.position.setValue([hW,hH,-camFL]);cam.Zoom.setValue(camFL);cam.focusDistance.setValue(camFL);
            if(createNull){var cn=activeComp.layers.addNull();cn.name="Camera Controller";cn.threeDLayer=true;cn.property("Anchor Point").setValue([50,50]);cn.position.setValue([hW,hH,-camFL]);cam.parent=cn;}
        }
        if(activeComp.activeCamera!==null){
            var curCam=activeComp.activeCamera;camFL=curCam.zoom.value;
            var tn=activeComp.layers.addNull();tn.threeDLayer=true;tn.position.setValue([0,0,0]);tn.setParentWithJump(curCam);tn.parent=null;
            if(!isMove)zOffset=zOffset-(tn.position.value[2]+camFL);else zOffset=zOffset-(camFL+tn.position.value[2]);tn.remove();
            curCamNull=activeComp.layers.addNull();curCamNull.threeDLayer=true;curCamNull.property("Anchor Point").setValue([50,50]);curCamNull.position.setValue([hW,hH,-(curCam.zoom.value)]);
        }
        var ig=0;
        for(var i=1;i<=layers.length;i++){
            var cl=layers[i-1];var zPos=isMove?zOffset:(i-1-ig)*distribution+zOffset;
            if(!(cl instanceof LightLayer)&&!(cl instanceof CameraLayer)){
                if(!cl.threeDLayer)cl.threeDLayer=true;
                if(cl.parent==null){var tn2=activeComp.layers.addNull();tn2.threeDLayer=true;cl.parent=tn2;tn2.position.setValue([hW,hH,zPos]);var ss=tn2.scale.value[2]+((tn2.scale.value[2]*zPos)/camFL);tn2.scale.setValue([ss,ss,ss]);tn2.remove();if(activeComp.activeCamera!==null&&curCamNull)cl.parent=curCamNull;}
                else ig++;
            }else ig++;
        }
        if(curCamNull){curCamNull.position.setValue([0,0,0]);if(activeComp.activeCamera!==null)curCamNull.setParentWithJump(activeComp.activeCamera);curCamNull.parent=null;curCamNull.remove();}
    });
}

// ── SMART FILL ────────────────────────────────────────────────
function applySmartFill(r1, g1, b1, r2, g2, b2, opac, isRemove) {
    _addUndo("Smart Fill",function(){
        var comp=app.project.activeItem; if(!comp||comp.selectedLayers.length===0)return;
        for(var i=0;i<comp.selectedLayers.length;i++){
            var fx=comp.selectedLayers[i].property("Effects");
            if(isRemove){if(fx.property("Color From"))fx.property("Color From").remove();if(fx.property("Color To"))fx.property("Color To").remove();if(fx.property("Color Transition %"))fx.property("Color Transition %").remove();if(fx.property("Bazan Fill"))fx.property("Bazan Fill").remove();continue;}
            if(fx.property("Color From")){fx.property("Color From").remove();fx.property("Color To").remove();fx.property("Color Transition %").remove();fx.property("Bazan Fill").remove();}
            var cF=fx.addProperty("ADBE Color Control");cF.name="Color From";cF.property("Color").setValue([r1,g1,b1,1]);
            var cT=fx.addProperty("ADBE Color Control");cT.name="Color To";cT.property("Color").setValue([r2,g2,b2,1]);
            fx.addProperty("ADBE Slider Control").name="Color Transition %";
            var fill=fx.addProperty("ADBE Fill");fill.name="Bazan Fill";
            if(fill.property("Opacity"))fill.property("Opacity").setValue(opac/100);
            if(fill.property("Color"))_handleExpression(fill.property("Color"),"var c1=effect('Color From')('Color');\nvar c2=effect('Color To')('Color');\nvar tr=clamp(effect('Color Transition %')(1),0,100);\nlinear(tr,0,100,c1,c2);",false,false);
        }
    });
}

// ── PULL IN AE ────────────────────────────────────────────────
function pullInAE(isGrouped) {
    var comp=app.project.activeItem; if(!comp||!(comp instanceof CompItem))return "Please open a Composition first!";
    var df=new File("~/Desktop/ai_to_ae_data.json"); if(!df.exists)return "No data found! Please push from Illustrator first.";
    df.open("r");var content=df.read();df.close();
    if(!content||content.length===0)return "Empty data file.";
    var td=[];try{td=eval("("+content+")");}catch(e){return "Data reading error!";}
    if(!td||td.length===0)return "No shapes found.";
    app.beginUndoGroup("Pull in AE");
    try{
        var mn=comp.layers.addNull();mn.name="AI Shapes Controller";mn.label=10;mn.property("Position").setValue([comp.width/2,comp.height/2]);
        var il=[];var mnX=999999,mnY=999999,mxX=-999999,mxY=-999999;
        function addVerts(pathData){for(var v=0;v<pathData.vertices.length;v++){var vx=pathData.vertices[v][0];var vy=pathData.vertices[v][1];if(vx<mnX)mnX=vx;if(vy<mnY)mnY=vy;if(vx>mxX)mxX=vx;if(vy>mxY)mxY=vy;}}
        function makePath(pathData){var ns=new Shape();ns.vertices=pathData.vertices;ns.inTangents=pathData.inTangents;ns.outTangents=pathData.outTangents;ns.closed=pathData.closed;return ns;}
        function addShapeToGroup(gc,data){for(var p=0;p<data.paths.length;p++){var pd=data.paths[p];var pg=gc.addProperty("ADBE Vector Shape - Group");pg.name="Path "+(p+1);pg.property("ADBE Vector Shape").setValue(makePath(pd));addVerts(pd);}if(data.hasFill){var fp=gc.addProperty("ADBE Vector Graphic - Fill");fp.property("ADBE Vector Fill Color").setValue(data.fillColor);}if(data.hasStroke){var sp=gc.addProperty("ADBE Vector Graphic - Stroke");sp.property("ADBE Vector Stroke Color").setValue(data.strokeColor);sp.property("ADBE Vector Stroke Width").setValue(data.strokeWidth);}}
        if(isGrouped){
            var groups={};var go=[];
            for(var i=0;i<td.length;i++){var d=td[i];var ln=d.layerName||d.layer||d.parentLayer;if(!ln||ln==="AI Layer"||ln==="undefined")ln=(d.name&&d.name!=="AI Layer")?d.name:"Shape "+(i+1);if(!groups[ln]){groups[ln]=[];go.push(ln);}groups[ln].push(d);}
            for(var g=go.length-1;g>=0;g--){var sl=comp.layers.addShape();sl.name=go[g];sl.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([0,0]);sl.property("ADBE Transform Group").property("ADBE Position").setValue([comp.width/2,comp.height/2]);il.push(sl);var tr=sl.property("ADBE Root Vectors Group");var shapes=groups[go[g]];for(var idx=0;idx<shapes.length;idx++){var mg=tr.addProperty("ADBE Vector Group");mg.name=(shapes[idx].name&&shapes[idx].name!=="AI Layer")?shapes[idx].name:"Group "+(idx+1);addShapeToGroup(mg.property(2),shapes[idx]);}}
        }else{
            for(var i=td.length-1;i>=0;i--){var d=td[i];var sl=comp.layers.addShape();sl.name=(d.name&&d.name!=="AI Layer")?d.name:"Shape "+(i+1);sl.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([0,0]);sl.property("ADBE Transform Group").property("ADBE Position").setValue([comp.width/2,comp.height/2]);il.push(sl);var tr=sl.property("ADBE Root Vectors Group");var mg=tr.addProperty("ADBE Vector Group");mg.name="Contents";addShapeToGroup(mg.property(2),d);}
        }
        var tw=mxX-mnX;var th=mxY-mnY;
        if(tw>0&&th>0){var sx=(comp.width/tw)*100;var sy=(comp.height/th)*100;var fs=Math.min(sx,sy);var cx=mnX+(tw/2);var cy=mnY+(th/2);mn.property("Anchor Point").setValue([cx,cy]);mn.property("Scale").setValue([fs,fs]);}
        for(var k=0;k<il.length;k++){il[k].parent=mn;il[k].selected=true;}
        mn.moveToBeginning();mn.selected=true;
    }catch(err){app.endUndoGroup();return "Error: "+err.toString();}
    app.endUndoGroup();return "ok";
}

function applyNumberScript(withComma, selSym, pos, customTxt) { 
    var comp = app.project.activeItem; 
    if (!comp || !(comp instanceof CompItem)) return alert("Select comp."); 
    var sel = comp.selectedLayers; 
    if(sel.length === 0) return alert("Select Text layer."); 
    
    // تحويل البيانات لضمان إنها تتقري صح من الواجهة
    var isComma = (withComma === true || withComma === "true");
    var posIndex = parseInt(pos);

    var finalSym = "";
    if (customTxt && customTxt !== "") {
        finalSym = customTxt;
    } else if (selSym !== "None" && selSym !== "") {
        finalSym = selSym;
    }
    
    app.beginUndoGroup("Apply Numbers");
    try {
        for(var i=0; i<sel.length; i++) { 
            var layer = sel[i]; 
            if(!(layer instanceof TextLayer)) continue; 
            
            var textProp = layer.property("Source Text"); 
            var fx = layer.property("Effects"); 
            
            if(fx.property("Symbol Right Position")) {
                fx.property("Symbol Right Position").remove();
            }

            var sld = fx.property("Slider Control") || fx.addProperty("ADBE Slider Control"); 
            sld.name = "Slider Control"; 
            
            var expr = 'var n = effect("Slider Control")(1);\n'; 
            if (isComma) { 
                expr += 'function addCommas(num) { var s = Math.floor(num).toString(); var res = ""; var c = 0; for(var j=s.length-1; j>=0; j--){ res = s[j] + res; c++; if(c%3==0 && j!=0) res = "," + res; } return res; }\n'; 
                expr += 'var valStr = addCommas(n);\n'; 
            } else { 
                expr += 'var valStr = Math.round(n).toString();\n'; 
            } 
            
            if (finalSym !== "") { 
                var symEscaped = finalSym.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n');
                expr += 'var mySym = "' + symEscaped + '";\n';
                
                if (posIndex === 0) { 
                   expr += '"\\u202D" + mySym + " " + valStr + "\\u202C";'; 
                } else {         
                    expr += '"\\u202D" + valStr + " " + mySym + "\\u202C";'; 
                }
            } else { 
                expr += 'valStr;'; 
            } 
            
            if (textProp.canSetExpression) {
                textProp.expression = expr; 
            }
        } 
    } catch(err) {
        alert("Error: " + err.toString());
    } finally {
        app.endUndoGroup();
    }
}

function applyNewtonLauncherScript() {
    var comp = app.project.activeItem;
    
    // تأكد إن فيه كومبوزيشن مفتوح وفيه لايرات مختارة
    if (!comp || !(comp instanceof CompItem)) {
        alert("Please select a Composition and some Layers first!");
        return;
    }

    if (comp.selectedLayers.length === 0) {
        alert("Select at least one layer to use with Newton!");
        return;
    }

    // قايمة الأسماء اللي جربناها واشتغلت معاك
    var possibleNames = ["Newton", "Newton ", "Newton...", "Newton…", "Newton 4", "Newton 4...", "Newton 4…"];
    var newtonCmd = 0;

    for (var i = 0; i < possibleNames.length; i++) {
        newtonCmd = app.findMenuCommandId(possibleNames[i]);
        if (newtonCmd !== 0) break;
    }

    if (newtonCmd !== 0) {
        // قبل ما يفتح نيوتن، بنعمل "تنشيط" للكومب عشان نيوتن يلقط الاختيار
        comp.openInViewer(); 
        app.executeCommand(newtonCmd);
    } else {
        alert("Newton Plugin not found!");
    }
}