(function(thisObj) {
    function buildUI(thisObj) {
        var win = (thisObj instanceof Panel) ? thisObj : new Window("palette", "Bazan Pro Kit V3.16 🚀", undefined, {resizeable: true});
        win.orientation = "column"; 
        win.alignChildren = ["fill", "top"];
        win.spacing = 0; win.margins = 2;

        var headerGroup = win.add("group");
        headerGroup.orientation = "column"; headerGroup.alignChildren = ["center", "center"]; headerGroup.alignment = ["fill", "top"]; headerGroup.spacing = 0; headerGroup.margins = [0, 0, 0, 4];
        var brandingText = headerGroup.add("statictext", undefined, "✨ BAZAN PRO KIT V3.16 ✨");
        brandingText.graphics.font = ScriptUI.newFont("Verdana", "BOLD", 18); 
        brandingText.graphics.foregroundColor = brandingText.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [1, 0.65, 0.1, 1], 1); 

        var topDivider = win.add("panel", [0,0,100,2], undefined); topDivider.alignment = ["fill", "top"];

        // ==========================================
        // SMART HELPERS & BULLETPROOF UNDO SYSTEM
        // ==========================================
        var undoDepth = 0;
        function addUndo(name, func) {
            var groupStarted = false;
            if (undoDepth === 0) { app.beginUndoGroup(name); groupStarted = true; }
            undoDepth++;
            try { func(); } catch(e) { /* Silent fail */ } 
            finally { undoDepth--; if (groupStarted && undoDepth === 0) { app.endUndoGroup(); } }
        }
        
        function forceRedraw(element) { if(element) { element.hide(); element.show(); } }
        
        function handleExpression(prop, exprStr) {
            if (!prop || !prop.canSetExpression) return;
            var isCtrl = ScriptUI.environment.keyboardState.ctrlKey;
            var isAlt = ScriptUI.environment.keyboardState.altKey;
            if (isAlt) { prop.expression = ""; } else if (isCtrl) {
                if (prop.expression !== "") { var curVal = prop.value; prop.expression = ""; prop.setValue(curVal); }
            } else { prop.expression = exprStr; }
        }

        function manageEffect(layer, matchName, displayName) {
            var fx = layer.property("Effects");
            var existingFx = fx.property(displayName);
            if (!existingFx) { 
                var newFx = fx.addProperty(matchName); 
                newFx.name = displayName; 
                return newFx; 
            }
            return existingFx;
        }

        function getCompAndSelection() { var comp = app.project.activeItem; if (!comp || !(comp instanceof CompItem)) { alert("Please select a composition first!"); return null; } var sel = comp.selectedLayers; if (sel.length === 0) { alert("Please select at least one layer!"); return null; } return { comp: comp, layers: sel }; }

        // --- PATH NULLS SYSTEM ---
        var PathNulls = {};
        PathNulls.getActiveComp = function() { return app.project.activeItem; };
        PathNulls.getSelectedLayers = function(c) { return c.selectedLayers; };
        PathNulls.createNull = function(c) { var n = c.layers.addNull(); n.property("Anchor Point").setValue([50, 50]); return n; };
        PathNulls.getSelectedProperties = function(l) { var p = l.selectedProperties; return (p.length < 1) ? null : p; };
        PathNulls.forEachLayer = function(arr, fn) { for (var i = 0; i < arr.length; i++) fn(arr[i]); };
        PathNulls.forEachProperty = function(arr, fn) { for (var i = 0; i < arr.length; i++) fn(arr[i]); };
        PathNulls.forEachEffect = function(l, fn) { for (var i = 1; i <= l.property("ADBE Effect Parade").numProperties; i++) fn(l.property("ADBE Effect Parade").property(i)); };
        PathNulls.matchMatchName = function(fx, name) { return (fx != null && fx.matchName === name) ? fx : null; };
        PathNulls.getPropPath = function(currentProp, pathHierarchy) { var pathPath = ""; while (currentProp.parentProperty !== null) { if (currentProp.parentProperty.propertyType === PropertyType.INDEXED_GROUP) { pathHierarchy.unshift(currentProp.propertyIndex); pathPath = "(" + currentProp.propertyIndex + ")" + pathPath; } else { pathPath = "(\"" + currentProp.matchName.toString() + "\")" + pathPath; } currentProp = currentProp.parentProperty; } return pathPath; };
        PathNulls.getPathPoints = function(path) { return path.value.vertices; };
        PathNulls.forEachPath = function(doSomething) { var comp = PathNulls.getActiveComp(); if (!comp) return; var selectedLayers = PathNulls.getSelectedLayers(comp); if (!selectedLayers) return; var selectedPaths = []; var parentLayers = []; PathNulls.forEachLayer(selectedLayers, function(selectedLayer) { var paths = PathNulls.getSelectedProperties(selectedLayer); if (!paths) return; PathNulls.forEachProperty(paths, function(path) { if (PathNulls.matchMatchName(path, "ADBE Vector Shape") != null || PathNulls.matchMatchName(path, "ADBE Mask Shape") != null) { selectedPaths.push(path); parentLayers.push(selectedLayer); } }); }); if (selectedPaths.length == 0) return alert("Error: No paths selected."); for (var p = 0; p < selectedPaths.length; p++) doSomething(comp, parentLayers[p], selectedPaths[p]); };
        PathNulls.linkNullsToPoints = function() { addUndo("Nulls Follow Points", function() { PathNulls.forEachPath(function(comp, selectedLayer, path) { var pathHierarchy = []; var pathPath = PathNulls.getPropPath(path, pathHierarchy); var pathPoints = PathNulls.getPathPoints(path); for (var i = 0; i < pathPoints.length; i++) { var nullName = selectedLayer.name + ": " + path.parentProperty.name + " [" + pathHierarchy.join(".") + "." + i + "]"; if (comp.layer(nullName) == undefined) { var newNull = PathNulls.createNull(comp); newNull.moveBefore(selectedLayer); newNull.position.setValue(pathPoints[i]); newNull.position.expression = "var srcLayer = thisComp.layer(\"" + selectedLayer.name + "\"); \r" + "var srcPath = srcLayer" + pathPath + ".points()[" + i + "]; \r" + "srcLayer.toComp(srcPath);"; newNull.name = nullName; newNull.label = 10; } } }); }); };
        PathNulls.linkPointsToNulls = function() { addUndo("Points Follow Nulls", function() { PathNulls.forEachPath(function(comp, selectedLayer, path) { var pathHierarchy = []; var pathPath = PathNulls.getPropPath(path, pathHierarchy); var nullSet = []; var pathPoints = PathNulls.getPathPoints(path); for (var i = 0; i < pathPoints.length; i++) { var nullName = selectedLayer.name + ": " + path.parentProperty.name + " [" + pathHierarchy.join(".") + "." + i + "]"; nullSet.push(nullName); if (comp.layer(nullName) == undefined) { var newNull = PathNulls.createNull(comp); newNull.moveBefore(selectedLayer); newNull.name = nullName; newNull.label = 11; newNull.position.setValue(pathPoints[i]); newNull.position.expression = "var srcLayer = thisComp.layer(\"" + selectedLayer.name + "\"); \r" + "var srcPath = srcLayer" + pathPath + ".points()[" + i + "]; \r" + "srcLayer.toComp(srcPath);"; newNull.position.setValue(newNull.position.value); newNull.position.expression = ''; } } var existingEffects = []; PathNulls.forEachEffect(selectedLayer, function(targetEffect) { if (PathNulls.matchMatchName(targetEffect, "ADBE Layer Control") != null) existingEffects.push(targetEffect.name); }); for (var n = 0; n < nullSet.length; n++) { if (existingEffects.join("|").indexOf(nullSet[n]) != -1) { selectedLayer.property("ADBE Effect Parade")(nullSet[n]).property("ADBE Layer Control-0001").setValue(comp.layer(nullSet[n]).index); } else { var newControl = selectedLayer.property("ADBE Effect Parade").addProperty("ADBE Layer Control"); newControl.name = nullSet[n]; newControl.property("ADBE Layer Control-0001").setValue(comp.layer(nullSet[n]).index); } } handleExpression(path, "var nullLayerNames = [\"" + nullSet.join("\",\"") + "\"]; \rvar origPath = thisProperty; \rvar origPoints = origPath.points(); \rvar origInTang = origPath.inTangents(); \rvar origOutTang = origPath.outTangents(); \rvar getNullLayers = []; \rfor (var i = 0, il = nullLayerNames.length; i < il; i++){ \r  try{ getNullLayers.push(effect(nullLayerNames[i])(\"ADBE Layer Control-0001\")); } catch(err) { getNullLayers.push(null); }} \rfor (var i = 0, il = getNullLayers.length; i < il; i++){ \r  if (getNullLayers[i] != null && getNullLayers[i].index != thisLayer.index){ \r    origPoints[i] = fromCompToSurface(getNullLayers[i].toComp(getNullLayers[i].anchorPoint)); }} \rcreatePath(origPoints,origInTang,origOutTang,origPath.isClosed());"); }); }); };
        PathNulls.tracePath = function() { addUndo("Trace Path", function() { PathNulls.forEachPath(function(comp, selectedLayer, path) { var pathHierarchy = []; var pathPath = PathNulls.getPropPath(path, pathHierarchy); var newNull = PathNulls.createNull(comp); newNull.moveBefore(selectedLayer); var nullControl = newNull.property("ADBE Effect Parade").addProperty("Pseudo/ADBE Trace Path"); nullControl.property("Pseudo/ADBE Trace Path-0002").setValue(true); nullControl.property("Pseudo/ADBE Trace Path-0001").setValuesAtTimes([0,1],[0,100]); nullControl.property("Pseudo/ADBE Trace Path-0001").expression = "if(thisProperty.propertyGroup(1)(\"Pseudo/ADBE Trace Path-0002\") == true && thisProperty.numKeys > 1){ \rthisProperty.loopOut(\"cycle\"); \r} else { \rvalue \r}"; newNull.position.expression = "var pathLayer = thisComp.layer(\"" + selectedLayer.name + "\"); \rvar progress = thisLayer.effect(\"Pseudo/ADBE Trace Path\")(\"Pseudo/ADBE Trace Path-0001\")/100; \rvar pathToTrace = pathLayer" + pathPath + "; \rpathLayer.toComp(pathToTrace.pointOnPath(progress));"; newNull.rotation.expression = "var pathToTrace = thisComp.layer(\"" + selectedLayer.name + "\")" + pathPath + "; \rvar progress = thisLayer.effect(\"Pseudo/ADBE Trace Path\")(\"Pseudo/ADBE Trace Path-0001\")/100; \rvar pathTan = pathToTrace.tangentOnPath(progress); \rradiansToDegrees(Math.atan2(pathTan[1],pathTan[0]));"; newNull.name = "Trace " + selectedLayer.name + ": " + path.parentProperty.name + " [" + pathHierarchy.join(".") + "]"; newNull.label = 10; }); }); };

        // --- PRESETS SAVING LOGIC ---
        var easeSettingsSection = "BazanProEase_V5"; var easeSettingsKey = "SavedPresets"; var activePresetIndex = -1; 
        function getSavedPresets() { if (app.settings.haveSetting(easeSettingsSection, easeSettingsKey)) { var str = app.settings.getSetting(easeSettingsSection, easeSettingsKey); if (str !== "") return str.split("|"); } return []; }
        function savePresets(arr) { app.settings.saveSetting(easeSettingsSection, easeSettingsKey, arr.join("|")); }
        function drawExactSpeedCurve(g, w, h, inInf, outInf, color, thickness, isMini) { var outVal = Math.max(0.001, outInf / 100); var inVal = Math.max(0.001, inInf / 100); g.newPath(); var started = false; var paddingX = isMini ? 1 : 0; var paddingY = isMini ? 1 : 0; var effW = w - paddingX * 2; var effH = h - paddingY * 2; var scaleDiv = isMini ? 2.5 : 3.2; for (var t = 0; t <= 1.001; t += 0.02) { var ct = Math.min(1, t); var mt = 1 - ct; var valX = 3 * mt * mt * ct * outVal + 3 * mt * ct * ct * (1 - inVal) + ct * ct * ct; var px = paddingX + valX * effW; var dydt = 6 * ct * mt; var dxdt = 3 * outVal * mt * (1 - 3*ct) + 3 * (1 - inVal) * ct * (2 - 3*ct) + 3 * ct * ct; var speed = (dxdt === 0) ? 0 : Math.abs(dydt / dxdt); var py = (h - paddingY) - (speed * (effH / scaleDiv)); py = Math.max(paddingY, Math.min(h - paddingY, py)); if (!started) { g.moveTo(px, py); started = true; } else { g.lineTo(px, py); } } g.strokePath(g.newPen(g.PenType.SOLID_COLOR, color, thickness)); }
        function applyEaseKeys(inV, outV) { var comp = app.project.activeItem; if (!comp) return; var sel = comp.selectedProperties; addUndo("Apply Speed", function() { for (var i = 0; i < sel.length; i++) { var p = sel[i]; if (!p.canVaryOverTime) continue; for (var j = 0; j < p.selectedKeys.length; j++) { var kIdx = p.selectedKeys[j]; p.setInterpolationTypeAtKey(kIdx, KeyframeInterpolationType.BEZIER); var inEases = p.keyInTemporalEase(kIdx); var outEases = p.keyOutTemporalEase(kIdx); var inArr = [], outArr = []; for (var d = 0; d < inEases.length; d++) inArr.push(new KeyframeEase(0, inV)); for (var d = 0; d < outEases.length; d++) outArr.push(new KeyframeEase(0, outV)); p.setTemporalEaseAtKey(kIdx, inArr, outArr); } } }); }

        // ==========================================
        // UI TABS 
        // ==========================================
        var tPanel = win.add("tabbedpanel"); tPanel.alignChildren = ["fill", "top"]; tPanel.alignment = ["fill", "top"];
        tPanel.margins = 0; tPanel.spacing = 0; 
        
        var pnlMargins = [4, 15, 4, 4]; 

        var vBasic = tPanel.add("tab", undefined, "🛠️ Basics"); vBasic.orientation = "column"; vBasic.alignChildren = ["fill", "top"]; vBasic.spacing = 2; vBasic.margins = 4;
        var vProx = tPanel.add("tab", undefined, "🎯 Prox & Rigs"); vProx.orientation = "column"; vProx.alignChildren = ["fill", "top"]; vProx.spacing = 2; vProx.margins = 4;
        var vZSpace = tPanel.add("tab", undefined, "🌌 Space & Fill"); vZSpace.orientation = "column"; vZSpace.alignChildren = ["fill", "top"]; vZSpace.spacing = 2; vZSpace.margins = 4;

        // =========================================================
        // TAB 1: BASICS & EASE
        // =========================================================
        var pnlEase = vBasic.add("panel", undefined, "Live Control"); pnlEase.alignChildren = ["fill", "top"]; pnlEase.margins = pnlMargins; pnlEase.spacing = 4;
        var topEaseSection = pnlEase.add("group"); topEaseSection.orientation = "row"; topEaseSection.alignChildren = ["left", "top"]; topEaseSection.spacing = 6; 
        
        var graphGroup = topEaseSection.add("group"); graphGroup.alignment = ["left", "top"]; 
        var mainGraph = graphGroup.add("custombutton", undefined, ""); mainGraph.preferredSize = [100, 70]; 
        
        var controlsRow = topEaseSection.add("group"); controlsRow.orientation = "column"; controlsRow.alignChildren = ["left", "top"]; controlsRow.spacing = 2; 
        
        var sliderRow1 = controlsRow.add("group"); sliderRow1.orientation = "row"; sliderRow1.spacing = 2; sliderRow1.alignChildren = ["left", "center"]; var lblIn = sliderRow1.add("statictext", undefined, "In:"); lblIn.preferredSize.width = 20; var valIn = sliderRow1.add("edittext", undefined, "33"); valIn.preferredSize = [40, 22]; valIn.justify = "center"; var sldIn = sliderRow1.add("slider", undefined, 33, 0.1, 100); sldIn.preferredSize = [80, 12];
        var sliderRow2 = controlsRow.add("group"); sliderRow2.orientation = "row"; sliderRow2.spacing = 2; sliderRow2.alignChildren = ["left", "center"]; var lblOut = sliderRow2.add("statictext", undefined, "Out:"); lblOut.preferredSize.width = 20; var valOut = sliderRow2.add("edittext", undefined, "33"); valOut.preferredSize = [40, 22]; valOut.justify = "center"; var sldOut = sliderRow2.add("slider", undefined, 33, 0.1, 100); sldOut.preferredSize = [80, 12];
        
        var btnActionGrp = controlsRow.add("group"); btnActionGrp.orientation = "row"; btnActionGrp.spacing = 2; var btnSave = btnActionGrp.add("button", undefined, "Save"); btnSave.noScale = true; btnSave.preferredSize = [45, 20]; var btnDel = btnActionGrp.add("button", undefined, "Del"); btnDel.noScale = true; btnDel.preferredSize = [45, 20]; var btnApplyEase = btnActionGrp.add("button", undefined, "Apply"); btnApplyEase.noScale = true; btnApplyEase.preferredSize = [45, 20]; 
        mainGraph.onDraw = function() { var g = this.graphics; var w = this.size[0], h = this.size[1]; g.newPath(); g.rectPath(0,0,w,h); g.fillPath(g.newBrush(g.BrushType.SOLID_COLOR, [0.08, 0.08, 0.08])); g.newPath(); g.moveTo(w/2, 0); g.lineTo(w/2, h); g.strokePath(g.newPen(g.PenType.SOLID_COLOR, [0.2, 0.2, 0.2], 1)); drawExactSpeedCurve(g, w, h, sldOut.value, sldIn.value, [1, 0.65, 0.1], 2, false); };
        btnApplyEase.onClick = function() { applyEaseKeys(sldOut.value, sldIn.value); }; 
        btnSave.onClick = function() { var arr = getSavedPresets(); arr.push(sldIn.value + "," + sldOut.value); savePresets(arr); activePresetIndex = arr.length - 1; rebuildPresets(); }; 
        btnDel.onClick = function() { var arr = getSavedPresets(); if(arr.length > 0) { if(activePresetIndex !== -1 && activePresetIndex < arr.length) { arr.splice(activePresetIndex, 1); savePresets(arr); activePresetIndex = -1; rebuildPresets(); } else { alert("لو سمحت اختار الـ Ease اللي عايز تمسحه من تحت الأول!"); } } };
        
        function updatePresetsState() { if(typeof presetScroll !== "undefined") { for(var i=0; i<presetScroll.children.length; i++) { var row = presetScroll.children[i]; for(var j=0; j<row.children.length; j++) forceRedraw(row.children[j]); } } }
        sldOut.onChanging = function() { valOut.text = Math.round(this.value); activePresetIndex = -1; forceRedraw(mainGraph); updatePresetsState(); }; sldIn.onChanging = function() { valIn.text = Math.round(this.value); activePresetIndex = -1; forceRedraw(mainGraph); updatePresetsState(); }; valOut.onChange = function() { var v=parseFloat(this.text); if(!isNaN(v)){ sldOut.value=Math.max(0.1,Math.min(100,v)); activePresetIndex = -1; forceRedraw(mainGraph); updatePresetsState(); }}; valIn.onChange = function() { var v=parseFloat(this.text); if(!isNaN(v)){ sldIn.value=Math.max(0.1,Math.min(100,v)); activePresetIndex = -1; forceRedraw(mainGraph); updatePresetsState(); }};

        // --- 🛠️ BASIC TOOLS ---
        var pnlBasicTools = vBasic.add("panel", undefined, "🛠️ Basic Tools"); pnlBasicTools.alignChildren = ["fill", "top"]; pnlBasicTools.margins = pnlMargins; pnlBasicTools.spacing = 2;
        var grpB1 = pnlBasicTools.add("group"); grpB1.orientation = "row"; grpB1.alignChildren = ["fill", "top"]; grpB1.spacing = 2; var btnSolid = grpB1.add("button", undefined, "⬛ Solid"); btnSolid.alignment = ["fill", "top"]; var btnAdj = grpB1.add("button", undefined, "🌗 Adj"); btnAdj.alignment = ["fill", "top"]; var btnBounce = grpB1.add("button", undefined, "🏀 Bounce"); btnBounce.alignment = ["fill", "top"]; var btnNull = grpB1.add("button", undefined, "🎯 Null"); btnNull.alignment = ["fill", "top"];
        var grpB2 = pnlBasicTools.add("group"); grpB2.orientation = "row"; grpB2.alignChildren = ["fill", "top"]; grpB2.spacing = 2; var btnRev = grpB2.add("button", undefined, "🔄 Reverse"); btnRev.alignment = ["fill", "top"]; var btnTrim = grpB2.add("button", undefined, "✂️ Trim Keys"); btnTrim.alignment = ["fill", "top"]; var btnRenameBundle = grpB2.add("button", undefined, "🏷️ Rename Bundle"); btnRenameBundle.alignment = ["fill", "top"]; 
        btnSolid.onClick = function() { app.executeCommand(2038); }; btnAdj.onClick = function() { var c = app.project.activeItem; if(c && c instanceof CompItem) { addUndo("Add Adj Layer", function() { var sel = c.selectedLayers; var l = c.layers.addSolid([1,1,1], "Adjustment Layer", c.width, c.height, c.pixelAspect, c.duration); l.adjustmentLayer = true; l.label = 5; l.startTime = 0; if (sel.length > 0) l.moveBefore(sel[0]); }); } else { alert("Please select a comp first!"); } }; 
        
        // --- 🏀 BOUNCE LOGIC ---
        btnBounce.onClick = function() {
            var comp = app.project.activeItem;
            if (!comp || !(comp instanceof CompItem)) return alert("لازم تفتح Composition الأول يا محمد بازان.");
            if (comp.selectedLayers.length === 0) return alert("اختار لاير واحد على الأقل عشان نطبق عليه الـ Bounce.");

            var d = new Window("dialog", "Bazan Bounce Control");
            d.orientation = "column"; d.alignChildren = ["center", "top"]; d.spacing = 15; d.margins = 20;
            d.graphics.backgroundColor = d.graphics.newBrush(d.graphics.BrushType.SOLID_COLOR, [0.15, 0.15, 0.15]);
            
            var groupProps = d.add("group", undefined, "Properties");
            groupProps.orientation = "row";
            var chkPos = groupProps.add("checkbox", undefined, "Position"); chkPos.graphics.foregroundColor = d.graphics.newPen(d.graphics.PenType.SOLID_COLOR, [0.9, 0.9, 0.9], 1);
            var chkScale = groupProps.add("checkbox", undefined, "Scale"); chkScale.graphics.foregroundColor = d.graphics.newPen(d.graphics.PenType.SOLID_COLOR, [0.9, 0.9, 0.9], 1);
            var chkRot = groupProps.add("checkbox", undefined, "Rotation"); chkRot.graphics.foregroundColor = d.graphics.newPen(d.graphics.PenType.SOLID_COLOR, [0.9, 0.9, 0.9], 1);
            
            chkPos.value = true;
            
            var btnApplyBounce = d.add("button", undefined, "Bounce it");
            btnApplyBounce.size = [120, 30];
            
            btnApplyBounce.onClick = function() {
                var doPos = chkPos.value, doScale = chkScale.value, doRot = chkRot.value;
                d.close();
                
                addUndo("Apply Bazan Bounce", function() {
                    var expr = "try {\n" +
                    "    var amp = effect('Amplitude')('Slider') / 1000;\n" +
                    "    var freq = effect('Frequency')('Slider');\n" +
                    "    var decay = effect('Decay')('Slider');\n" +
                    "    var floor = effect('Floor')('Checkbox');\n" +
                    "    var n = 0, t = 0, v;\n" +
                    "    if (numKeys > 0) {\n" +
                    "        n = nearestKey(time).index;\n" +
                    "        if (key(n).time > time) { n--; }\n" +
                    "    }\n" +
                    "    if (n == 0) { t = 0; } else { t = time - key(n).time; }\n" +
                    "    if (n > 0) {\n" +
                    "        v = velocityAtTime(key(n).time - thisComp.frameDuration / 10);\n" +
                    "        if (floor == 1) {\n" +
                    "            value + v * amp * -(Math.abs(Math.sin(freq * t * 2 * Math.PI)) / Math.exp(decay * t));\n" +
                    "        } else {\n" +
                    "            value + v * amp * (Math.sin(freq * t * 2 * Math.PI) / Math.exp(decay * t));\n" +
                    "        }\n" +
                    "    } else {\n" +
                    "        value;\n" +
                    "    }\n" +
                    "} catch (err) {\n" +
                    "    value;\n" +
                    "}";

                    function addEff(lyr, mName, dName, val) {
                        var fx = lyr.property("Effects");
                        if (!fx.property(dName)) {
                            var f = fx.addProperty(mName);
                            f.name = dName;
                            if(f.property(1)) f.property(1).setValue(val);
                        }
                    }
                    
                    var layers = comp.selectedLayers;
                    for (var i = 0; i < layers.length; i++) {
                        var layer = layers[i];
                        addEff(layer, "ADBE Slider Control", "Amplitude", 50);
                        addEff(layer, "ADBE Slider Control", "Frequency", 3);
                        addEff(layer, "ADBE Slider Control", "Decay", 5);
                        addEff(layer, "ADBE Checkbox Control", "Floor", 0);
                        
                        if (doPos) handleExpression(layer.property("ADBE Transform Group").property("ADBE Position"), expr);
                        if (doScale) handleExpression(layer.property("ADBE Transform Group").property("ADBE Scale"), expr);
                        if (doRot) {
                            var rotProp = layer.property("ADBE Transform Group").property("ADBE Rotate Z") || layer.property("ADBE Transform Group").property("ADBE Rotation");
                            handleExpression(rotProp, expr);
                        }
                    }
                });
            };
            d.show();
        };

        btnNull.onClick = function() { var comp = app.project.activeItem; if(!comp) return alert("Select a comp!"); addUndo("Smart Parent Null", function() { var sel = comp.selectedLayers; if(sel.length === 0) { var n = comp.layers.addNull(); n.name = "Parent Null"; n.label = 2; n.property("Anchor Point").setValue([50, 50]); return; } var is3D = false; var avgX = 0, avgY = 0, avgZ = 0; var count = sel.length; var minIdx = comp.numLayers + 1; for(var i=0; i<count; i++) { if(sel[i].threeDLayer) is3D = true; if(sel[i].index < minIdx) minIdx = sel[i].index; var pos = sel[i].property("Position").value; avgX += pos[0]; avgY += pos[1]; if(pos.length > 2) avgZ += pos[2]; } var nullLayer = comp.layers.addNull(); nullLayer.name = "Parent Null"; nullLayer.threeDLayer = is3D; nullLayer.label = 2; nullLayer.property("Anchor Point").setValue([50, 50]); if (count > 1) { if(is3D) nullLayer.property("Position").setValue([comp.width/2, comp.height/2, 0]); else nullLayer.property("Position").setValue([comp.width/2, comp.height/2]); } else { if(is3D) nullLayer.property("Position").setValue([avgX, avgY, avgZ]); else nullLayer.property("Position").setValue([avgX, avgY]); } var targetIdx = minIdx + 1; if (nullLayer.index !== targetIdx && nullLayer.index !== targetIdx - 1) nullLayer.moveBefore(comp.layer(targetIdx)); for(var j=0; j<count; j++) sel[j].parent = nullLayer; }); }; 
        btnRev.onClick = function() { var comp = app.project.activeItem; if(!comp || comp.selectedLayers.length < 2) return alert("Select at least 2 layers!"); addUndo("Reverse Layers", function() { var sel = comp.selectedLayers.slice(0); sel.sort(function(a,b){return a.index - b.index;}); var topLayer = sel[0]; for (var i = sel.length - 1; i > 0; i--) sel[i].moveBefore(topLayer); }); };
        function getLayerKeyTimes(layer) { var minT = 999999, maxT = -999999; function scanProps(propGroup) { for (var i=1; i<=propGroup.numProperties; i++) { var p = propGroup.property(i); if (p.propertyType === PropertyType.PROPERTY && p.canVaryOverTime && p.numKeys > 0) { if (p.keyTime(1) < minT) minT = p.keyTime(1); if (p.keyTime(p.numKeys) > maxT) maxT = p.keyTime(p.numKeys); } else if (p.propertyType === PropertyType.INDEXED_GROUP || p.propertyType === PropertyType.NAMED_GROUP) scanProps(p); } } scanProps(layer); return (minT === 999999) ? null : {min: minT, max: maxT}; }
        btnTrim.onClick = function() { var comp = app.project.activeItem; if(!comp || comp.selectedLayers.length === 0) return alert("Select layers with keyframes!"); var d = new Window("dialog", "Trim to Keyframes"); d.orientation = "row"; d.margins = 15; d.spacing = 10; d.graphics.backgroundColor = d.graphics.newBrush(d.graphics.BrushType.SOLID_COLOR, [0.15, 0.15, 0.15]); var bIn = d.add("button", undefined, "[ ✂️ In"); var bOut = d.add("button", undefined, "Out ✂️ ]"); var bBoth = d.add("button", undefined, "[ ✂️ Both ✂️ ]"); bIn.onClick = function() { addUndo("Trim In", function() { for(var i=0;i<comp.selectedLayers.length;i++) { var k = getLayerKeyTimes(comp.selectedLayers[i]); if(k) comp.selectedLayers[i].inPoint = k.min; } }); d.close(); }; bOut.onClick = function() { addUndo("Trim Out", function() { for(var i=0;i<comp.selectedLayers.length;i++) { var k = getLayerKeyTimes(comp.selectedLayers[i]); if(k) comp.selectedLayers[i].outPoint = k.max; } }); d.close(); }; bBoth.onClick = function() { addUndo("Trim Both", function() { for(var i=0;i<comp.selectedLayers.length;i++) { var k = getLayerKeyTimes(comp.selectedLayers[i]); if(k) { comp.selectedLayers[i].inPoint = k.min; comp.selectedLayers[i].outPoint = k.max; } } }); d.close(); }; d.show(); };
        btnRenameBundle.onClick = function() { var data = getCompAndSelection(); if(!data) return; var d = new Window("dialog", "Rename Bundle Options"); d.orientation = "column"; d.margins = 15; d.spacing = 10; d.graphics.backgroundColor = d.graphics.newBrush(d.graphics.BrushType.SOLID_COLOR, [0.15, 0.15, 0.15]); var pnlFix = d.add("panel", undefined, "🔗 Add Prefix"); pnlFix.orientation = "row"; pnlFix.margins=10; pnlFix.alignChildren = ["left", "center"]; var txtPre = pnlFix.add("edittext", undefined, ""); txtPre.preferredSize.width = 100; var btnPreAdd = pnlFix.add("button", undefined, "Apply Prefix"); btnPreAdd.onClick = function() { addUndo("Add Prefix", function() { for (var i = 0; i < data.layers.length; i++) data.layers[i].name = txtPre.text + data.layers[i].name; }); }; var pnlSuf = d.add("panel", undefined, "🔗 Add Suffix"); pnlSuf.orientation = "row"; pnlSuf.margins=10; pnlSuf.alignChildren = ["left", "center"]; var txtSuf = pnlSuf.add("edittext", undefined, ""); txtSuf.preferredSize.width = 100; var btnSufAdd = pnlSuf.add("button", undefined, "Apply Suffix"); btnSufAdd.onClick = function() { addUndo("Add Suffix", function() { for (var i = 0; i < data.layers.length; i++) data.layers[i].name = data.layers[i].name + txtSuf.text; }); }; var pnlBase = d.add("panel", undefined, "🔢 Base Rename (Combines & Closes)"); pnlBase.orientation = "row"; pnlBase.margins=10; pnlBase.alignChildren = ["left", "center"]; var txtBase = pnlBase.add("edittext", undefined, "New_Name"); txtBase.preferredSize.width = 100; var chkNum = pnlBase.add("checkbox", undefined, "Num (01,02)"); chkNum.value = true; var btnBaseApply = pnlBase.add("button", undefined, "Apply Base"); btnBaseApply.onClick = function() { addUndo("Base Rename", function() { for (var i = 0; i < data.layers.length; i++) { var finalName = txtBase.text; if (chkNum.value) { var num = (i + 1).toString(); if (num.length < 2) num = "0" + num; finalName += "_" + num; } data.layers[i].name = txtPre.text + finalName + txtSuf.text; } }); d.close(); }; d.show(); };

        // --- COMPOSITIONS (CROP FIX) ---
        var pnlComps = vBasic.add("panel", undefined, "📦 Compositions"); pnlComps.alignChildren = ["fill", "top"]; pnlComps.margins = pnlMargins; pnlComps.spacing = 2;
        var grpPre = pnlComps.add("group"); grpPre.orientation = "row"; grpPre.alignChildren = ["fill", "top"]; grpPre.spacing = 2; var btnPre = grpPre.add("button", undefined, "📦 Pre-Comp"); btnPre.alignment = ["fill", "top"]; var btnUnPre = grpPre.add("button", undefined, "💥 Un-Precomp"); btnUnPre.alignment = ["fill", "top"]; var btnCopyComp = grpPre.add("button", undefined, "🚀 Copy Comp"); btnCopyComp.alignment = ["fill", "top"];
        
        btnPre.onClick = function() { 
            var comp = app.project.activeItem; 
            if (!comp || comp.selectedLayers.length === 0) return alert("Select layers first!"); 
            var d = new Window("dialog", "Pre-Compose Pro Settings"); d.orientation = "column"; d.alignChildren = ["fill", "top"]; d.spacing = 15; d.margins = 20; d.graphics.backgroundColor = d.graphics.newBrush(d.graphics.BrushType.SOLID_COLOR, [0.15, 0.15, 0.15]);
            var lbl = d.add("statictext", undefined, "New Composition Name:"); lbl.graphics.foregroundColor = lbl.graphics.newPen(d.graphics.PenType.SOLID_COLOR, [0.9, 0.9, 0.9], 1);
            var input = d.add("edittext", undefined, "Pre-comp 1"); input.active = true;
            
            var grpCrop1 = d.add("group"); grpCrop1.orientation = "row"; grpCrop1.alignChildren = ["left", "center"];
            var chkCrop = grpCrop1.add("checkbox", undefined, "✂️ Crop Comp to Region"); chkCrop.value = false; chkCrop.graphics.foregroundColor = chkCrop.graphics.newPen(d.graphics.PenType.SOLID_COLOR, [0.9, 0.9, 0.9], 1);
            var chkMask = grpCrop1.add("checkbox", undefined, "🎭 Mask"); chkMask.value = true; chkMask.enabled = false; chkMask.graphics.foregroundColor = chkMask.graphics.newPen(d.graphics.PenType.SOLID_COLOR, [0.8, 0.8, 0.8], 1);

            var grpCrop2 = d.add("group"); grpCrop2.orientation = "row"; grpCrop2.alignChildren = ["left", "center"];
            grpCrop2.add("statictext", undefined, "  Padding (px):").graphics.foregroundColor = chkCrop.graphics.newPen(d.graphics.PenType.SOLID_COLOR, [0.9, 0.9, 0.9], 1);
            var txtPad = grpCrop2.add("edittext", undefined, "50"); txtPad.preferredSize.width = 40;

            chkCrop.onClick = function() { chkMask.enabled = chkCrop.value; };

            var btnGrp = d.add("group"); btnGrp.orientation = "row"; btnGrp.alignChildren = ["right", "center"]; var btnCancel = btnGrp.add("button", undefined, "Cancel"); var btnOk = btnGrp.add("button", undefined, "OK");
            
            btnOk.onClick = function() { 
                var compName = input.text; var doCrop = chkCrop.value; var doMask = chkMask.value; var pad = parseInt(txtPad.text) || 0; d.close();
                addUndo("Precompose & Crop", function() { 
                    var layers = comp.selectedLayers; var layerIndices = []; var minIn = layers[0].inPoint; var maxOut = layers[0].outPoint; 
                    for (var i=0; i<layers.length; i++) { layerIndices.push(layers[i].index); if (layers[i].inPoint < minIn) minIn = layers[i].inPoint; if (layers[i].outPoint > maxOut) maxOut = layers[i].outPoint; } 
                    var newComp = comp.layers.precompose(layerIndices, compName, true); 
                    var precompLayer = comp.selectedLayers[0]; 
                    newComp.duration = maxOut - minIn; precompLayer.startTime = minIn; 
                    for(var j=1; j<=newComp.numLayers; j++) newComp.layer(j).startTime -= minIn; 

                    if (doCrop) {
                        var evalTime = comp.time - minIn;
                        if (evalTime < 0 || evalTime > newComp.duration) evalTime = 0;

                        function getTrueBounds(lyr, t, readMasks) {
                            var b = lyr.sourceRectAtTime(t, false);
                            var res = { left: b.left, top: b.top, width: b.width, height: b.height };
                            
                            if (readMasks && lyr.property("ADBE Mask Parade") && lyr.property("ADBE Mask Parade").numProperties > 0) {
                                var masks = lyr.property("ADBE Mask Parade");
                                var hasValidMask = false;
                                var mMinX = Infinity, mMinY = Infinity, mMaxX = -Infinity, mMaxY = -Infinity;
                                
                                for (var m = 1; m <= masks.numProperties; m++) {
                                    var mask = masks.property(m);
                                    if (mask.maskMode !== MaskMode.NONE) {
                                        var shape = mask.property("ADBE Mask Shape").valueAtTime(t, false);
                                        var verts = shape.vertices;
                                        if (verts && verts.length > 0) {
                                            hasValidMask = true;
                                            var inT = shape.inTangents;
                                            var outT = shape.outTangents;
                                            for (var v = 0; v < verts.length; v++) {
                                                var px = verts[v][0], py = verts[v][1];
                                                var ix = px + inT[v][0], iy = py + inT[v][1];
                                                var ox = px + outT[v][0], oy = py + outT[v][1];
                                                mMinX = Math.min(mMinX, px, ix, ox);
                                                mMaxX = Math.max(mMaxX, px, ix, ox);
                                                mMinY = Math.min(mMinY, py, iy, oy);
                                                mMaxY = Math.max(mMaxY, py, iy, oy);
                                            }
                                            try {
                                                var feather = mask.property("ADBE Mask Feather").valueAtTime(t, false);
                                                mMinX -= feather[0]; mMaxX += feather[0];
                                                mMinY -= feather[1]; mMaxY += feather[1];
                                            } catch(e) {}
                                        }
                                    }
                                }
                                if (hasValidMask) { res.left = mMinX; res.top = mMinY; res.width = mMaxX - mMinX; res.height = mMaxY - mMinY; }
                            }
                            return res;
                        }

                        var minX = 999999, minY = 999999, maxX = -999999, maxY = -999999;
                        var hasValidLayers = false;
                        var exprNull = newComp.layers.addNull(); exprNull.name = "Bazan_Temp_Scanner";

                        for (var i = 1; i <= newComp.numLayers; i++) {
                            var l = newComp.layer(i);
                            if (l === exprNull || !l.active || l.isNull || l.adjustmentLayer || l.camera || l.light || l.hasTrackMatte) continue;
                            try {
                                var rect = getTrueBounds(l, evalTime, doMask);
                                if (rect.width === 0 || rect.height === 0) continue;
                                var corners = [ [rect.left, rect.top], [rect.left + rect.width, rect.top], [rect.left, rect.top + rect.height], [rect.left + rect.width, rect.top + rect.height] ];
                                for (var c=0; c<4; c++) {
                                    exprNull.property("Position").expression = "try{thisComp.layer(" + l.index + ").toComp([" + corners[c][0] + "," + corners[c][1] + ",0], " + evalTime + ");}catch(e){[0,0,0];}";
                                    var p = exprNull.property("Position").value;
                                    minX = Math.min(minX, p[0]); minY = Math.min(minY, p[1]); maxX = Math.max(maxX, p[0]); maxY = Math.max(maxY, p[1]);
                                }
                                hasValidLayers = true;
                            } catch(e){}
                        }
                        exprNull.remove();
                        
                        if (hasValidLayers && minX !== 999999 && maxX > minX && maxY > minY) {
                            var newW = Math.max(4, Math.ceil(maxX - minX)) + (pad * 2);
                            var newH = Math.max(4, Math.ceil(maxY - minY)) + (pad * 2);
                            
                            var roots = []; var lockStates = [];
                            var shiftNull = newComp.layers.addNull(); shiftNull.name = "Temp Shift Null";

                            for(var i=1; i<=newComp.numLayers; i++) {
                                var lr = newComp.layer(i);
                                if(lr !== shiftNull && lr.parent == null) { roots.push(lr); lockStates.push(lr.locked); if(lr.locked) lr.locked = false; lr.parent = shiftNull; }
                            }
                            
                            var nPos = shiftNull.property("Position").value;
                            shiftNull.property("Position").setValue([nPos[0] - minX + pad, nPos[1] - minY + pad]);
                            
                            for(var i=0; i<roots.length; i++) { roots[i].parent = null; if(lockStates[i]) roots[i].locked = true; }
                            shiftNull.remove();
                            
                            newComp.width = newW; newComp.height = newH;
                            precompLayer.property("Anchor Point").setValue([newW/2, newH/2]);
                            if (precompLayer.threeDLayer) {
                                var pZ = precompLayer.property("Position").value[2];
                                precompLayer.property("Position").setValue([minX - pad + newW/2, minY - pad + newH/2, pZ]);
                            } else {
                                precompLayer.property("Position").setValue([minX - pad + newW/2, minY - pad + newH/2]);
                            }
                        }
                    }
                }); 
            }; 
            btnCancel.onClick = function() { d.close(); }; d.show();
        };

        btnUnPre.onClick = function() { 
            var c = app.project.activeItem; if (!c || !(c instanceof CompItem)) return alert("Select a comp."); 
            var selLayers = c.selectedLayers; if (selLayers.length === 0) return alert("Select Pre-comps."); 
            var pComps = []; for(var i=0; i<selLayers.length; i++) if(selLayers[i].source instanceof CompItem) pComps.push(selLayers[i]); 
            if (pComps.length === 0) return alert("No valid Pre-comps selected."); 
            
            var d = new Window("dialog", "Un-Precompose"); d.orientation = "column"; d.alignChildren = ["fill", "top"]; d.spacing = 15; d.margins = 20; d.graphics.backgroundColor = d.graphics.newBrush(d.graphics.BrushType.SOLID_COLOR, [0.15, 0.15, 0.15]); 
            var rdoDel = d.add("radiobutton", undefined, "🗑️ Delete Original"); rdoDel.value = true; rdoDel.graphics.foregroundColor = rdoDel.graphics.newPen(d.graphics.PenType.SOLID_COLOR, [0.9, 0.9, 0.9], 1); 
            var rdoKeep = d.add("radiobutton", undefined, "👁️ Keep (Hide)"); rdoKeep.graphics.foregroundColor = rdoKeep.graphics.newPen(d.graphics.PenType.SOLID_COLOR, [0.9, 0.9, 0.9], 1); 
            var grpBtns = d.add("group"); grpBtns.orientation = "row"; grpBtns.alignChildren = ["right", "center"]; var btnCancel = grpBtns.add("button", undefined, "Cancel"); var btnOk = grpBtns.add("button", undefined, "OK"); 
            btnOk.onClick = function() { d.close(1); }; btnCancel.onClick = function() { d.close(0); }; 
            
            if (d.show() === 1) { 
                var doDelete = rdoDel.value; 
                addUndo("Un-Precompose", function() {
                    try {
                        for (var p = pComps.length - 1; p >= 0; p--) { 
                            var pL = pComps[p]; var sC = pL.source; var tO = pL.startTime; 
                            sC.openInViewer(); app.executeCommand(2004); 
                            var hasLayers = false; 
                            for (var i = 1; i <= sC.numLayers; i++) { sC.layer(i).locked = false; sC.layer(i).selected = true; hasLayers = true; } 
                            if(hasLayers) app.executeCommand(19); 
                            c.openInViewer(); app.executeCommand(2004); pL.selected = true; 
                            if(hasLayers) { 
                                app.executeCommand(20); 
                                var pst = c.selectedLayers; 
                                for (var i = 0; i < pst.length; i++) if (pst[i] !== pL) pst[i].startTime += (tO - sC.displayStartTime); 
                                var pRoots = []; 
                                for (var i = 0; i < pst.length; i++) { 
                                    if (pst[i] === pL) continue; 
                                    var isRoot = true; 
                                    if (pst[i].parent !== null) { for (var j=0; j<pst.length; j++) if (pst[i].parent === pst[j]) { isRoot = false; break; } } 
                                    if (isRoot) pRoots.push(pst[i]); 
                                } 
                                if (pRoots.length > 0) { 
                                    var tempNull = c.layers.addNull(c.duration); 
                                    tempNull.property("Anchor Point").setValue([0, 0]); tempNull.property("Position").setValue([0, 0]); 
                                    for (var i=0; i<pRoots.length; i++) pRoots[i].parent = tempNull; 
                                    tempNull.property("Anchor Point").setValue(pL.property("Anchor Point").value); 
                                    tempNull.property("Position").setValue(pL.property("Position").value); 
                                    tempNull.property("Scale").setValue(pL.property("Scale").value); 
                                    tempNull.property("Rotation").setValue(pL.property("Rotation").value); 
                                    if(pL.threeDLayer) { 
                                        tempNull.threeDLayer = true; 
                                        tempNull.property("X Rotation").setValue(pL.property("X Rotation").value); 
                                        tempNull.property("Y Rotation").setValue(pL.property("Y Rotation").value); 
                                        tempNull.property("Z Rotation").setValue(pL.property("Z Rotation").value); 
                                        if(pL.property("Orientation")) tempNull.property("Orientation").setValue(pL.property("Orientation").value); 
                                    } 
                                    for (var i=0; i<pRoots.length; i++) pRoots[i].parent = null; 
                                    tempNull.remove(); 
                                } 
                            } else { c.openInViewer(); } 
                            if (doDelete) { pL.remove(); try { sC.remove(); } catch(e) {} } else { pL.enabled = false; pL.selected = false; } 
                        } 
                    } catch(err) { 
                        alert("Un-Precompose Error: " + err.toString()); 
                    } 
                });
            } 
        };

        function deepDuplicate_Exact(originalComp, suffix, clonedMap) { if (clonedMap[originalComp.id]) return clonedMap[originalComp.id]; var newComp = originalComp.duplicate(); var cleanName = originalComp.name.replace(/(_\d+)+$/, ''); newComp.name = cleanName + suffix; clonedMap[originalComp.id] = newComp; for (var i = 1; i <= newComp.numLayers; i++) { var layer = newComp.layer(i); if (layer.source && layer.source instanceof CompItem) { var newPreComp = deepDuplicate_Exact(layer.source, suffix, clonedMap); layer.replaceSource(newPreComp, true); } } return newComp; }
        btnCopyComp.onClick = function() { var proj = app.project; if (!proj) return; var selItems = proj.selection; var compsToDupe = []; for (var i = 0; i < selItems.length; i++) if (selItems[i] instanceof CompItem) compsToDupe.push(selItems[i]); if (compsToDupe.length === 0) return alert("Select Comps in PROJECT PANEL."); var d = new Window("dialog", "Multi-Copy Comp"); d.orientation="column"; d.margins=15; d.spacing=10; d.graphics.backgroundColor = d.graphics.newBrush(d.graphics.BrushType.SOLID_COLOR, [0.15, 0.15, 0.15]); var pnl = d.add("group"); pnl.orientation="row"; pnl.alignChildren=["left","center"]; var lbl1 = pnl.add("statictext", undefined, "Copies:"); lbl1.graphics.foregroundColor = lbl1.graphics.newPen(d.graphics.PenType.SOLID_COLOR, [0.9, 0.9, 0.9], 1); var txtCopies = pnl.add("edittext", undefined, "1"); txtCopies.preferredSize.width = 40; var lbl2 = pnl.add("statictext", undefined, "Suffix:"); lbl2.graphics.foregroundColor = lbl2.graphics.newPen(d.graphics.PenType.SOLID_COLOR, [0.9, 0.9, 0.9], 1); var txtS = pnl.add("edittext", undefined, "_"); txtS.preferredSize.width = 60; var btnGrp = d.add("group"); btnGrp.orientation="row"; btnGrp.alignChildren=["center","center"]; var bOk = btnGrp.add("button", undefined, "Duplicate"); bOk.onClick = function() { addUndo("Multi-Copy Comp", function() { var copies = parseInt(txtCopies.text) || 1; var suffixBase = txtS.text; for (var c = 0; c < compsToDupe.length; c++) { for (var k = 1; k <= copies; k++) { var clonedMap = {}; var finalSuffix = suffixBase + (copies > 1 ? k : "1"); deepDuplicate_Exact(compsToDupe[c], finalSuffix, clonedMap); } } }); d.close(); alert("Done! Copied successfully."); }; d.show(); };

        var pnlTextExploder = vBasic.add("panel", undefined, "💥 Text Exploder"); pnlTextExploder.alignChildren = ["fill", "top"]; pnlTextExploder.margins = pnlMargins; pnlTextExploder.spacing = 2;
        var grpTextAdd = pnlTextExploder.add("group"); grpTextAdd.orientation = "row"; grpTextAdd.alignChildren = ["fill", "top"]; grpTextAdd.spacing = 2; var btnText = grpTextAdd.add("button", undefined, "📝 Text Box Rig"); btnText.alignment = ["fill", "top"]; var btnSrt = grpTextAdd.add("button", undefined, "📝 SRT Import"); btnSrt.alignment = ["fill", "top"];
        var grpDec1 = pnlTextExploder.add("group"); grpDec1.orientation = "row"; grpDec1.alignChildren = ["fill", "center"]; grpDec1.spacing = 2; var dropMode = grpDec1.add("dropdownlist", undefined, ["Characters", "Words", "Lines"]); dropMode.selection = 0; dropMode.preferredSize.width = 95; var dropOrder = grpDec1.add("dropdownlist", undefined, ["Top ➔ Bottom", "Bottom ➔ Top"]); dropOrder.selection = 0; dropOrder.preferredSize.width = 110;
        var grpDec2 = pnlTextExploder.add("group"); grpDec2.orientation = "row"; grpDec2.alignChildren = ["left", "center"]; grpDec2.spacing = 15; var chkRTL = grpDec2.add("checkbox", undefined, "RTL (Arabic)"); chkRTL.value = true; var btnDecompose = pnlTextExploder.add("button", undefined, "🔠 Clean Decompose Selected Text"); btnDecompose.alignment = ["fill", "top"];
        btnText.onClick = function() { var comp = app.project.activeItem; if (!comp) return alert("افتح كومبوزيشن يا هندسة!"); addUndo("Bazan Centered Box Rig", function() { comp.layers.addShape().name = "Bazan Box"; comp.layers.addText("New Text").name = "Bazan Text"; var ctrlNull = comp.layers.addNull(); ctrlNull.name = "Bazan Controller"; ctrlNull.label = 2; var txtProp = comp.layer("Bazan Text").property("ADBE Text Properties").property("ADBE Text Document"); var txtDoc = txtProp.value; txtDoc.justification = ParagraphJustification.CENTER_JUSTIFY; txtProp.setValue(txtDoc); var fx = ctrlNull.property("ADBE Effect Parade"); fx.addProperty("ADBE Slider Control").name = "Progress %"; fx.addProperty("ADBE Slider Control").name = "Padding X"; fx.addProperty("ADBE Slider Control").name = "Padding Y"; fx.addProperty("ADBE Slider Control").name = "Roundness"; ctrlNull.effect("Padding X")(1).setValue(80); ctrlNull.effect("Padding Y")(1).setValue(40); ctrlNull.effect("Roundness")(1).setValue(20); comp.layer("Bazan Text").property("ADBE Text Properties").property("ADBE Text Document").expression = "var ctrl = thisComp.layer('Bazan Controller');\nvar p = clamp(ctrl.effect('Progress %')(1), 0, 100) / 100;\nvar str = value.toString();\nvar count = Math.round(str.length * p);\nvar res = str.substr(0, count);\nif(res == '') res = '\\u200B';\nres;"; var vectors = comp.layer("Bazan Box").property("ADBE Root Vectors Group"); var rectGrp = vectors.addProperty("ADBE Vector Group"); rectGrp.property("ADBE Vectors Group").addProperty("ADBE Vector Shape - Rect"); rectGrp.property("ADBE Vectors Group").addProperty("ADBE Vector Graphic - Fill"); var shapeGrp = comp.layer("Bazan Box").property("ADBE Root Vectors Group").property(1).property("ADBE Vectors Group"); shapeGrp.property(2).property("ADBE Vector Fill Color").setValue([0.1, 0.4, 0.8]); shapeGrp.property(1).property("ADBE Vector Rect Roundness").expression = "thisComp.layer('Bazan Controller').effect('Roundness')(1);"; shapeGrp.property(1).property("ADBE Vector Rect Size").expression = "var txt = thisComp.layer('Bazan Text');\nvar ctrl = thisComp.layer('Bazan Controller');\nvar dummy = txt.text.sourceText;\nvar px = ctrl.effect('Padding X')(1);\nvar py = ctrl.effect('Padding Y')(1);\nvar r = txt.sourceRectAtTime(time, false);\nif (r.width === 0) {\n  [0, 0];\n} else {\n  [r.width + px, r.height + py];\n}"; shapeGrp.property(1).property("ADBE Vector Rect Position").expression = "var txt = thisComp.layer('Bazan Text');\nvar dummy = txt.text.sourceText;\nvar r = txt.sourceRectAtTime(time, false);\nif (r.width === 0) {\n  [0, 0];\n} else {\n  [r.left + r.width/2, r.top + r.height/2];\n}"; var centerX = comp.width / 2; var centerY = comp.height / 2; ctrlNull.property("ADBE Transform Group").property("ADBE Position").setValue([centerX, centerY]); comp.layer("Bazan Text").property("ADBE Transform Group").property("ADBE Position").setValue([centerX, centerY]); comp.layer("Bazan Box").property("ADBE Transform Group").property("ADBE Position").setValue([centerX, centerY]); ctrlNull.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([50,50]); comp.layer("Bazan Text").property("ADBE Transform Group").property("ADBE Anchor Point").setValue([0,0]); comp.layer("Bazan Box").property("ADBE Transform Group").property("ADBE Anchor Point").setValue([0,0]); comp.layer("Bazan Box").parent = comp.layer("Bazan Text"); comp.layer("Bazan Text").parent = ctrlNull; var prog = ctrlNull.effect("Progress %")(1); prog.setValue(100); for (var i = 1; i <= comp.numLayers; i++) comp.layer(i).selected = false; ctrlNull.selected = true; }); }; 
        btnSrt.onClick = function() { var comp = app.project.activeItem; if (!comp || !(comp instanceof CompItem)) return alert("Select comp first!"); var srtFile = File.openDialog("Select an SRT file", "*.srt"); if (!srtFile) return; var opened = srtFile.open("r"); if (!opened) return alert("Failed to open."); var content = srtFile.read(); srtFile.close(); function parseSrtTime(timeStr) { var parts = timeStr.replace(',', '.').split(":"); return (parseInt(parts[0], 10) * 3600) + (parseInt(parts[1], 10) * 60) + parseFloat(parts[2]); } addUndo("Import SRT", function() { content = content.replace(/\r\n/g, "\n").replace(/\r/g, "\n"); var blocks = content.split(/\n\n+/); for (var i = 0; i < blocks.length; i++) { var block = blocks[i].replace(/^\s+|\s+$/g, ''); if (block === "") continue; var lines = block.split("\n"); if (lines.length >= 3) { var timeParts = lines[1].split(" --> "); if (timeParts.length === 2) { var startTime = parseSrtTime(timeParts[0]); var endTime = parseSrtTime(timeParts[1]); var txtLayer = comp.layers.addText(lines.slice(2).join("\n")); txtLayer.startTime = startTime; txtLayer.inPoint = startTime; txtLayer.outPoint = endTime; var rect = txtLayer.sourceRectAtTime(startTime, false); txtLayer.property("Anchor Point").setValue([rect.left + rect.width/2, rect.top + rect.height/2]); txtLayer.property("Position").setValue([comp.width/2, comp.height * 0.85]); } } } }); }; 

        btnDecompose.onClick = function() { 
            var comp = app.project.activeItem; 
            if (!comp || !(comp instanceof CompItem)) return alert("A comp must be active."); 
            var layers = comp.selectedLayers; 
            if (layers.length === 0) return alert("Please select a text layer."); 
            
            addUndo("Decompose Text", function() { 
                var splitMode = dropMode.selection.index; 
                var isRTL = chkRTL.value; 
                var isTopToBottom = (dropOrder.selection.index === 0); 

                function getTrueWidth(layer, textDoc, str, time) { 
                    if (str === "") return 0; 
                    textDoc.text = str + "|"; 
                    layer.property("ADBE Text Properties").property("ADBE Text Document").setValue(textDoc); 
                    var w1 = layer.sourceRectAtTime(time, false).width; 
                    textDoc.text = "|"; 
                    layer.property("ADBE Text Properties").property("ADBE Text Document").setValue(textDoc); 
                    var w2 = layer.sourceRectAtTime(time, false).width; 
                    return w1 - w2; 
                } 

                function safeAddOffset(prop, diffArray) {
                    if (!prop || !prop.canSetExpression) return;
                    var hasKeys = prop.numKeys > 0;
                    var hasExpr = prop.expression !== "";
                    
                    if (!hasKeys && !hasExpr) {
                        var v = prop.value;
                        if (v.length >= 2) {
                            v[0] += diffArray[0];
                            v[1] += diffArray[1];
                            if (v.length > 2 && diffArray.length > 2) v[2] += diffArray[2];
                        } else {
                            v += diffArray[0];
                        }
                        prop.setValue(v);
                    } else {
                        var offsetStr = (prop.value.length === 3) ? "["+diffArray[0]+","+diffArray[1]+","+(diffArray[2]||0)+"]" : "["+diffArray[0]+","+diffArray[1]+"]";
                        if (hasExpr) {
                            var cleanExpr = prop.expression.replace(/\r\n/g, "\n");
                            prop.expression = "var _orig = (function(){\n" + cleanExpr + "\n})();\ntry{ _orig + " + offsetStr + "; } catch(e){ value + " + offsetStr + "; }";
                        } else {
                            prop.expression = "value + " + offsetStr + ";";
                        }
                    }
                }

                for (var lIdx = 0; lIdx < layers.length; lIdx++) { 
                    var layer = layers[lIdx]; 
                    if (!(layer instanceof TextLayer)) continue; 
                    var textProp = layer.property("ADBE Text Properties").property("ADBE Text Document"); 
                    var doc = textProp.value; 
                    if (doc.boxText) continue; 
                    var fullText = doc.text.replace(/\r\n/g, "\n").replace(/\r/g, "\n"); 
                    var lines = fullText.split("\n"); 
                    var measureLayer = layer.duplicate(); 
                    measureLayer.name = "Bazan_Measure"; 
                    measureLayer.locked = false; 
                    if (measureLayer.property("Source Text").canSetExpression) measureLayer.property("Source Text").expression = ""; 
                    var mDoc = measureLayer.property("ADBE Text Properties").property("ADBE Text Document").value; 
                    mDoc.justification = ParagraphJustification.LEFT_JUSTIFY; 
                    var lead = doc.autoLeading ? doc.fontSize * 1.2 : doc.leading; 
                    var generatedLayers = []; 
                    
                    for (var i = 0; i < lines.length; i++) { 
                        var lineText = lines[i]; 
                        if (lineText === "") continue; 
                        var yOffset = i * lead; 
                        var chunks = []; 
                        if (splitMode === 2) chunks.push({ text: lineText, prefix: "" }); 
                        else if (splitMode === 1) { 
                            var regex = /\S+/g; 
                            var match; 
                            while ((match = regex.exec(lineText)) !== null) chunks.push({ text: match[0], prefix: lineText.substring(0, match.index) }); 
                        } else if (splitMode === 0) { 
                            for (var cIdx = 0; cIdx < lineText.length; cIdx++) if (lineText[cIdx] !== ' ' && lineText[cIdx] !== '\t') chunks.push({ text: lineText[cIdx], prefix: lineText.substring(0, cIdx) }); 
                        } 
                        if (chunks.length === 0) continue; 
                        var totalLineWidth = getTrueWidth(measureLayer, mDoc, lineText, comp.time); 
                        var startX = 0; 
                        if (doc.justification == ParagraphJustification.CENTER_JUSTIFY) startX = -totalLineWidth / 2; 
                        else if (doc.justification == ParagraphJustification.RIGHT_JUSTIFY) startX = -totalLineWidth; 
                        
                        for (var j = 0; j < chunks.length; j++) { 
                            var chunk = chunks[j]; 
                            var prefixWidth = getTrueWidth(measureLayer, mDoc, chunk.prefix, comp.time); 
                            var chunkWidth = getTrueWidth(measureLayer, mDoc, chunk.text, comp.time); 
                            var chunkStartX = isRTL ? startX + totalLineWidth - prefixWidth - chunkWidth : startX + prefixWidth; 
                            var chunkAnchorX = 0; 
                            if (doc.justification == ParagraphJustification.CENTER_JUSTIFY) chunkAnchorX = -chunkWidth / 2; 
                            else if (doc.justification == ParagraphJustification.RIGHT_JUSTIFY) chunkAnchorX = -chunkWidth; 
                            var deltaX = chunkStartX - chunkAnchorX; 
                            var deltaY = yOffset; 
                            
                            var newL = layer.duplicate(); 
                            newL.name = chunk.text; 
                            newL.locked = false; 
                            if (newL.property("Source Text").canSetExpression) newL.property("Source Text").expression = ""; 
                            var newDoc = newL.property("ADBE Text Properties").property("ADBE Text Document").value; 
                            newDoc.text = chunk.text; 
                            newL.property("ADBE Text Properties").property("ADBE Text Document").setValue(newDoc); 
                            
                            var oldAP = newL.property("Anchor Point").value; 
                            var shiftedAP = [oldAP[0] - deltaX, oldAP[1] - deltaY, oldAP.length > 2 ? oldAP[2] : 0]; 
                            
                            var rect = newL.sourceRectAtTime(comp.time, false); 
                            var targetAP = [rect.left + rect.width / 2, rect.top + rect.height / 2, shiftedAP[2]]; 
                            
                            var currentPos = newL.property("Position").value; 
                            var scale = newL.property("Scale").value; 
                            var apDiffX = targetAP[0] - shiftedAP[0]; 
                            var apDiffY = targetAP[1] - shiftedAP[1]; 
                            
                            var newPosX = currentPos[0] + (apDiffX * (scale[0] / 100)); 
                            var newPosY = currentPos[1] + (apDiffY * (scale[1] / 100)); 
                            var newPosZ = currentPos.length > 2 ? currentPos[2] : 0; 
                            
                            // CALCULATE TRUE OFFSETS 
                            var offsetAP = [targetAP[0] - oldAP[0], targetAP[1] - oldAP[1], targetAP.length > 2 ? targetAP[2] - (oldAP[2]||0) : 0];
                            var offsetPos = [newPosX - currentPos[0], newPosY - currentPos[1], currentPos.length > 2 ? newPosZ - (currentPos[2]||0) : 0];

                            // SAFELY APPLY THEM
                            safeAddOffset(newL.property("Anchor Point"), offsetAP);
                            safeAddOffset(newL.property("Position"), offsetPos);
                            
                            newL.selected = false; 
                            generatedLayers.push(newL); 
                        } 
                    } 
                    measureLayer.remove(); 
                    if (isRTL) generatedLayers.reverse(); 
                    for (var k = 0; k < generatedLayers.length; k++) { 
                        if (isTopToBottom) { 
                            if (k === 0) generatedLayers[k].moveBefore(layer); 
                            else generatedLayers[k].moveAfter(generatedLayers[k-1]); 
                        } else { 
                            if (k === 0) generatedLayers[k].moveAfter(layer); 
                            else generatedLayers[k].moveBefore(generatedLayers[k-1]); 
                        } 
                    } 
                    layer.enabled = false; 
                    layer.selected = false; 
                } 
            }); 
        };

       // --- NUMBER & SYMBOL ---
        var pnlNum = vBasic.add("panel", undefined, "🔢 Number & Symbol (Ctrl+Click to Bake)"); pnlNum.alignChildren = ["fill", "top"]; pnlNum.margins = pnlMargins; pnlNum.spacing = 2;
        var grpNumTop = pnlNum.add("group"); grpNumTop.orientation = "row"; grpNumTop.alignChildren = ["left", "center"]; grpNumTop.spacing = 4; 
        
        grpNumTop.add("statictext", undefined, "🏷️ Sym:"); 
        
        var dropSym = grpNumTop.add("dropdownlist", undefined, ["None", "%", "$", "€"]); 
        dropSym.selection = 0; dropSym.preferredSize.width = 50; 
        
        var txtCustomSym = grpNumTop.add("edittext", undefined, "");
        txtCustomSym.preferredSize.width = 55;
        
        var dropPos = grpNumTop.add("dropdownlist", undefined, ["👈 L", "👉 R"]); 
        dropPos.selection = 0; dropPos.preferredSize.width = 50; 
        
        var grpNumBtns = pnlNum.add("group"); grpNumBtns.orientation = "row"; grpNumBtns.alignChildren = ["fill", "top"]; grpNumBtns.spacing = 2; 
        var btnNumCount = grpNumBtns.add("button", undefined, "🔢 Count"); btnNumCount.alignment = ["fill", "top"]; 
        var btnNumComma = grpNumBtns.add("button", undefined, "🧮 Comma"); btnNumComma.alignment = ["fill", "top"];

        function applyNumberScript(withComma) { 
            var comp = app.project.activeItem; if (!comp || !(comp instanceof CompItem)) return alert("Select comp."); 
            var sel = comp.selectedLayers; if(sel.length === 0) return alert("Select Text layer."); 
            
            var selSym = dropSym.selection.text;
            var pos = dropPos.selection.index; // 0 يعني L و 1 يعني R
            var customTxt = txtCustomSym.text;
            
            var finalSym = "";
            if (customTxt && customTxt !== "") {
                finalSym = customTxt;
            } else if (selSym !== "None" && selSym !== "") {
                finalSym = selSym;
            }
            
            addUndo("Apply Numbers", function() { 
                for(var i=0; i<sel.length; i++) { 
                    var layer = sel[i]; if(!(layer instanceof TextLayer)) continue; 
                    var textProp = layer.property("Source Text"); 
                    var fx = layer.property("Effects"); 
                    
                    if(fx.property("Symbol Right Position")) {
                        fx.property("Symbol Right Position").remove();
                    }

                    var sld = fx.property("Slider Control") || fx.addProperty("ADBE Slider Control"); 
                    sld.name = "Slider Control"; 
                    
                    var expr = 'var n = effect("Slider Control")(1);\n'; 
                    if (withComma) { 
                        expr += 'function addCommas(num) { var s = Math.floor(num).toString(); var res = ""; var c = 0; for(var j=s.length-1; j>=0; j--){ res = s[j] + res; c++; if(c%3==0 && j!=0) res = "," + res; } return res; }\n'; 
                        expr += 'var valStr = addCommas(n);\n'; 
                        expr += 'if (n < 0) { valStr = "-" + valStr.replace("-", ""); }\n';
                    } else { 
                        expr += 'var valStr = Math.round(n).toString();\n'; 
                    } 
                    
                    if (finalSym !== "") { 
                        var symEscaped = finalSym.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n');
                        expr += 'var mySym = "' + symEscaped + '";\n';
                        
                        if (pos === 0) { // L (شمال)
                            expr += '"\\u202D" + mySym + " " + valStr + "\\u202C";'; 
                        } else {         // R (يمين)
                            expr += '"\\u202D" + valStr + " " + mySym + "\\u202C";'; 
                        }
                    } else { 
                        expr += '"\\u202D" + valStr + "\\u202C";'; 
                    } 
                    handleExpression(textProp, expr); 
                } 
            }); 
        }

        btnNumCount.onClick = function() { applyNumberScript(false); }; 
        btnNumComma.onClick = function() { applyNumberScript(true); };
        // =========================================================
        // TAB 2: PROXIMITY & RIGS
        // =========================================================
        var pnlPathNulls = vProx.add("panel", undefined, "🔗 Create Nulls From Paths"); pnlPathNulls.alignChildren = ["fill", "top"]; pnlPathNulls.margins = pnlMargins; pnlPathNulls.spacing = 2;
        var grpPathN1 = pnlPathNulls.add("group"); grpPathN1.orientation = "row"; grpPathN1.alignChildren = ["fill", "top"]; grpPathN1.spacing = 2; var btnPtToNull = grpPathN1.add("button", undefined, "📍 Points Follow Nulls"); btnPtToNull.alignment = ["fill", "top"]; var btnNullToPt = grpPathN1.add("button", undefined, "📌 Nulls Follow Points"); btnNullToPt.alignment = ["fill", "top"]; var btnTracePath = pnlPathNulls.add("button", undefined, "🛤️ Trace Path"); btnTracePath.alignment = ["fill", "top"];
        btnPtToNull.onClick = function() { PathNulls.linkPointsToNulls(); }; btnNullToPt.onClick = function() { PathNulls.linkNullsToPoints(); }; btnTracePath.onClick = function() { PathNulls.tracePath(); };

        // --- 🚀 AUTO RIGS & AROUND OBJECT ---
        var pnlAutoRigs = vProx.add("panel", undefined, "🔄 Auto Rig & Net Ropes"); 
        pnlAutoRigs.alignChildren = ["fill", "top"]; pnlAutoRigs.margins = pnlMargins; pnlAutoRigs.spacing = 2;
        
        var grpAutoRigs = pnlAutoRigs.add("group"); grpAutoRigs.orientation = "row"; grpAutoRigs.alignChildren = ["fill", "top"]; grpAutoRigs.spacing = 2;
        var btnAutoPathRig = grpAutoRigs.add("button", undefined, "🚀 Create Auto Path Rig"); btnAutoPathRig.alignment = ["fill", "top"];
        var btnAround = grpAutoRigs.add("button", undefined, "🔄 Around Object"); btnAround.alignment = ["fill", "top"];
        
        var grpRopes = pnlAutoRigs.add("group"); grpRopes.orientation = "row"; grpRopes.alignChildren = ["fill", "center"]; grpRopes.spacing = 2; var btnRopes = grpRopes.add("button", undefined, "🕸️ Network Ropes"); var dropRopeType = grpRopes.add("dropdownlist", undefined, ["Hub (1 to All)", "Web (All to All)"]); dropRopeType.selection = 0; dropRopeType.preferredSize.width = 120;
        
        btnRopes.onClick = function() { addUndo("Network Ropes Pro", function() { var comp = app.project.activeItem; if (!comp || !(comp instanceof CompItem)) return alert("Please select a composition first."); if (comp.selectedLayers.length < 2) return alert("Please select at least 2 layers."); var layers = comp.selectedLayers; var connections = []; var typeIdx = dropRopeType.selection.index; if (typeIdx === 0) { for (var i = 1; i < layers.length; i++) connections.push({ l1: layers[0], l2: layers[i] }); } else { for (var i = 0; i < layers.length; i++) for (var j = i + 1; j < layers.length; j++) connections.push({ l1: layers[i], l2: layers[j] }); } var ctrlNull = comp.layers.addNull(); ctrlNull.name = "🎛️ Network Controller"; ctrlNull.property("Anchor Point").setValue([50, 50]); if (ctrlNull.index > 1) ctrlNull.moveBefore(comp.layer(1)); var ctrlFx = ctrlNull.property("Effects"); var fxColor = ctrlFx.addProperty("ADBE Color Control"); fxColor.name = "Rope Color"; fxColor.property("Color").setValue([1, 1, 1]); var fxThick = ctrlFx.addProperty("ADBE Slider Control"); fxThick.name = "Stroke Thickness"; fxThick.property(1).setValue(4); var fxStart = ctrlFx.addProperty("ADBE Slider Control"); fxStart.name = "Trim Start %"; fxStart.property(1).setValue(0); var fxEnd = ctrlFx.addProperty("ADBE Slider Control"); fxEnd.name = "Trim End %"; fxEnd.property(1).setValue(100); var fxWaveH = ctrlFx.addProperty("ADBE Slider Control"); fxWaveH.name = "Wave Height"; fxWaveH.property(1).setValue(0); var fxWaveW = ctrlFx.addProperty("ADBE Slider Control"); fxWaveW.name = "Wave Width"; fxWaveW.property(1).setValue(40); var fxWaveS = ctrlFx.addProperty("ADBE Slider Control"); fxWaveS.name = "Wave Speed"; fxWaveS.property(1).setValue(1); for (var c = 0; c < connections.length; c++) { var l1 = connections[c].l1; var l2 = connections[c].l2; var ropeLayer = comp.layers.addShape(); ropeLayer.name = "Rope: " + l1.name + " -> " + l2.name; if (ropeLayer.index !== ctrlNull.index + 1) ropeLayer.moveAfter(ctrlNull); ropeLayer.property("Position").setValue([0, 0]); ropeLayer.property("Anchor Point").setValue([0, 0]); var shapeGroup = ropeLayer.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group"); shapeGroup.name = "Rope Path"; var pathGroup = shapeGroup.property("ADBE Vectors Group").addProperty("ADBE Vector Shape - Group"); var pathProp = pathGroup.property("ADBE Vector Shape"); var safeL1Name = l1.name.replace(/'/g, "\\'"); var safeL2Name = l2.name.replace(/'/g, "\\'"); 
        var exprPath = "var _l1 = thisComp.layer('" + safeL1Name + "');\nvar _l2 = thisComp.layer('" + safeL2Name + "');\nvar p1 = _l1.toComp(_l1.anchorPoint);\nvar p2 = _l2.toComp(_l2.anchorPoint);\ncreatePath([[p1[0], p1[1]], [p2[0], p2[1]]], [], [], false);"; 
        pathProp.expression = exprPath; var trim = shapeGroup.property("ADBE Vectors Group").addProperty("ADBE Vector Filter - Trim"); trim.property("ADBE Vector Trim Start").expression = 'thisComp.layer("' + ctrlNull.name + '").effect("Trim Start %")(1);'; trim.property("ADBE Vector Trim End").expression = 'thisComp.layer("' + ctrlNull.name + '").effect("Trim End %")(1);'; var stroke = shapeGroup.property("ADBE Vectors Group").addProperty("ADBE Vector Graphic - Stroke"); stroke.property("ADBE Vector Stroke Color").expression = 'thisComp.layer("' + ctrlNull.name + '").effect("Rope Color")(1);'; stroke.property("ADBE Vector Stroke Width").expression = 'thisComp.layer("' + ctrlNull.name + '").effect("Stroke Thickness")(1);'; var waveFx = ropeLayer.property("Effects").addProperty("ADBE Wave Warp"); waveFx.property("Wave Height").expression = 'thisComp.layer("' + ctrlNull.name + '").effect("Wave Height")(1);'; waveFx.property("Wave Width").expression = 'thisComp.layer("' + ctrlNull.name + '").effect("Wave Width")(1);'; waveFx.property("Wave Speed").expression = 'thisComp.layer("' + ctrlNull.name + '").effect("Wave Speed")(1);'; ropeLayer.selected = false; } for (var j = 1; j <= comp.numLayers; j++) comp.layer(j).selected = false; ctrlNull.selected = true; }); };

        btnAround.onClick = function() { addUndo("Around Object Rig", function() { var comp = app.project.activeItem; if (!comp || !(comp instanceof CompItem) || comp.selectedLayers.length === 0) return alert("Select layers."); var layers = comp.selectedLayers; var tx = 0, ty = 0; for (var i=0; i<layers.length; i++) { var p = layers[i].property("Position").value; tx+=p[0]; ty+=p[1]; } var center = [tx/layers.length, ty/layers.length]; var ctrl = comp.layers.addNull(); ctrl.name = "Radial Controller"; ctrl.property("Anchor Point").setValue([50, 50]); ctrl.position.setValue([center[0], center[1], 0]); var fx = ctrl.property("Effects"); fx.addProperty("ADBE Slider Control").name = "Influence"; ctrl.effect("Influence")(1).setValue(100); fx.addProperty("ADBE Slider Control").name = "Radius"; ctrl.effect("Radius")(1).setValue(300); fx.addProperty("ADBE Slider Control").name = "Arc"; ctrl.effect("Arc")(1).setValue(360); fx.addProperty("ADBE Angle Control").name = "Start Angle"; fx.addProperty("ADBE Slider Control").name = "Random Offset"; fx.addProperty("ADBE Slider Control").name = "Random Seed"; fx.addProperty("ADBE Checkbox Control").name = "Orient to Center"; fx.addProperty("ADBE Angle Control").name = "Random Rotation"; var is3D = false; for(var i=0; i<layers.length; i++) { if(layers[i].threeDLayer) is3D = true; } if(is3D) { ctrl.threeDLayer = true; fx.addProperty("ADBE Angle Control").name = "Tilt X"; fx.addProperty("ADBE Angle Control").name = "Tilt Y"; fx.addProperty("ADBE Slider Control").name = "Random Offset Z"; } layers.sort(function(a,b){return a.index - b.index;}); for(var i=0; i<layers.length; i++) { var l = layers[i]; l.parent = ctrl; var expr = "var ctrl = thisLayer.parent;\nvar influence = ctrl.effect('Influence')(1) / 100;\nvar radius = ctrl.effect('Radius')(1);\nvar arc = ctrl.effect('Arc')(1);\nvar startAngle = ctrl.effect('Start Angle')(1);\nvar randomOffset = ctrl.effect('Random Offset')(1);\nvar randomSeed = ctrl.effect('Random Seed')(1);\nvar siblings = []; for (var i = 1; i <= thisComp.numLayers; i++) { var lyr = thisComp.layer(i); if (lyr.hasParent && lyr.parent.index == ctrl.index && lyr.index != ctrl.index) siblings.push(lyr.index); }\nsiblings.sort(function(a,b){return a-b;}); var totalLayers = siblings.length;\nvar myIndex = 0; for(var j=0; j<siblings.length; j++){ if(siblings[j] == thisLayer.index) { myIndex = j; break; } }\nvar blend = Math.max(0, Math.min(1, (arc - 270) / 90));\nvar angleStep = (totalLayers > 1) ? arc / (totalLayers - 1 + blend) : 0;\nvar angle = degreesToRadians(startAngle + (myIndex * angleStep));\nseedRandom(randomSeed + " + (i*1000) + ", true);\nvar randOffset = (random() - 0.5) * 2 * randomOffset;\nvar finalRadius = radius + randOffset;\nvar radialX = Math.cos(angle) * finalRadius;\nvar radialY = Math.sin(angle) * finalRadius;\n"; if (is3D) { expr += "var tiltX = degreesToRadians(ctrl.effect('Tilt X')(1));\nvar tiltY = degreesToRadians(ctrl.effect('Tilt Y')(1));\nvar randZ = (random() - 0.5) * 2 * ctrl.effect('Random Offset Z')(1);\nvar y1 = radialY * Math.cos(tiltX); var z1 = radialY * Math.sin(tiltX);\nvar x2 = radialX * Math.cos(tiltY) + z1 * Math.sin(tiltY);\nvar z2 = -radialX * Math.sin(tiltY) + z1 * Math.cos(tiltY);\nvar radialPos = [x2, y1, z2 + randZ];\n"; } else { expr += "var radialPos = [radialX, radialY];\n"; } expr += "linear(influence, 0, 1, value, radialPos);"; handleExpression(l.property("Position"), expr); var rotExpr = "var ctrl = thisLayer.parent;\nvar influence = ctrl.effect('Influence')(1) / 100;\nvar arc = ctrl.effect('Arc')(1);\nvar startAngle = ctrl.effect('Start Angle')(1);\nvar orient = ctrl.effect('Orient to Center')(1);\nvar randomRotation = ctrl.effect('Random Rotation')(1);\nvar randomSeed = ctrl.effect('Random Seed')(1);\nvar siblings = []; for (var i = 1; i <= thisComp.numLayers; i++) { var lyr = thisComp.layer(i); if (lyr.hasParent && lyr.parent.index == ctrl.index && lyr.index != ctrl.index) siblings.push(lyr.index); }\nsiblings.sort(function(a,b){return a-b;}); var totalLayers = siblings.length;\nvar myIndex = 0; for(var j=0; j<siblings.length; j++){ if(siblings[j] == thisLayer.index) { myIndex = j; break; } }\nvar blend = Math.max(0, Math.min(1, (arc - 270) / 90));\nvar angleStep = (totalLayers > 1) ? arc / (totalLayers - 1 + blend) : 0;\nvar radialAngle = startAngle + (myIndex * angleStep) + 90;\nseedRandom(randomSeed + " + (i*1000) + ", true);\nvar randRot = (random() - 0.5) * 2 * randomRotation;\nvar targetRot = (orient == 1) ? radialAngle + randRot + value : value + randRot;\nlinear(influence, 0, 1, value, targetRot);"; handleExpression(l.property("Rotation"), rotExpr); } for(var i=1; i<=comp.numLayers; i++) comp.layer(i).selected = false; ctrl.selected = true; }); };
        
        btnAutoPathRig.onClick = function() {
            var comp = app.project.activeItem;
            if(!comp) return alert("Please select a comp first!");

            var d = new Window("dialog", "Auto Path Rig Settings");
            d.orientation = "column"; d.margins = 20; d.spacing = 15;
            d.graphics.backgroundColor = d.graphics.newBrush(d.graphics.BrushType.SOLID_COLOR, [0.15, 0.15, 0.15]);

            var grpCount = d.add("group");
            var lblCount = grpCount.add("statictext", undefined, "How many Images/Videos?");
            lblCount.graphics.foregroundColor = d.graphics.newPen(d.graphics.PenType.SOLID_COLOR, [0.9,0.9,0.9], 1);
            var txtCount = grpCount.add("edittext", undefined, "6"); 
            txtCount.preferredSize.width = 50; txtCount.justify = "center";

            var btnGrp = d.add("group"); btnGrp.spacing = 10;
            var btnCancel = btnGrp.add("button", undefined, "Cancel");
            var btnOk = btnGrp.add("button", undefined, "Create Rig");

            btnCancel.onClick = function() { d.close(); };
            btnOk.onClick = function() {
                var count = parseInt(txtCount.text) || 6;
                d.close();

                addUndo("1-Click Path Rig", function() {
                    var sL = comp.layers.addShape();
                    sL.name = "path";
                    var sG = sL.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
                    sG.name = "Ellipse 1";
                    
                    var pG = sG.property("ADBE Vectors Group").addProperty("ADBE Vector Shape - Group");
                    pG.name = "Path 1";
                    var pathProp = pG.property("ADBE Vector Shape");
                    
                    var newShape = new Shape();
                    var w = comp.width * 0.6; var h = comp.height * 0.6;
                    var kx = (w/2) * 0.55228; var ky = (h/2) * 0.55228;
                    newShape.vertices = [[0, -h/2], [w/2, 0], [0, h/2], [-w/2, 0]];
                    newShape.inTangents = [[-kx, 0], [0, -ky], [kx, 0], [0, ky]];
                    newShape.outTangents = [[kx, 0], [0, ky], [-kx, 0], [0, -ky]];
                    newShape.closed = true;
                    pathProp.setValue(newShape);

                    var stk = sG.property("ADBE Vectors Group").addProperty("ADBE Vector Graphic - Stroke");
                    stk.property("ADBE Vector Stroke Width").setValue(2);
                    stk.property("ADBE Vector Stroke Color").setValue([1,1,1,1]);

                    var ctrl = comp.layers.addNull();
                    ctrl.name = "controller";
                    ctrl.property("Anchor Point").setValue([50, 50]);
                    
                    var fx = ctrl.property("Effects");
                    fx.addProperty("ADBE Checkbox Control").name = "Enable Scale"; ctrl.effect("Enable Scale")(1).setValue(1);
                    fx.addProperty("ADBE Checkbox Control").name = "Enable Rotation"; ctrl.effect("Enable Rotation")(1).setValue(1);
                    fx.addProperty("ADBE Slider Control").name = "max distance"; ctrl.effect("max distance")(1).setValue(200);
                    fx.addProperty("ADBE Slider Control").name = "min scale"; ctrl.effect("min scale")(1).setValue(25);
                    fx.addProperty("ADBE Slider Control").name = "layers rotation";
                    fx.addProperty("ADBE Slider Control").name = "max scale"; ctrl.effect("max scale")(1).setValue(40);
                    fx.addProperty("ADBE Angle Control").name = "rotation";
                    fx.addProperty("ADBE Slider Control").name = "Images Count"; ctrl.effect("Images Count")(1).setValue(count);

                    var exprPos = 'try{\n  var sc = thisComp.layer("controller");\n  var pLayer = thisComp.layer("path");\n  var el = pLayer.content("Ellipse 1").content("Path 1").path;\n  var r = sc.effect("rotation")(1);\n  var lc = Math.max(2, Math.min(30, sc.effect("Images Count")(1)));\n  var x = parseInt(thisLayer.name.split(" ")[1]) - 1;\n  if(isNaN(x)) x = index;\n  var t = ((x / lc) + (r / 360)) % 1.0;\n  if(t < 0) t += 1;\n  var pt = el.pointOnPath(t);\n  pLayer.toComp(pt);\n}catch(e){ value; }';
                    var exprScl = 'try{\n  var sc = thisComp.layer("controller");\n  if (sc.effect("Enable Scale")(1).value == 1) {\n    var distance = length(toWorld(transform.anchorPoint), sc.toWorld(sc.transform.anchorPoint));\n    var maxDist = sc.effect("max distance")(1);\n    var minS = sc.effect("min scale")(1);\n    var maxS = sc.effect("max scale")(1);\n    var scaleFactor = linear(distance, 0, maxDist, maxS/100, minS/100);\n    [scaleFactor * 100, scaleFactor * 100];\n  } else { value; }\n}catch(e){ value; }';
                    var exprRot = 'try{\n  var sc = thisComp.layer("controller");\n  if (sc.effect("Enable Rotation")(1).value == 1) {\n    var el = thisComp.layer("path").content("Ellipse 1").content("Path 1").path;\n    var r = sc.effect("rotation")(1);\n    var lc = Math.max(2, Math.min(30, sc.effect("Images Count")(1)));\n    var x = parseInt(thisLayer.name.split(" ")[1]) - 1;\n    if(isNaN(x)) x = index;\n    var t = ((x / lc) + (r / 360)) % 1.0;\n    if(t < 0) t += 1;\n    var tan = el.tangentOnPath(t);\n    var angleRad = Math.atan2(tan[1], tan[0]);\n    var lr = sc.effect("layers rotation")(1);\n    radiansToDegrees(angleRad) + lr;\n  } else { value; }\n}catch(e){ value; }';

                    for(var i=count; i>=1; i--) { 
                        var newComp = app.project.items.addComp("Image " + i, 1080, 1080, 1, comp.duration, comp.frameRate);
                        newComp.layers.addSolid([0.2, 0.6, 0.8], "Put Image Here", 1080, 1080, 1);
                        var newLayer = comp.layers.add(newComp);
                        newLayer.name = "Image " + i;

                        handleExpression(newLayer.property("Position"), exprPos);
                        handleExpression(newLayer.property("Scale"), exprScl);
                        handleExpression(newLayer.property("Rotation"), exprRot);
                    }
                    
                    ctrl.moveToBeginning();
                    sL.moveToBeginning();
                    for(var i=1; i<=comp.numLayers; i++) comp.layer(i).selected = false;
                    ctrl.selected = true; 
                });
            };
            d.show();
        };

        // --- SPACE BETWEEN LAYERS ---
        var pnlSpace = vProx.add("panel", undefined, "📏 Space Between Layers (Ctrl+Click to Bake)"); 
        pnlSpace.alignChildren = ["fill", "top"]; pnlSpace.margins = pnlMargins; pnlSpace.spacing = 2;
        var btnSpaceXYZR = pnlSpace.add("button", undefined, "🎯 X-Y-Z-R Smart Space");
        btnSpaceXYZR.alignment = ["fill", "top"];
        
        btnSpaceXYZR.onClick = function() {
            var comp = app.project.activeItem; if(!comp) return; 
            var selLayers = comp.selectedLayers.slice(0);
            if(selLayers.length === 0) return alert("Select layers to link first!"); 
            
            addUndo("Space X-Y-Z-R Link", function() { 
                var l = comp.layer("X-Y-Z-R"); 
                if(!l) { 
                    l=comp.layers.addNull(); l.name="X-Y-Z-R"; l.label=2; l.property("Anchor Point").setValue([50, 50]); 
                    var fx = l.property("Effects"); 
                    fx.addProperty("ADBE Slider Control").name="Space X"; 
                    fx.addProperty("ADBE Slider Control").name="Space Y"; 
                    fx.addProperty("ADBE Slider Control").name="Space Z"; 
                    var srFx = fx.addProperty("ADBE Slider Control"); srFx.name = "Space Rotation"; srFx.property(1).setValue(0); 
                } 
                
                for(var i=1; i<=comp.numLayers; i++) comp.layer(i).selected = false;
                for(var i=0; i<selLayers.length; i++) selLayers[i].selected = true;
                
                var minIdx = selLayers[0].index; 
                for(var i=1; i<selLayers.length; i++) { if(selLayers[i].index < minIdx) minIdx = selLayers[i].index; }
                for(var i=0; i<selLayers.length; i++) { 
                    var layer = selLayers[i]; layer.threeDLayer = true;
                    var expr = 'var sx=0, sy=0, sz=0, sr=0;\n' + 
                    'var spc=null;\n' + 
                    'try{\n  spc=thisComp.layer("X-Y-Z-R");\n  if(spc!=null){\n    var myRelIdx = index - ' + minIdx + ';\n    sx=spc.effect("Space X")(1)*myRelIdx;\n    sy=spc.effect("Space Y")(1)*myRelIdx;\n    sz=spc.effect("Space Z")(1)*myRelIdx;\n    sr=spc.effect("Space Rotation")(1)*myRelIdx;\n  }\n}catch(e){}\n' + 
                    'var basePos = (value.length >= 3) ? value + [sx, sy, sz] : value + [sx, sy];\n' + 
                    'if (spc != null) {\n' + 
                    '  var nullPos = spc.toComp(spc.anchorPoint);\n' + 
                    '  var vec = basePos - nullPos;\n' + 
                    '  var rad = degreesToRadians(sr);\n' + 
                    '  var cos = Math.cos(rad), sin = Math.sin(rad);\n' + 
                    '  var nx = vec[0]*cos - vec[1]*sin;\n' + 
                    '  var ny = vec[0]*sin + vec[1]*cos;\n' + 
                    '  (basePos.length >= 3) ? [nullPos[0] + nx, nullPos[1] + ny, basePos[2]] : [nullPos[0] + nx, nullPos[1] + ny];\n' + 
                    '} else {\n' + 
                    '  basePos;\n' + 
                    '}';
                    handleExpression(layer.property("Transform").property("Position"), expr);
                    
                    var rProp = layer.property("Transform").property("Rotation");
                    if (layer.threeDLayer && layer.property("Transform").property("Z Rotation")) rProp = layer.property("Transform").property("Z Rotation");
                    var rExpr = 'try{\n  var spc = thisComp.layer("X-Y-Z-R");\n  value + (spc.effect("Space Rotation")(1) * (index - ' + minIdx + '));\n}catch(e){ value; }';
                    handleExpression(rProp, rExpr);
                }
            });
        };

        var pnlProxScale = vProx.add("panel", undefined, "🔍 Promixly Scale (Ctrl+Click to Bake)"); pnlProxScale.alignChildren = ["fill", "top"]; pnlProxScale.margins = pnlMargins; pnlProxScale.spacing = 2;
        var btnProxScaleApply = pnlProxScale.add("button", undefined, "🎯 Null Scale");
        btnProxScaleApply.alignment = ["fill", "top"];
        btnProxScaleApply.onClick = function() {
            var comp = app.project.activeItem; if(!comp) return alert("Select a comp first!");
            var selLayers = comp.selectedLayers.slice(0); 
            if(selLayers.length === 0) return alert("Select layers to apply the scale effect!");
            
            addUndo("Null Scale", function() {
                var l = comp.layer("Effector");
                if(!l) {
                    l = comp.layers.addNull(); l.name = "Effector"; l.property("Anchor Point").setValue([50, 50]);
                    var fx = l.property("Effects");
                    fx.addProperty("ADBE Slider Control").name = "Radius"; l.effect("Radius")(1).setValue(100);
                    fx.addProperty("ADBE Slider Control").name = "Radius Strength"; 
                    fx.addProperty("ADBE Slider Control").name = "Scale To"; l.effect("Scale To")(1).setValue(150);
                }
                
                var expr = 'var eff = null;\ntry{ eff = thisComp.layer("Effector"); }catch(e){}\nif(eff != null){\n  var p1 = thisLayer.toWorld(thisLayer.anchorPoint);\n  var p2 = eff.toWorld(eff.anchorPoint);\n  var d = length(p1, p2);\n  var r = eff.effect("Radius")(1);\n  var rStr = eff.effect("Radius Strength")(1);\n  var valTo = eff.effect("Scale To")(1);\n  var valFrom = value[0];\n  var fVal = linear(d, r, rStr, valTo, valFrom);\n  if(value.length == 3) [fVal, fVal, fVal]; else [fVal, fVal];\n} else { value; }';
                
                for (var i=0; i<selLayers.length; i++) {
                    var sl = selLayers[i];
                    handleExpression(sl.property("Transform").property("Scale"), expr);
                }
                
                for(var i=1; i<=comp.numLayers; i++) comp.layer(i).selected = false;
                l.selected = true; 
            });
        };

        // --- UI STYLE (Z-POSITION & FX) ---
        var pnlZ = vProx.add("panel", undefined, "🏔️ UI Style (Z-Position & FX)");
        pnlZ.alignChildren = ["fill", "top"]; pnlZ.margins = pnlMargins; pnlZ.spacing = 2;
        var btnUIStyle = pnlZ.add("button", undefined, "🎯 UI Style");
        btnUIStyle.alignment = ["fill", "top"];

        btnUIStyle.onClick = function() {
            var comp = app.project.activeItem;
            if(!comp) return alert("Please select a comp first!");
            var selLayers = comp.selectedLayers.slice(0);
            if(selLayers.length === 0) return alert("Select layers to apply UI Style!");

            var d = new Window("dialog", "UI Style Settings");
            d.orientation = "column"; d.margins = 20; d.spacing = 15;
            d.graphics.backgroundColor = d.graphics.newBrush(d.graphics.BrushType.SOLID_COLOR, [0.15, 0.15, 0.15]);

            var grpType = d.add("group");
            var lblType = grpType.add("statictext", undefined, "Layer Type:");
            lblType.graphics.foregroundColor = d.graphics.newPen(d.graphics.PenType.SOLID_COLOR, [0.9,0.9,0.9], 1);
            
            var dropType = grpType.add("dropdownlist", undefined, ["🖼️ Comp / PNG", "🔺 Shape"]);
            dropType.selection = 0;

            var btnGrp = d.add("group"); btnGrp.spacing = 10;
            var btnCancel = btnGrp.add("button", undefined, "Cancel");
            var btnOk = btnGrp.add("button", undefined, "Apply Rig");

            btnCancel.onClick = function() { d.close(); };
            btnOk.onClick = function() {
                var isShapeMode = (dropType.selection.index === 1);
                d.close();

                addUndo("Apply UI Style", function() {
                    // 1. Create UI Controller
                    var ctrl = comp.layer("UI Controller");
                    if (!ctrl) {
                        ctrl = comp.layers.addNull();
                        ctrl.name = "UI Controller";
                        ctrl.label = 2;
                        ctrl.property("Anchor Point").setValue([50, 50]);

                        var fx = ctrl.property("Effects");
                        
                        fx.addProperty("ADBE Slider Control").name = "Range"; ctrl.effect("Range")(1).setValue(200);

                        fx.addProperty("ADBE Checkbox Control").name = "Enable X"; ctrl.effect("Enable X")(1).setValue(0);
                        fx.addProperty("ADBE Slider Control").name = "X Shift"; ctrl.effect("X Shift")(1).setValue(0);

                        fx.addProperty("ADBE Checkbox Control").name = "Enable Y"; ctrl.effect("Enable Y")(1).setValue(0);
                        fx.addProperty("ADBE Slider Control").name = "Y Shift"; ctrl.effect("Y Shift")(1).setValue(0);

                        fx.addProperty("ADBE Checkbox Control").name = "Enable Z"; ctrl.effect("Enable Z")(1).setValue(1);
                        fx.addProperty("ADBE Slider Control").name = "Z Shift"; ctrl.effect("Z Shift")(1).setValue(-200);

                        fx.addProperty("ADBE Checkbox Control").name = "Enable Shadow"; ctrl.effect("Enable Shadow")(1).setValue(0);
                        fx.addProperty("ADBE Slider Control").name = "Shdw Dist Max"; ctrl.effect("Shdw Dist Max")(1).setValue(45);
                        fx.addProperty("ADBE Slider Control").name = "Shdw Opac Max"; ctrl.effect("Shdw Opac Max")(1).setValue(50);
                        fx.addProperty("ADBE Slider Control").name = "Shdw Soft Max"; ctrl.effect("Shdw Soft Max")(1).setValue(11);

                        fx.addProperty("ADBE Checkbox Control").name = "Enable Fade Opac"; ctrl.effect("Enable Fade Opac")(1).setValue(1);
                        fx.addProperty("ADBE Slider Control").name = "Opac Radius"; ctrl.effect("Opac Radius")(1).setValue(200);
                        fx.addProperty("ADBE Slider Control").name = "Opac Strength"; ctrl.effect("Opac Strength")(1).setValue(100);

                        fx.addProperty("ADBE Checkbox Control").name = "Enable Col Shift"; ctrl.effect("Enable Col Shift")(1).setValue(0);
                        fx.addProperty("ADBE Color Control").name = "End Color"; ctrl.effect("End Color")("Color").setValue([1,0,0,1]);
                        fx.addProperty("ADBE Slider Control").name = "Color Radius"; ctrl.effect("Color Radius")(1).setValue(200);

                        var bModeFx = fx.addProperty("ADBE Solid Composite");
                        bModeFx.name = "Bazan Blend Mode";
                        try { bModeFx.property("Opacity").setValue(0); } catch(e){}
                    }

                    // 2. Setup Exact Original Expressions (Clean & Bulletproof)
var posExpr = "var offX=0, offY=0, offZ=0;\n" +
"try{\n" +
"  var ctrl = thisComp.layer('UI Controller');\n" +
"  if(ctrl != null){\n" +
"    var rng = ctrl.effect('Range')(1).value;\n" +
"    var ctrlPos = ctrl.toWorld(ctrl.anchorPoint);\n" +
"    var myPos = toWorld(anchorPoint);\n" +
"    var d = length([myPos[0], myPos[1]], [ctrlPos[0], ctrlPos[1]]);\n" +
"    var factor = ease(d, 0, rng, 1, 0);\n" +
"    if(ctrl.effect('Enable X')(1).value) offX = factor * ctrl.effect('X Shift')(1).value;\n" +
"    if(ctrl.effect('Enable Y')(1).value) offY = factor * ctrl.effect('Y Shift')(1).value;\n" +
"    if(ctrl.effect('Enable Z')(1).value) offZ = factor * ctrl.effect('Z Shift')(1).value;\n" +
"  }\n" +
"}catch(e){}\n" +
"(value.length >= 3) ? value + [offX, offY, offZ] : value + [offX, offY];";

var opacExpr = "var ctrl=null;\ntry{ctrl=thisComp.layer('UI Controller');}catch(e){}\nif(ctrl!=null && ctrl.effect('Enable Fade Opac')(1).value){\n  var ctrlPos=ctrl.toWorld(ctrl.anchorPoint);\n  var myPos=toWorld(anchorPoint);\n  var dist=length([myPos[0],myPos[1]], [ctrlPos[0],ctrlPos[1]]);\n  var infl=linear(dist, 0, ctrl.effect('Opac Radius')(1).value, 1, 0);\n  linear(infl, 0, 1, 100 - clamp(ctrl.effect('Opac Strength')(1).value,0,100), 100);\n}else{value;}";

var shdwDistExpr = "var ctrl=null;\ntry{ctrl=thisComp.layer('UI Controller');}catch(e){}\nif(ctrl!=null){\n  var rng=ctrl.effect('Range')(1).value;\n  var ctrlPos=ctrl.toWorld(ctrl.anchorPoint);\n  var myPos=toWorld(anchorPoint);\n  var d=length([myPos[0],myPos[1]], [ctrlPos[0],ctrlPos[1]]);\n  var factor=ease(d,0,rng,1,0);\n  linear(factor,0,1,0,ctrl.effect('Shdw Dist Max')(1).value);\n}else{value;}";

var shdwOpacExpr = "var ctrl=null;\ntry{ctrl=thisComp.layer('UI Controller');}catch(e){}\nif(ctrl!=null){\n  if(ctrl.effect('Enable Shadow')(1).value){\n    var rng=ctrl.effect('Range')(1).value;\n    var ctrlPos=ctrl.toWorld(ctrl.anchorPoint);\n    var myPos=toWorld(anchorPoint);\n    var d=length([myPos[0],myPos[1]], [ctrlPos[0],ctrlPos[1]]);\n    var factor=ease(d,0,rng,1,0);\n    linear(factor,0,1,0,ctrl.effect('Shdw Opac Max')(1).value);\n  }else{0;}\n}else{value;}";

var shdwSoftExpr = "var ctrl=null;\ntry{ctrl=thisComp.layer('UI Controller');}catch(e){}\nif(ctrl!=null){\n  var rng=ctrl.effect('Range')(1).value;\n  var ctrlPos=ctrl.toWorld(ctrl.anchorPoint);\n  var myPos=toWorld(anchorPoint);\n  var d=length([myPos[0],myPos[1]], [ctrlPos[0],ctrlPos[1]]);\n  var factor=ease(d,0,rng,1,0);\n  linear(factor,0,1,0,ctrl.effect('Shdw Soft Max')(1).value);\n}else{value;}";

var shapeColExpr = "var ctrl=null;\ntry{ctrl=thisComp.layer('UI Controller');}catch(e){}\nif(ctrl!=null && ctrl.effect('Enable Col Shift')(1).value){\n  var ctrlPos=ctrl.toWorld(ctrl.anchorPoint);\n  var myPos=toWorld(anchorPoint);\n  var dist=length([myPos[0],myPos[1]], [ctrlPos[0],ctrlPos[1]]);\n  var infl=linear(dist, 0, ctrl.effect('Color Radius')(1).value, 1, 0);\n  linear(infl, 0, 1, value, ctrl.effect('End Color')(1).value);\n}else{value;}";

                    function applyToShapeFills(layer, exprStr) {
                        function scanGrp(grp) {
                            for(var k=1; k<=grp.numProperties; k++) {
                                var p = grp.property(k);
                                if(p.matchName === "ADBE Vector Graphic - Fill") {
                                    var cProp = p.property("Color");
                                    if(cProp.canSetExpression) cProp.expression = exprStr;
                                } else if(p.propertyType === PropertyType.INDEXED_GROUP || p.propertyType === PropertyType.NAMED_GROUP) {
                                    scanGrp(p);
                                }
                            }
                        }
                        scanGrp(layer.property("ADBE Root Vectors Group"));
                    }

                    for (var i = 0; i < selLayers.length; i++) {
                        var sl = selLayers[i];
                        sl.threeDLayer = true;

                        handleExpression(sl.property("Transform").property("Position"), posExpr);
                        handleExpression(sl.property("Transform").property("Opacity"), opacExpr);

                        if(isShapeMode) {
                            if(sl instanceof ShapeLayer) {
                                applyToShapeFills(sl, shapeColExpr);
                            } else {
                                alert("Layer '" + sl.name + "' is not a Shape Layer! Color Shift skipped.");
                            }
                        } else {
                            var fillBlend = manageEffect(sl, "ADBE Solid Composite", "Color Shift Blend");
                            if (fillBlend) {
                                var colExpr = "var cLayer=null;\ntry{cLayer=thisComp.layer(\"UI Controller\");}catch(e){}\nif(cLayer!=null && cLayer.effect(\"Enable Col Shift\")(1).value == 1){ cLayer.effect(\"End Color\")(1); } else { value; }";
                                var colOpacExpr = "var cLayer=null;\ntry{cLayer=thisComp.layer(\"UI Controller\");}catch(e){}\nif(cLayer!=null && cLayer.effect(\"Enable Col Shift\")(1).value == 1){\n  var dist=length([toWorld(anchorPoint)[0],toWorld(anchorPoint)[1]], cLayer.position);\n  var infl=linear(dist, 0, cLayer.effect(\"Color Radius\")(1), 1, 0);\n  linear(infl, 0, 1, 0, 100);\n}else{0;}";
                                var modeExpr = "try{\n  var ctrl = thisComp.layer('UI Controller');\n  if(ctrl.effect('Enable Col Shift')(1).value == 1){\n    ctrl.effect('Bazan Blend Mode')(4).value;\n  }else{\n    value;\n  }\n}catch(e){ value; }";

handleExpression(fillBlend.property("Color"), colExpr);
handleExpression(fillBlend.property("Opacity"), colOpacExpr);
handleExpression(fillBlend.property(4), modeExpr);
                            }
                        }

                        // Drop Shadow
                        var dropFx = manageEffect(sl, "ADBE Drop Shadow", "Drop Shadow");
                        if(dropFx) {
                            dropFx.property("Direction").setValue(180);
                            handleExpression(dropFx.property("Distance"), shdwDistExpr);
                            handleExpression(dropFx.property("Opacity"), shdwOpacExpr);
                            handleExpression(dropFx.property("Softness"), shdwSoftExpr);
                        }
                    }

                    for(var i=1; i<=comp.numLayers; i++) comp.layer(i).selected = false;
                    ctrl.selected = true;
                });
            };
            d.show();
        };

        // =========================================================
        // TAB 3: MASKS, & Z-SPACE
        // =========================================================
        function executeMaskSplitter() { var comp = app.project.activeItem; if (!comp || !(comp instanceof CompItem)) return alert("Please open a composition first."); var selected = comp.selectedLayers; if (selected.length === 0) return alert("Please select at least one layer with masks to split."); addUndo("Split Masks to Layers", function() { var layersProcessed = 0; var newLayers = []; for (var i = 0; i < selected.length; i++) { var layer = selected[i]; var masks = layer.property("ADBE Mask Parade"); if (!masks || masks.numProperties === 0) continue; var numMasks = masks.numProperties; layersProcessed++; for (var m = 1; m <= numMasks; m++) { var dupLayer = layer.duplicate(); dupLayer.name = layer.name + " (Mask " + m + ")"; var dupMasks = dupLayer.property("ADBE Mask Parade"); for (var j = numMasks; j >= 1; j--) { if (j !== m) dupMasks.property(j).remove(); } if (dupMasks.numProperties > 0) dupMasks.property(1).maskMode = MaskMode.ADD; newLayers.push(dupLayer); } layer.enabled = false; } for (var s = 0; s < comp.selectedLayers.length; s++) comp.selectedLayers[s].selected = false; for (var k = 0; k < newLayers.length; k++) { newLayers[k].selected = true; app.executeCommand(3973); newLayers[k].selected = false; } if (layersProcessed === 0) alert("No Masks Found on selected layers."); }); }
        var pnlMaskSplit = vZSpace.add("panel", undefined, "✂️ Mask & Layer Splitter"); pnlMaskSplit.alignChildren = ["fill", "top"]; pnlMaskSplit.margins = pnlMargins; pnlMaskSplit.spacing = 2; var btnSplitMasks = pnlMaskSplit.add("button", undefined, "✂️ Split Masks to Layers"); btnSplitMasks.alignment = ["fill", "top"]; btnSplitMasks.onClick = executeMaskSplitter;

        var pnlDepth = vZSpace.add("panel", undefined, "🌌 Z-Space (Depth Layers)"); pnlDepth.alignChildren = ["fill", "top"]; pnlDepth.margins = pnlMargins; pnlDepth.spacing = 2;
        var grpD1 = pnlDepth.add("group"); grpD1.orientation = "row"; grpD1.alignChildren = ["fill", "center"]; grpD1.spacing = 2; grpD1.add("statictext", undefined, "Lens:"); var dropFocal = grpD1.add("dropdownlist", undefined, ['15mm','20mm','24mm','28mm','35mm','50mm','80mm','135mm','200mm']); dropFocal.selection = 5; dropFocal.alignment = ["fill", "center"];
        var grpD2 = pnlDepth.add("group"); grpD2.orientation = "row"; grpD2.alignChildren = ["fill", "center"]; grpD2.spacing = 2; grpD2.add("statictext", undefined, "Dist:"); var txtDist = grpD2.add("edittext", undefined, "0"); txtDist.alignment = ["fill", "center"]; grpD2.add("statictext", undefined, "Space:"); var txtSpace = grpD2.add("edittext", undefined, "1000"); txtSpace.alignment = ["fill", "center"];
        var grpD3 = pnlDepth.add("group"); grpD3.orientation = "row"; grpD3.alignChildren = ["fill", "center"]; grpD3.spacing = 2; var chkCamNull = grpD3.add("checkbox", undefined, "Cam Null"); chkCamNull.value = true;
        var grpD4 = pnlDepth.add("group"); grpD4.orientation = "row"; grpD4.alignChildren = ["fill", "top"]; grpD4.spacing = 2; var btnDisperse = grpD4.add("button", undefined, "Disperse"); btnDisperse.alignment = ["fill", "top"]; var btnMove = grpD4.add("button", undefined, "Move"); btnMove.alignment = ["fill", "top"];
        function executeDepth(isMove) { var lens = parseFloat(dropFocal.selection.text); var distribution = parseFloat(txtSpace.text); var zOffset = parseFloat(txtDist.text); var createNull = chkCamNull.value; var activeComp = app.project.activeItem; if (!activeComp || !(activeComp instanceof CompItem)) return alert("Select layers."); if (isNaN(distribution) || isNaN(zOffset)) return alert("Numbers only please!"); var hHeight = activeComp.height/2; var hWidth = activeComp.width/2; var layers = activeComp.selectedLayers; if (layers.length === 0) return alert("Select layers."); layers.sort(function(a,b){return a.index-b.index}); var camFocalLength = lens*0.02777777777778*hWidth*2; var curCamNull, curCamera; addUndo(isMove ? "Z Space Move" : "Z Space Disperse", function() { if(activeComp.activeCamera == null){ var camera = activeComp.layers.addCamera(dropFocal.selection.text, [hWidth, hHeight]); camera.position.setValue([hWidth,hHeight,-camFocalLength]); camera.Zoom.setValue(camFocalLength); camera.focusDistance.setValue(camFocalLength); if (createNull){ var camNull = activeComp.layers.addNull(); camNull.name = "Camera Controller"; camNull.threeDLayer = true; camNull.property("Anchor Point").setValue([50, 50]); camNull.position.setValue([hWidth,hHeight,-camFocalLength]); camera.parent = camNull; } } if(activeComp.activeCamera !== null){ curCamera = activeComp.activeCamera; camFocalLength = curCamera.zoom.value; var tempCamNull = activeComp.layers.addNull(); tempCamNull.threeDLayer = true; tempCamNull.position.setValue([0,0,0]); tempCamNull.setParentWithJump(curCamera); tempCamNull.parent = null; if(!isMove) zOffset = zOffset-(tempCamNull.position.value[2]+camFocalLength); else zOffset = zOffset-(camFocalLength+tempCamNull.position.value[2]); tempCamNull.remove(); curCamNull = activeComp.layers.addNull(); curCamNull.threeDLayer = true; curCamNull.property("Anchor Point").setValue([50, 50]); curCamNull.position.setValue([hWidth, hHeight,-(curCamera.zoom.value)]); } var ignoreFactor = 0; for (var i=1; i<=layers.length; i++){ var curLayer = layers[i-1]; var zPos = isMove ? zOffset : (i-1-ignoreFactor)*distribution+zOffset; if(!(curLayer instanceof LightLayer) && !(curLayer instanceof CameraLayer)){ if (!curLayer.threeDLayer) curLayer.threeDLayer = true; if(curLayer.parent == null){ var tranNull = activeComp.layers.addNull(); tranNull.threeDLayer = true; curLayer.parent = tranNull; tranNull.position.setValue([hWidth,hHeight,zPos]); var sParentScale = tranNull.scale.value[2]+((tranNull.scale.value[2]*zPos)/camFocalLength); tranNull.scale.setValue([sParentScale,sParentScale,sParentScale]); tranNull.remove(); if(activeComp.activeCamera !== null) curLayer.parent = curCamNull; } else ignoreFactor++; } else ignoreFactor++; } if (layers.length == ignoreFactor){ if(curCamNull) curCamNull.remove(); alert("Need unparented 2D layer!"); } else { if(activeComp.activeCamera !== null) { if(isMove){ for (var d=1; d<=layers.length; d++){ if(layers[d-1].parent == curCamNull) layers[d-1].parent = null; } } curCamNull.position.setValue([0,0,0]); curCamNull.setParentWithJump(curCamera); curCamNull.parent = null; curCamNull.remove(); } } }); }
        btnDisperse.onClick = function() { executeDepth(false); }; btnMove.onClick = function() { executeDepth(true); };

        var pnlSmart = vZSpace.add("panel", undefined, "🖌️ Smart Fill (Ctrl+Click to Bake)"); pnlSmart.alignChildren = ["fill", "top"]; pnlSmart.margins = pnlMargins; pnlSmart.spacing = 2;
        var grpCF = pnlSmart.add("group"); grpCF.orientation="row"; grpCF.alignChildren=["fill","center"]; grpCF.spacing=2;
        grpCF.add("statictext", undefined, "From:"); var btnC1 = grpCF.add("custombutton", undefined, ""); btnC1.preferredSize.width=40; btnC1.preferredSize.height=20; btnC1.alignment=["fill","center"]; var rgb1=[0.8,0.1,0.2]; btnC1.onDraw=function(){var g=this.graphics;g.newPath();g.rectPath(0,0,this.size[0],this.size[1]);g.fillPath(g.newBrush(g.BrushType.SOLID_COLOR,rgb1));}; btnC1.onClick=function(){var h=$.colorPicker();if(h!==-1){rgb1=[(h>>16)/255,((h>>8)&0xFF)/255,(h&0xFF)/255]; forceRedraw(this); }};
        grpCF.add("statictext", undefined, "To:"); var btnC2 = grpCF.add("custombutton", undefined, ""); btnC2.preferredSize.width=40; btnC2.preferredSize.height=20; btnC2.alignment=["fill","center"]; var rgb2=[0.1,0.5,0.8]; btnC2.onDraw=function(){var g=this.graphics;g.newPath();g.rectPath(0,0,this.size[0],this.size[1]);g.fillPath(g.newBrush(g.BrushType.SOLID_COLOR,rgb2));}; btnC2.onClick=function(){var h=$.colorPicker();if(h!==-1){rgb2=[(h>>16)/255,((h>>8)&0xFF)/255,(h&0xFF)/255]; forceRedraw(this); }};
        var grpO = pnlSmart.add("group"); grpO.orientation="row"; grpO.alignChildren=["fill","center"]; grpO.spacing=2; grpO.add("statictext", undefined, "Opac:"); var sldO = grpO.add("slider", undefined, 100, 0, 100); sldO.alignment=["fill","center"]; var txtO = grpO.add("statictext", undefined, "100%"); txtO.preferredSize.width=35; sldO.onChanging = function(){txtO.text=Math.round(this.value)+"%";};
        var btnApplyFill = pnlSmart.add("button", undefined, "🎨 Apply Fill"); btnApplyFill.alignment=["fill","top"];
        btnApplyFill.onClick = function() { addUndo("Smart Fill", function() { var comp = app.project.activeItem; if (!comp || comp.selectedLayers.length === 0) return; var alt = ScriptUI.environment.keyboardState.altKey; for (var i = 0; i < comp.selectedLayers.length; i++) { var fx = comp.selectedLayers[i].property("Effects"); if (alt) { if (fx.property("Color From")) fx.property("Color From").remove(); if (fx.property("Color To")) fx.property("Color To").remove(); if (fx.property("Color Transition %")) fx.property("Color Transition %").remove(); if (fx.property("Bazan Fill")) fx.property("Bazan Fill").remove(); continue; } if (fx.property("Color From")) { fx.property("Color From").remove(); fx.property("Color To").remove(); fx.property("Color Transition %").remove(); fx.property("Bazan Fill").remove(); } var cFrom = fx.addProperty("ADBE Color Control"); cFrom.name = "Color From"; cFrom.property("Color").setValue([rgb1[0], rgb1[1], rgb1[2], 1]); var cTo = fx.addProperty("ADBE Color Control"); cTo.name = "Color To"; cTo.property("Color").setValue([rgb2[0], rgb2[1], rgb2[2], 1]); fx.addProperty("ADBE Slider Control").name = "Color Transition %"; var fill = fx.addProperty("ADBE Fill"); fill.name = "Bazan Fill"; if (fill.property("Opacity")) fill.property("Opacity").setValue(sldO.value/100); if (fill.property("Color")) handleExpression(fill.property("Color"), "var c1 = effect('Color From')('Color');\nvar c2 = effect('Color To')('Color');\nvar tr = clamp(effect('Color Transition %')(1), 0, 100);\nlinear(tr, 0, 100, c1, c2);"); } }); };

        // --- PULL IN AE PANEL (UPDATED) ---
        var pnlPull = vZSpace.add("panel", undefined, "📥 Pull in AE (From Illustrator)");
        pnlPull.alignChildren = ["fill", "top"]; pnlPull.margins = pnlMargins; pnlPull.spacing = 2;

        var chkGroupLayers = pnlPull.add("checkbox", undefined, "📦 Group by Illustrator Layer");
        chkGroupLayers.value = true; 

        var btnPullAction = pnlPull.add("custombutton", undefined, "");
        btnPullAction.alignment = ["fill", "top"];
        btnPullAction.preferredSize = [-1, 45];
        btnPullAction.onDraw = function() {
            var g = this.graphics;
            var w = this.size[0]; var h = this.size[1];
            
            g.newPath(); g.rectPath(0, 0, w, h);
            g.fillPath(g.newBrush(g.BrushType.SOLID_COLOR, [0.18, 0.18, 0.18, 1]));
            
            var cx = w / 2;
            var cy = h / 2 - 6; 
            
            g.newPath();
            g.moveTo(cx - 16, cy);      
            g.lineTo(cx - 4, cy - 8);   
            g.lineTo(cx - 4, cy - 3);   
            g.lineTo(cx + 16, cy - 3);  
            g.lineTo(cx + 16, cy + 3);  
            g.lineTo(cx - 4, cy + 3);   
            g.lineTo(cx - 4, cy + 8);   
            g.fillPath(g.newBrush(g.BrushType.SOLID_COLOR, [1, 0.3, 0.3, 1]));
            
            var textStr = "Pull in AE";
            var textPen = g.newPen(g.PenType.SOLID_COLOR, [0.8, 0.8, 0.8, 1], 1);
            g.drawString(textStr, textPen, cx - 25, cy + 14, g.font);
        };
        
        btnPullAction.onClick = function() {
            app.beginUndoGroup("Pull in AE");
            try {
                var comp = app.project.activeItem;
                if (!comp || !(comp instanceof CompItem)) {
                    alert("Please open a Composition first!");
                    return;
                }

                var dataFile = new File("~/Desktop/ai_to_ae_data.json");
                if (!dataFile.exists) {
                    alert("No data found! Please push from Illustrator first.");
                    return; 
                }

                dataFile.open("r"); 
                var content = dataFile.read(); 
                dataFile.close();
                
                if (!content || content.length === 0) return;

                var transferData = [];
                try { transferData = eval("(" + content + ")"); } 
                catch(e) { alert("Data reading error!"); return; }
                
                if (!transferData || transferData.length === 0) return;

                var isGrouped = chkGroupLayers.value;
                var masterNull = comp.layers.addNull();
                masterNull.name = "AI Shapes Controller";
                masterNull.label = 10;
                masterNull.property("Position").setValue([comp.width/2, comp.height/2]);

                var importedLayers = [];
                var minX = 999999, minY = 999999, maxX = -999999, maxY = -999999;

                if (isGrouped) {
                    var groups = {};
                    var groupOrder = [];
                    
                    for (var i = 0; i < transferData.length; i++) {
                        var d = transferData[i];
                        
                        var lName = d.layerName || d.layer || d.parentLayer;
                        
                        if (!lName || lName === "AI Layer" || lName === "undefined") {
                            lName = (d.name && d.name !== "AI Layer") ? d.name : "Shape " + (i + 1);
                        }
                        
                        if (!groups[lName]) {
                            groups[lName] = [];
                            groupOrder.push(lName);
                        }
                        groups[lName].push(d);
                    }

                    for (var g = groupOrder.length - 1; g >= 0; g--) {
                        var currentLayerName = groupOrder[g];
                        var shapesInThisLayer = groups[currentLayerName];

                        var shapeLayer = comp.layers.addShape();
                        shapeLayer.name = currentLayerName; 
                        shapeLayer.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([0, 0]);
                        shapeLayer.property("ADBE Transform Group").property("ADBE Position").setValue([comp.width/2, comp.height/2]);
                        importedLayers.push(shapeLayer);

                        var targetRoot = shapeLayer.property("ADBE Root Vectors Group");

                        for (var idx = 0; idx < shapesInThisLayer.length; idx++) {
                            var data = shapesInThisLayer[idx];
                            var mainGroup = targetRoot.addProperty("ADBE Vector Group");
                            mainGroup.name = (data.name && data.name !== "AI Layer") ? data.name : "Group " + (idx + 1); 
                            var groupContents = mainGroup.property(2);

                            for (var p = 0; p < data.paths.length; p++) {
                                var pathData = data.paths[p];
                                var pathGroup = groupContents.addProperty("ADBE Vector Shape - Group");
                                pathGroup.name = "Path " + (p + 1);
                                var pathProp = pathGroup.property("ADBE Vector Shape");

                                var newShape = new Shape();
                                newShape.vertices = pathData.vertices;
                                newShape.inTangents = pathData.inTangents;
                                newShape.outTangents = pathData.outTangents;
                                newShape.closed = pathData.closed;
                                pathProp.setValue(newShape);
                                
                                for (var v = 0; v < pathData.vertices.length; v++) {
                                    var vx = pathData.vertices[v][0];
                                    var vy = pathData.vertices[v][1];
                                    if (vx < minX) minX = vx;
                                    if (vy < minY) minY = vy;
                                    if (vx > maxX) maxX = vx;
                                    if (vy > maxY) maxY = vy;
                                }
                            }

                            if (data.hasFill) {
                                var fillProp = groupContents.addProperty("ADBE Vector Graphic - Fill");
                                fillProp.property("ADBE Vector Fill Color").setValue(data.fillColor);
                            }
                            
                            if (data.hasStroke) {
                                var strokeProp = groupContents.addProperty("ADBE Vector Graphic - Stroke");
                                strokeProp.property("ADBE Vector Stroke Color").setValue(data.strokeColor);
                                strokeProp.property("ADBE Vector Stroke Width").setValue(data.strokeWidth);
                            }
                        }
                    }
                } else {
                    for (var i = transferData.length - 1; i >= 0; i--) {
                        var data = transferData[i];
                        var shapeLayer = comp.layers.addShape();
                        shapeLayer.name = (data.name && data.name !== "AI Layer") ? data.name : "Shape " + (i + 1);
                        shapeLayer.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([0, 0]);
                        shapeLayer.property("ADBE Transform Group").property("ADBE Position").setValue([comp.width/2, comp.height/2]);
                        importedLayers.push(shapeLayer);
                        
                        var targetRoot = shapeLayer.property("ADBE Root Vectors Group");
                        var mainGroup = targetRoot.addProperty("ADBE Vector Group");
                        mainGroup.name = "Contents";
                        var groupContents = mainGroup.property(2);

                        for (var p = 0; p < data.paths.length; p++) {
                            var pathData = data.paths[p];
                            var pathGroup = groupContents.addProperty("ADBE Vector Shape - Group");
                            pathGroup.name = "Path " + (p + 1);
                            var pathProp = pathGroup.property("ADBE Vector Shape");
                            var newShape = new Shape();
                            newShape.vertices = pathData.vertices;
                            newShape.inTangents = pathData.inTangents;
                            newShape.outTangents = pathData.outTangents;
                            newShape.closed = pathData.closed;
                            pathProp.setValue(newShape);
                            
                            for (var v = 0; v < pathData.vertices.length; v++) {
                                var vx = pathData.vertices[v][0];
                                var vy = pathData.vertices[v][1];
                                if (vx < minX) minX = vx;
                                if (vy < minY) minY = vy;
                                if (vx > maxX) maxX = vx;
                                if (vy > maxY) maxY = vy;
                            }
                        }
                        if (data.hasFill) {
                            var fillProp = groupContents.addProperty("ADBE Vector Graphic - Fill");
                            fillProp.property("ADBE Vector Fill Color").setValue(data.fillColor);
                        }
                        if (data.hasStroke) {
                            var strokeProp = groupContents.addProperty("ADBE Vector Graphic - Stroke");
                            strokeProp.property("ADBE Vector Stroke Color").setValue(data.strokeColor);
                            strokeProp.property("ADBE Vector Stroke Width").setValue(data.strokeWidth);
                        }
                    }
                }
                
                var totalWidth = maxX - minX;
                var totalHeight = maxY - minY;

                if (totalWidth > 0 && totalHeight > 0) {
                    var scaleX = (comp.width / totalWidth) * 100;
                    var scaleY = (comp.height / totalHeight) * 100;
                    var finalScale = Math.min(scaleX, scaleY); 
                    
                    var centerX = minX + (totalWidth / 2);
                    var centerY = minY + (totalHeight / 2);
                    
                    masterNull.property("Anchor Point").setValue([centerX, centerY]);
                    masterNull.property("Scale").setValue([finalScale, finalScale]);
                }

                for(var k = 0; k < importedLayers.length; k++){
                    importedLayers[k].parent = masterNull;
                    importedLayers[k].selected = true;
                }
                
                masterNull.moveToBeginning(); 
                masterNull.selected = true;
                
            } catch(err) {
                alert("Error: " + err.toString());
            } finally {
                app.endUndoGroup();
            }
        };

        // --- GLOBAL SAVED EASES ---
        var presetWrapper = win.add("group");
        presetWrapper.orientation = "column"; presetWrapper.alignment = ["fill", "bottom"]; presetWrapper.alignChildren = ["left", "top"]; presetWrapper.spacing = 0; presetWrapper.margins = [4, 0, 4, 2]; 
        var presetScroll = presetWrapper.add("group"); presetScroll.orientation = "column"; presetScroll.alignChildren = ["left", "top"]; presetScroll.spacing = 2;
        
        function rebuildPresets() { 
            while(presetScroll.children.length > 0) presetScroll.remove(presetScroll.children[0]); 
            var arr = getSavedPresets(); 
            var itemsPerRow = 12; 
            var currentRow; 
            for(var i=0; i<arr.length; i++) { 
                var parts = arr[i].split(","); if(parts.length !== 2) continue; 
                if (i % itemsPerRow === 0) { currentRow = presetScroll.add("group"); currentRow.orientation = "row"; currentRow.alignChildren = ["left", "center"]; currentRow.spacing = 2; } 
                var inV = parseFloat(parts[0]); var outV = parseFloat(parts[1]); 
                var btn = currentRow.add("custombutton", undefined, ""); 
                btn.preferredSize = [22, 22]; btn.inVal = inV; btn.outVal = outV; btn.presetIdx = i; 
                btn.onDraw = function() { 
                    var g = this.graphics; var w = this.size[0], h = this.size[1]; 
                    var isActive = (activePresetIndex === this.presetIdx); 
                    var bgColor = isActive ? [0.25, 0.25, 0.25] : [0.12, 0.12, 0.12]; 
                    var borderColor = isActive ? [1, 0.65, 0.1] : [0.3, 0.3, 0.3]; 
                    var borderThick = isActive ? 1.5 : 1; 
                    g.newPath(); g.rectPath(0,0,w,h); g.fillPath(g.newBrush(g.BrushType.SOLID_COLOR, bgColor)); 
                    g.strokePath(g.newPen(g.PenType.SOLID_COLOR, borderColor, borderThick)); 
                    drawExactSpeedCurve(g, w, h, this.outVal, this.inVal, [1, 0.65, 0.1], 1, true); 
                }; 
                btn.onClick = function() { activePresetIndex = this.presetIdx; for(var r=0; r<presetScroll.children.length; r++) { var rowItems = presetScroll.children[r]; for(var j=0; j<rowItems.children.length; j++){ forceRedraw(rowItems.children[j]); } } sldIn.value = this.inVal; sldOut.value = this.outVal; valIn.text = Math.round(this.inVal); valOut.text = Math.round(this.outVal); forceRedraw(mainGraph); applyEaseKeys(this.outVal, this.inVal); }; 
            } 
            presetWrapper.layout.layout(true); 
        }
        rebuildPresets();

        function scaleButtons(container) {
            if(!container || !container.children) return;
            for (var i = 0; i < container.children.length; i++) {
                var child = container.children[i];
                if (child.type === "button" && !child.noScale) { 
                    if(!child.preferredSize) child.preferredSize = [-1, -1]; child.preferredSize.height = 25; 
                } else if (child.children && child.children.length > 0) { scaleButtons(child); }
            }
        }
        scaleButtons(win);

        win.onResizing = win.onResize = function() { this.layout.resize(); if(typeof mainGraph !== "undefined") forceRedraw(mainGraph); };
        win.layout.layout(true); return win;
    }

    var myScriptPal = buildUI(thisObj);
    if (myScriptPal instanceof Window) { myScriptPal.center(); myScriptPal.show(); }
})(this);