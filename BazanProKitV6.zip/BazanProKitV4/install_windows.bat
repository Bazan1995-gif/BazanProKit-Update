@echo off
echo ============================================
echo  BAZAN PRO KIT V4 - Windows CEP Installer
echo ============================================
echo.
echo [1/3] Enabling CEP Debug Mode for all versions...
reg add "HKCU\SOFTWARE\Adobe\CSXS.11" /v PlayerDebugMode /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKCU\SOFTWARE\Adobe\CSXS.10" /v PlayerDebugMode /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKCU\SOFTWARE\Adobe\CSXS.9"  /v PlayerDebugMode /t REG_DWORD /d 1 /f >nul 2>&1
echo    Done.

set "DEST=%APPDATA%\Adobe\CEP\extensions\BazanProKitV4"
echo [2/3] Creating extension folder...
if not exist "%DEST%" mkdir "%DEST%"

echo [3/3] Copying files...
set "SRC=%~dp0"
xcopy "%SRC%CSXS"   "%DEST%\CSXS\"   /E /I /Y /Q >nul
xcopy "%SRC%css"    "%DEST%\css\"    /E /I /Y /Q >nul
xcopy "%SRC%js"     "%DEST%\js\"     /E /I /Y /Q >nul
xcopy "%SRC%jsx"    "%DEST%\jsx\"    /E /I /Y /Q >nul
xcopy "%SRC%icons"  "%DEST%\icons\"  /E /I /Y /Q >nul 2>&1
copy  "%SRC%index.html" "%DEST%\index.html" /Y >nul

echo.
echo ============================================
echo  DONE! Restart After Effects, then:
echo  Window ^> Extensions ^> Bazan Pro Kit V4
echo ============================================
pause
