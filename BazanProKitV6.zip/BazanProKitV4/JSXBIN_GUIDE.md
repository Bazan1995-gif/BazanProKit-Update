# JSXBIN Conversion Guide — Bazan Pro Kit V4

## What is JSXBIN?
JSXBIN is Adobe's binary encoding for ExtendScript (.jsx) files.  
It prevents casual source code reading while remaining fully executable by AE.

---

## How to Convert host.jsx → host.jsxbin

### Method 1 — Adobe ExtendScript Toolkit (ESTK) [Recommended]
1. Open **Adobe ExtendScript Toolkit** (ships with older Creative Cloud)
2. File → Open → select `jsx/host.jsx`
3. File → Export as Binary → save as `jsx/host.jsxbin`
4. Replace the `<ScriptPath>` in `CSXS/manifest.xml`:
   ```xml
   <ScriptPath>./jsx/host.jsxbin</ScriptPath>
   ```
5. Delete `jsx/host.jsx` from the deployed extension

### Method 2 — Command Line (node-jsxbin)
```bash
npm install -g jsxbin
jsxbin jsx/host.jsx jsx/host.jsxbin
```

### Method 3 — VS Code Extension
Install **vscode-jsxbin** extension, right-click `host.jsx` → "Convert to JSXBIN"

---

## Manifest update after conversion
Open `CSXS/manifest.xml` and change line:
```xml
<ScriptPath>./jsx/host.jsx</ScriptPath>
```
to:
```xml
<ScriptPath>./jsx/host.jsxbin</ScriptPath>
```

---

## Notes on host.jsx Design
The `host.jsx` was written with JSXBIN conversion in mind:
- **No `eval()`** in hot paths (only in `pullInAE` for JSON parsing, which is standard)
- **No dynamic `new Function()`** calls  
- All string-building for expressions uses concatenation, not eval
- Helper functions are plain named functions at the top level
- No external `#include` dependencies

These patterns ensure reliable JSXBIN output.

---

## Verify conversion
After converting, test in AE by opening the panel and clicking any button.  
The `.jsxbin` file should work identically to the `.jsx` file.
