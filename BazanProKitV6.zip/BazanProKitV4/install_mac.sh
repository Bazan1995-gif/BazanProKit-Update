#!/bin/bash
echo "============================================"
echo " BAZAN PRO KIT V4 - macOS CEP Installer"
echo "============================================"
echo ""
echo "[1/3] Enabling CEP Debug Mode..."
defaults write com.adobe.CSXS.11 PlayerDebugMode 1
defaults write com.adobe.CSXS.10 PlayerDebugMode 1
defaults write com.adobe.CSXS.9  PlayerDebugMode 1
echo "   Done."

DEST="$HOME/Library/Application Support/Adobe/CEP/extensions/BazanProKitV4"
echo "[2/3] Creating: $DEST"
mkdir -p "$DEST"

SRC="$(cd "$(dirname "$0")" && pwd)"
echo "[3/3] Copying files..."
cp -R "$SRC/CSXS"      "$DEST/"
cp -R "$SRC/css"       "$DEST/"
cp -R "$SRC/js"        "$DEST/"
cp -R "$SRC/jsx"       "$DEST/"
cp -R "$SRC/icons"     "$DEST/" 2>/dev/null || true
cp    "$SRC/index.html" "$DEST/"
chmod -R 755 "$DEST"

echo ""
echo "============================================"
echo " DONE! Restart After Effects, then:"
echo " Window > Extensions > Bazan Pro Kit V4"
echo "============================================"
